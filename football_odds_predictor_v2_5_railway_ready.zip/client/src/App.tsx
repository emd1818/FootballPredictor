import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import PerformanceDashboard from "./pages/PerformanceDashboard";
import PredictionsDashboard from "./pages/PredictionsDashboard";
import { Statistics } from "./pages/Statistics";
import { AlertSettings } from "./pages/AlertSettings";
import Comparison from "./pages/Comparison";
import Terms from "./pages/Terms";
import Privacy from "./pages/Privacy";
import AccuracyPage from "./pages/Accuracy";
import MatchLab from "./pages/MatchLab";

function Router() {
  // make sure to consider if you need authentication for certain routes
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/match/:id"} component={MatchLab} />
      <Route path={"/performance"} component={PerformanceDashboard} />
      <Route path={"/predictions"} component={PredictionsDashboard} />
      <Route path={"/statistics"} component={Statistics} />
      <Route path={"/comparison"} component={Comparison} />
      <Route path={"/accuracy"} component={AccuracyPage} />
      <Route path={"/alerts"} component={AlertSettings} />
      <Route path={"/terms"} component={Terms} />
      <Route path={"/privacy"} component={Privacy} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="light"
        // switchable
      >
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
