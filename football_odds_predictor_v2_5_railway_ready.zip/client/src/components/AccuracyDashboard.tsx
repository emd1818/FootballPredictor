import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, Target, BarChart3 } from "lucide-react";
import { useState, useEffect } from "react";

export interface AccuracyStats {
  totalPredictions: number;
  correctPredictions: number;
  accuracy: number;
  byConfidenceLevel: {
    high: { total: number; correct: number; accuracy: number };
    medium: { total: number; correct: number; accuracy: number };
    low: { total: number; correct: number; accuracy: number };
  };
  byLeague: {
    [league: string]: { total: number; correct: number; accuracy: number };
  };
  roi: number;
  valueBetsAccuracy: number;
}

interface AccuracyDashboardProps {
  stats?: AccuracyStats;
  isLoading?: boolean;
}

export function AccuracyDashboard({ stats, isLoading = false }: AccuracyDashboardProps) {
  const defaultStats: AccuracyStats = {
    totalPredictions: 0,
    correctPredictions: 0,
    accuracy: 0,
    byConfidenceLevel: {
      high: { total: 0, correct: 0, accuracy: 0 },
      medium: { total: 0, correct: 0, accuracy: 0 },
      low: { total: 0, correct: 0, accuracy: 0 },
    },
    byLeague: {},
    roi: 0,
    valueBetsAccuracy: 0,
  };

  const data = stats || defaultStats;

  const getAccuracyColor = (accuracy: number) => {
    if (accuracy >= 55) return 'text-green-600 dark:text-green-400';
    if (accuracy >= 50) return 'text-yellow-600 dark:text-yellow-400';
    return 'text-red-600 dark:text-red-400';
  };

  const getAccuracyBg = (accuracy: number) => {
    if (accuracy >= 55) return 'bg-green-100 dark:bg-green-900';
    if (accuracy >= 50) return 'bg-yellow-100 dark:bg-yellow-900';
    return 'bg-red-100 dark:bg-red-900';
  };

  return (
    <div className="space-y-6">
      {/* Overall Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Predictions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{data.totalPredictions}</div>
            <p className="text-xs text-muted-foreground mt-1">All-time predictions made</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Correct Predictions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-600">{data.correctPredictions}</div>
            <p className="text-xs text-muted-foreground mt-1">Successful predictions</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Overall Accuracy</CardTitle>
          </CardHeader>
          <CardContent>
            <div className={`text-3xl font-bold ${getAccuracyColor(data.accuracy)}`}>
              {data.accuracy.toFixed(1)}%
            </div>
            <p className="text-xs text-muted-foreground mt-1">Win rate</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Estimated ROI</CardTitle>
          </CardHeader>
          <CardContent>
            <div className={`text-3xl font-bold ${data.roi >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              {data.roi >= 0 ? '+' : ''}{data.roi.toFixed(1)}%
            </div>
            <p className="text-xs text-muted-foreground mt-1">Return on investment</p>
          </CardContent>
        </Card>
      </div>

      {/* Accuracy by Confidence Level */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="w-5 h-5" />
            Accuracy by Confidence Level
          </CardTitle>
          <CardDescription>How predictions perform at different confidence thresholds</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* High Confidence */}
            <div className={`p-4 rounded-lg ${getAccuracyBg(data.byConfidenceLevel.high.accuracy)}`}>
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-semibold text-foreground">High Confidence ({'>'}70%)</h4>
                <Badge variant="outline">
                  {data.byConfidenceLevel.high.accuracy.toFixed(1)}%
                </Badge>
              </div>
              <p className="text-sm text-muted-foreground mb-2">
                {data.byConfidenceLevel.high.correct} / {data.byConfidenceLevel.high.total} correct
              </p>
              <div className="w-full bg-muted rounded-full h-2">
                <div
                  className="bg-gradient-to-r from-green-500 to-emerald-500 h-2 rounded-full"
                  style={{ width: `${Math.min(data.byConfidenceLevel.high.accuracy, 100)}%` }}
                />
              </div>
            </div>

            {/* Medium Confidence */}
            <div className={`p-4 rounded-lg ${getAccuracyBg(data.byConfidenceLevel.medium.accuracy)}`}>
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-semibold text-foreground">Medium Confidence (40-70%)</h4>
                <Badge variant="outline">
                  {data.byConfidenceLevel.medium.accuracy.toFixed(1)}%
                </Badge>
              </div>
              <p className="text-sm text-muted-foreground mb-2">
                {data.byConfidenceLevel.medium.correct} / {data.byConfidenceLevel.medium.total} correct
              </p>
              <div className="w-full bg-muted rounded-full h-2">
                <div
                  className="bg-gradient-to-r from-yellow-500 to-amber-500 h-2 rounded-full"
                  style={{ width: `${Math.min(data.byConfidenceLevel.medium.accuracy, 100)}%` }}
                />
              </div>
            </div>

            {/* Low Confidence */}
            <div className={`p-4 rounded-lg ${getAccuracyBg(data.byConfidenceLevel.low.accuracy)}`}>
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-semibold text-foreground">Low Confidence ({"<"}40%)</h4>
                <Badge variant="outline">
                  {data.byConfidenceLevel.low.accuracy.toFixed(1)}%
                </Badge>
              </div>
              <p className="text-sm text-muted-foreground mb-2">
                {data.byConfidenceLevel.low.correct} / {data.byConfidenceLevel.low.total} correct
              </p>
              <div className="w-full bg-muted rounded-full h-2">
                <div
                  className="bg-gradient-to-r from-orange-500 to-red-500 h-2 rounded-full"
                  style={{ width: `${Math.min(data.byConfidenceLevel.low.accuracy, 100)}%` }}
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Value Bets Performance */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5" />
            Value Bets Performance
          </CardTitle>
          <CardDescription>Predictions with high confidence and favorable odds</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">Accuracy</p>
              <p className={`text-3xl font-bold ${getAccuracyColor(data.valueBetsAccuracy)}`}>
                {data.valueBetsAccuracy.toFixed(1)}%
              </p>
            </div>
            <div className="flex-1 ml-8">
              <div className="w-full bg-muted rounded-full h-4">
                <div
                  className="bg-gradient-to-r from-blue-500 to-purple-500 h-4 rounded-full"
                  style={{ width: `${Math.min(data.valueBetsAccuracy, 100)}%` }}
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* League Performance */}
      {Object.keys(data.byLeague).length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5" />
              Accuracy by League
            </CardTitle>
            <CardDescription>Performance across different football leagues</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {Object.entries(data.byLeague).map(([league, stats]) => (
                <div key={league}>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm font-medium text-foreground">{league}</span>
                    <Badge variant="outline" className={getAccuracyColor(stats.accuracy)}>
                      {stats.accuracy.toFixed(1)}% ({stats.correct}/{stats.total})
                    </Badge>
                  </div>
                  <div className="w-full bg-muted rounded-full h-2">
                    <div
                      className="bg-gradient-to-r from-blue-500 to-purple-500 h-2 rounded-full"
                      style={{ width: `${Math.min(stats.accuracy, 100)}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
