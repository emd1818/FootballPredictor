import { Link, useLocation } from "wouter";
import { Activity, BarChart3, Database, FlaskConical, LayoutDashboard, ListChecks, ShieldCheck, Bell } from "lucide-react";
import { cn } from "@/lib/utils";

const nav = [
  { href: "/", label: "Dashboard", icon: LayoutDashboard },
  { href: "/predictions", label: "Predictions", icon: ListChecks },
  { href: "/comparison", label: "Market vs Model", icon: Activity },
  { href: "/performance", label: "Performance", icon: BarChart3 },
  { href: "/accuracy", label: "Calibration", icon: ShieldCheck },
  { href: "/statistics", label: "Backtesting", icon: FlaskConical },
  { href: "/alerts", label: "Alerts", icon: Bell },
];

export function AppShell({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  return (
    <div className="fi-shell">
      <aside className="fi-sidebar">
        <Link href="/" className="fi-brand">
          <span className="fi-logo">FI</span>
          <span><strong>Football Intelligence</strong><small>Forecasting terminal</small></span>
        </Link>
        <div className="fi-nav-label">WORKSPACE</div>
        <nav className="fi-nav">
          {nav.map(({ href, label, icon: Icon }) => {
            const active = href === "/" ? location === "/" : location.startsWith(href);
            return <Link key={href} href={href} className={cn("fi-nav-item", active && "active")}><Icon size={17}/><span>{label}</span></Link>;
          })}
        </nav>
        <div className="fi-sidebar-bottom">
          <div className="fi-live"><span className="fi-dot"/> Real-data mode</div>
          <small>Odds and fixtures are read from the connected providers. No synthetic matches are displayed.</small>
        </div>
      </aside>
      <main className="fi-main">
        <header className="fi-topbar">
          <div><span className="fi-kicker">FOOTBALL INTELLIGENCE</span><span className="fi-top-title">Live forecasting workspace</span></div>
          <div className="fi-top-status"><span className="fi-dot"/> Production data pipeline</div>
        </header>
        {children}
      </main>
    </div>
  );
}
