import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, AlertCircle, Target, Trophy, Zap, ChevronDown, ChevronUp } from "lucide-react";
import { format } from "date-fns";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { RecentFormDisplay } from "@/components/RecentFormDisplay";

interface EnhancedPredictionCardProps {
  prediction: any;
}

export function EnhancedPredictionCard({ prediction }: EnhancedPredictionCardProps) {
  const [expanded, setExpanded] = useState(false);

  if (!prediction) return null;

  const getPredictionColor = (pred: string) => {
    switch (pred) {
      case 'home_win':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200';
      case 'away_win':
        return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200';
      case 'draw':
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200';
    }
  };

  const getPredictionLabel = (pred: string) => {
    switch (pred) {
      case 'home_win':
        return 'Home Win';
      case 'away_win':
        return 'Away Win';
      case 'draw':
        return 'Draw';
      default:
        return pred;
    }
  };

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'low':
        return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200';
      case 'high':
        return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 70) return 'text-green-600 dark:text-green-400';
    if (confidence >= 50) return 'text-yellow-600 dark:text-yellow-400';
    return 'text-orange-600 dark:text-orange-400';
  };

  const getConfidenceBg = (confidence: number) => {
    if (confidence >= 70) return 'bg-green-100 dark:bg-green-900/30';
    if (confidence >= 50) return 'bg-yellow-100 dark:bg-yellow-900/30';
    return 'bg-orange-100 dark:bg-orange-900/30';
  };

  const riskLevel = prediction.riskLevel || 'medium';
  const bookmakerDisagreement = prediction.bookmakerDisagreement || 0;
  const oddsMovementScore = prediction.oddsMovementScore || 0;
  const volatilityScore = prediction.volatilityScore || 0;
  const homeFormScore = prediction.homeFormScore;
  const awayFormScore = prediction.awayFormScore;
  const h2hAdvantage = prediction.h2hAdvantage;

  let keyInsights = [];
  try {
    if (prediction.keyInsights && typeof prediction.keyInsights === 'string') {
      keyInsights = JSON.parse(prediction.keyInsights);
    } else if (Array.isArray(prediction.keyInsights)) {
      keyInsights = prediction.keyInsights;
    }
  } catch (e) {
    keyInsights = [];
  }

  return (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow">
      <CardHeader className={`pb-3 ${getConfidenceBg(prediction.confidence)}`}>
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <h3 className="text-lg font-semibold text-foreground">
                {prediction.match?.homeTeam || 'TBD'} vs {prediction.match?.awayTeam || 'TBD'}
              </h3>
              <Badge variant="outline" className="text-xs">
                {prediction.match?.league || 'Unknown'}
              </Badge>
            </div>
            <p className="text-sm text-muted-foreground">
              {prediction.match?.matchDate ? format(new Date(prediction.match.matchDate), 'MMM dd, HH:mm') : 'TBD'}
            </p>
          </div>
          <div className="text-right">
            <div className={`text-3xl font-bold ${getConfidenceColor(prediction.confidence)}`}>
              {prediction.confidence}%
            </div>
            <p className="text-xs text-muted-foreground">Confidence</p>
          </div>
        </div>
      </CardHeader>

      <CardContent className="pt-4">
        {/* Prediction Badge */}
        <div className="mb-4">
          <Badge className={`text-sm py-1 px-3 ${getPredictionColor(prediction.prediction)}`}>
            <TrendingUp className="w-3 h-3 mr-1 inline" />
            {getPredictionLabel(prediction.prediction)}
          </Badge>
        </div>

        {/* Team Form & H2H Stats */}
        {(homeFormScore !== undefined || awayFormScore !== undefined || h2hAdvantage !== undefined) && (
          <div className="grid grid-cols-3 gap-2 mb-4">
            {homeFormScore !== undefined && (
              <div className="bg-blue-50 dark:bg-blue-900/20 p-2 rounded-lg border border-blue-200 dark:border-blue-800">
                <p className="text-xs text-muted-foreground mb-1">Home Form</p>
                <div className="flex items-center gap-1">
                  <span className="text-sm font-semibold text-blue-600 dark:text-blue-400">{homeFormScore}</span>
                  <span className="text-xs text-muted-foreground">/100</span>
                </div>
                <div className="w-full bg-muted rounded-full h-1 mt-1">
                  <div className="bg-blue-500 h-1 rounded-full" style={{ width: `${homeFormScore}%` }} />
                </div>
              </div>
            )}
            {awayFormScore !== undefined && (
              <div className="bg-red-50 dark:bg-red-900/20 p-2 rounded-lg border border-red-200 dark:border-red-800">
                <p className="text-xs text-muted-foreground mb-1">Away Form</p>
                <div className="flex items-center gap-1">
                  <span className="text-sm font-semibold text-red-600 dark:text-red-400">{awayFormScore}</span>
                  <span className="text-xs text-muted-foreground">/100</span>
                </div>
                <div className="w-full bg-muted rounded-full h-1 mt-1">
                  <div className="bg-red-500 h-1 rounded-full" style={{ width: `${awayFormScore}%` }} />
                </div>
              </div>
            )}
            {h2hAdvantage !== undefined && (
              <div className="bg-purple-50 dark:bg-purple-900/20 p-2 rounded-lg border border-purple-200 dark:border-purple-800">
                <p className="text-xs text-muted-foreground mb-1">H2H Advantage</p>
                <div className="flex items-center gap-1">
                  <span className={`text-sm font-semibold ${
                    h2hAdvantage > 0 ? 'text-green-600 dark:text-green-400' : 
                    h2hAdvantage < 0 ? 'text-red-600 dark:text-red-400' : 
                    'text-gray-600 dark:text-gray-400'
                  }`}>
                    {h2hAdvantage > 0 ? '+' : ''}{h2hAdvantage}
                  </span>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Recent Match Results */}
        {(prediction.recentFormHome || prediction.recentFormAway) && (
          <div className="grid grid-cols-2 gap-3 mb-4">
            {prediction.recentFormHome && (
              <div className="bg-blue-50 dark:bg-blue-900/20 p-3 rounded-lg border border-blue-200 dark:border-blue-800">
                <RecentFormDisplay recentForm={prediction.recentFormHome} teamName={prediction.match?.homeTeam} />
              </div>
            )}
            {prediction.recentFormAway && (
              <div className="bg-red-50 dark:bg-red-900/20 p-3 rounded-lg border border-red-200 dark:border-red-800">
                <RecentFormDisplay recentForm={prediction.recentFormAway} teamName={prediction.match?.awayTeam} />
              </div>
            )}
          </div>
        )}

        {/* Odds Coefficients */}
        {(prediction.homeWinOdds || prediction.drawOdds || prediction.awayWinOdds) && (
          <div className="grid grid-cols-3 gap-2 mb-4">
            <div className="bg-blue-50 dark:bg-blue-900/20 p-2 rounded-lg border border-blue-200 dark:border-blue-800">
              <p className="text-xs text-muted-foreground mb-1">1 (Home)</p>
              <p className="text-lg font-semibold text-blue-600 dark:text-blue-400">{prediction.homeWinOdds || '2.00'}</p>
            </div>
            <div className="bg-yellow-50 dark:bg-yellow-900/20 p-2 rounded-lg border border-yellow-200 dark:border-yellow-800">
              <p className="text-xs text-muted-foreground mb-1">X (Draw)</p>
              <p className="text-lg font-semibold text-yellow-600 dark:text-yellow-400">{prediction.drawOdds || '3.00'}</p>
            </div>
            <div className="bg-red-50 dark:bg-red-900/20 p-2 rounded-lg border border-red-200 dark:border-red-800">
              <p className="text-xs text-muted-foreground mb-1">2 (Away)</p>
              <p className="text-lg font-semibold text-red-600 dark:text-red-400">{prediction.awayWinOdds || '3.50'}</p>
            </div>
          </div>
        )}

        {/* Risk Level and Other Indicators */}
        <div className="flex flex-wrap gap-2 mb-4">
          <Badge className={`${getRiskColor(riskLevel)}`}>
            <AlertCircle className="w-3 h-3 mr-1" />
            {riskLevel.charAt(0).toUpperCase() + riskLevel.slice(1)} Risk
          </Badge>

          {oddsMovementScore > 0 && (
            <Badge variant="outline">
              <TrendingUp className="w-3 h-3 mr-1" />
              Odds Movement: {oddsMovementScore}%
            </Badge>
          )}

          {volatilityScore > 0 && (
            <Badge variant="outline">
              <Zap className="w-3 h-3 mr-1" />
              Volatility: {volatilityScore}%
            </Badge>
          )}

          {bookmakerDisagreement > 0 && (
            <Badge variant="outline">
              <Target className="w-3 h-3 mr-1" />
              Disagreement: {bookmakerDisagreement}%
            </Badge>
          )}
        </div>

        {/* Reasoning */}
        {prediction.reasoning && (
          <div className="mb-4 p-3 bg-muted/30 rounded-lg border border-border">
            <p className="text-sm text-foreground line-clamp-2">{prediction.reasoning}</p>
          </div>
        )}

        {/* Expandable Insights */}
        {keyInsights.length > 0 && (
          <div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setExpanded(!expanded)}
              className="w-full justify-between text-left mb-2"
            >
              <span className="text-sm font-medium">Key Insights ({keyInsights.length})</span>
              {expanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </Button>

            {expanded && (
              <div className="space-y-2 pl-4 border-l border-border">
                {keyInsights.map((insight: any, idx: number) => (
                  <div key={idx} className="text-sm text-muted-foreground">
                    <span className="text-primary font-medium">•</span> {insight}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
