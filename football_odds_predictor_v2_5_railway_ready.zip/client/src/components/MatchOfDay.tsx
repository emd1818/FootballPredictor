import { trpc } from '@/lib/trpc';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Flame, TrendingUp } from 'lucide-react';
import { format } from 'date-fns';

export function MatchOfDay() {
  const { data: matchOfDay, isLoading } = trpc.predictions.matchOfDay.useQuery();

  if (isLoading) {
    return (
      <Card className="p-8 bg-gradient-to-r from-orange-50 to-red-50 border-orange-200">
        <div className="animate-pulse space-y-4">
          <div className="h-4 bg-orange-200 rounded w-1/4"></div>
          <div className="h-8 bg-orange-200 rounded w-1/2"></div>
          <div className="h-4 bg-orange-200 rounded w-3/4"></div>
        </div>
      </Card>
    );
  }

  if (!matchOfDay) {
    return null;
  }

  const matchTime = matchOfDay.matchDate ? format(new Date(matchOfDay.matchDate), 'HH:mm') : 'TBD';
  const matchDate = matchOfDay.matchDate ? format(new Date(matchOfDay.matchDate), 'MMM d') : '';

  // Determine prediction label
  const predictionLabel = matchOfDay.prediction === 'home_win' 
    ? `${matchOfDay.homeTeam} Win`
    : matchOfDay.prediction === 'away_win'
    ? `${matchOfDay.awayTeam} Win`
    : 'Draw';

  // Determine confidence color
  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 80) return 'bg-red-500';
    if (confidence >= 70) return 'bg-orange-500';
    return 'bg-yellow-500';
  };

  return (
    <Card className="p-8 bg-gradient-to-r from-orange-50 to-red-50 border-2 border-orange-200 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-0 right-0 opacity-10">
        <Flame size={120} className="text-orange-500" />
      </div>

      <div className="relative z-10">
        {/* Header */}
        <div className="flex items-center gap-3 mb-6">
          <Flame size={24} className="text-orange-500" />
          <h2 className="text-2xl font-bold text-gray-900">Match of the Day</h2>
          <Badge className="ml-auto bg-orange-500 text-white">AI Recommended</Badge>
        </div>

        {/* Match Info */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-4">
            <div className="text-center flex-1">
              <p className="text-lg font-semibold text-gray-900">{matchOfDay.homeTeam}</p>
              <p className="text-sm text-gray-600">Home</p>
            </div>
            <div className="px-6 text-center">
              <p className="text-sm font-medium text-gray-600 mb-2">vs</p>
              <p className="text-xs text-gray-500">{matchDate} • {matchTime}</p>
            </div>
            <div className="text-center flex-1">
              <p className="text-lg font-semibold text-gray-900">{matchOfDay.awayTeam}</p>
              <p className="text-sm text-gray-600">Away</p>
            </div>
          </div>

          {/* League Badge */}
          <div className="flex justify-center mb-4">
            <Badge variant="outline" className="bg-white border-orange-200">
              {matchOfDay.league}
            </Badge>
          </div>
        </div>

        {/* Prediction Card */}
        <div className="bg-white rounded-lg p-6 mb-6 border border-orange-100">
          <div className="flex items-center justify-between mb-4">
            <div>
              <p className="text-sm text-gray-600 mb-1">AI Prediction</p>
              <p className="text-2xl font-bold text-gray-900">{predictionLabel}</p>
            </div>
            <div className="text-right">
              <p className="text-sm text-gray-600 mb-1">Confidence</p>
              <div className="flex items-center gap-2">
                <div className="w-32 h-3 bg-gray-200 rounded-full overflow-hidden">
                  <div
                    className={`h-full ${getConfidenceColor(matchOfDay.confidence)} transition-all`}
                    style={{ width: `${matchOfDay.confidence}%` }}
                  ></div>
                </div>
                <span className="text-2xl font-bold text-gray-900">{matchOfDay.confidence}%</span>
              </div>
            </div>
          </div>

          {/* Volatility Score */}
          <div className="flex items-center gap-2 text-sm text-orange-600 bg-orange-50 p-3 rounded">
            <TrendingUp size={16} />
            <span>Odds Volatility: {matchOfDay.volatilityScore.toFixed(2)}% - High market movement detected</span>
          </div>
        </div>

        {/* Reasoning */}
        {matchOfDay.reasoning && (
          <div className="bg-white rounded-lg p-6 border border-orange-100">
            <p className="text-sm font-semibold text-gray-900 mb-3">AI Analysis</p>
            <p className="text-sm text-gray-700 leading-relaxed">{matchOfDay.reasoning}</p>
          </div>
        )}
      </div>
    </Card>
  );
}
