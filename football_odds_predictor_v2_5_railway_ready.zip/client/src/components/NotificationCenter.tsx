import { useState, useEffect } from 'react';
import { Bell, X, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

export interface Notification {
  id: number;
  title: string;
  message: string;
  confidence: number;
  prediction: string;
  isRead: boolean;
  sentAt: string;
  matchId: number;
}

interface NotificationCenterProps {
  notifications?: Notification[];
  onMarkAsRead?: (notificationId: number) => void;
  onDelete?: (notificationId: number) => void;
}

export function NotificationCenter({
  notifications = [],
  onMarkAsRead,
  onDelete,
}: NotificationCenterProps) {
  const [isOpen, setIsOpen] = useState(false);
  const unreadCount = notifications.filter(n => !n.isRead).length;

  const getPredictionColor = (prediction: string) => {
    switch (prediction) {
      case 'home_win':
        return 'bg-blue-100 text-blue-800';
      case 'away_win':
        return 'bg-red-100 text-red-800';
      case 'draw':
        return 'bg-gray-100 text-gray-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 85) return 'text-red-600';
    if (confidence >= 75) return 'text-orange-600';
    return 'text-yellow-600';
  };

  return (
    <div className="relative">
      {/* Notification Bell Button */}
      <Button
        variant="ghost"
        size="icon"
        onClick={() => setIsOpen(!isOpen)}
        className="relative"
      >
        <Bell className="h-5 w-5" />
        {unreadCount > 0 && (
          <Badge
            variant="destructive"
            className="absolute -top-2 -right-2 h-5 w-5 flex items-center justify-center p-0 text-xs"
          >
            {unreadCount}
          </Badge>
        )}
      </Button>

      {/* Notification Dropdown */}
      {isOpen && (
        <div className="absolute right-0 mt-2 w-96 bg-white rounded-lg shadow-lg border border-gray-200 z-50">
          <div className="p-4 border-b border-gray-200">
            <h3 className="font-semibold text-lg">Notifications</h3>
          </div>

          {notifications.length === 0 ? (
            <div className="p-8 text-center text-gray-500">
              <p>No notifications yet</p>
            </div>
          ) : (
            <div className="max-h-96 overflow-y-auto">
              {notifications.map((notification) => (
                <Card
                  key={notification.id}
                  className={`m-2 p-3 cursor-pointer transition-colors ${
                    notification.isRead
                      ? 'bg-gray-50 hover:bg-gray-100'
                      : 'bg-blue-50 hover:bg-blue-100 border-blue-200'
                  }`}
                  onClick={() => {
                    if (!notification.isRead && onMarkAsRead) {
                      onMarkAsRead(notification.id);
                    }
                  }}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1">
                      <h4 className="font-semibold text-sm">{notification.title}</h4>
                      <p className="text-xs text-gray-600 mt-1">{notification.message}</p>
                      
                      <div className="flex items-center gap-2 mt-2">
                        <Badge className={getPredictionColor(notification.prediction)}>
                          {notification.prediction.replace('_', ' ').toUpperCase()}
                        </Badge>
                        <span className={`text-xs font-bold ${getConfidenceColor(notification.confidence)}`}>
                          {notification.confidence}%
                        </span>
                      </div>

                      <p className="text-xs text-gray-500 mt-2">
                        {new Date(notification.sentAt).toLocaleString()}
                      </p>
                    </div>

                    <div className="flex gap-1">
                      {!notification.isRead && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            if (onMarkAsRead) {
                              onMarkAsRead(notification.id);
                            }
                          }}
                          title="Mark as read"
                        >
                          <Check className="h-4 w-4" />
                        </Button>
                      )}
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation();
                          if (onDelete) {
                            onDelete(notification.id);
                          }
                        }}
                        title="Delete"
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
