import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { toast } from 'sonner';

export interface NotificationPreferencesData {
  confidenceThreshold: number;
  enableEmailNotifications: boolean;
  enableInAppNotifications: boolean;
  preferredLeagues?: string[];
}

interface NotificationPreferencesProps {
  preferences?: NotificationPreferencesData;
  onSave?: (preferences: NotificationPreferencesData) => Promise<void>;
  isLoading?: boolean;
}

const AVAILABLE_LEAGUES = [
  'Premier League',
  'La Liga',
  'Serie A',
  'Bundesliga',
  'Ligue 1',
  'Champions League',
];

export function NotificationPreferences({
  preferences = {
    confidenceThreshold: 75,
    enableEmailNotifications: true,
    enableInAppNotifications: true,
  },
  onSave,
  isLoading = false,
}: NotificationPreferencesProps) {
  const [formData, setFormData] = useState<NotificationPreferencesData>(preferences);
  const [isSaving, setIsSaving] = useState(false);

  const handleThresholdChange = (value: number[]) => {
    setFormData({ ...formData, confidenceThreshold: value[0] });
  };

  const handleToggleEmail = (checked: boolean) => {
    setFormData({ ...formData, enableEmailNotifications: checked });
  };

  const handleToggleInApp = (checked: boolean) => {
    setFormData({ ...formData, enableInAppNotifications: checked });
  };

  const handleLeagueToggle = (league: string) => {
    const leagues = formData.preferredLeagues || [];
    const updated = leagues.includes(league)
      ? leagues.filter(l => l !== league)
      : [...leagues, league];
    setFormData({ ...formData, preferredLeagues: updated });
  };

  const handleSave = async () => {
    if (!onSave) return;

    setIsSaving(true);
    try {
      await onSave(formData);
      toast.success('Notification preferences saved');
    } catch (error) {
      toast.error('Failed to save preferences');
      console.error(error);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <Card className="p-6 max-w-2xl">
      <h2 className="text-2xl font-bold mb-6">Notification Preferences</h2>

      {/* Confidence Threshold */}
      <div className="mb-8">
        <Label className="text-base font-semibold mb-4 block">
          Confidence Threshold: {formData.confidenceThreshold}%
        </Label>
        <p className="text-sm text-gray-600 mb-4">
          Only receive notifications for predictions with confidence at or above this level
        </p>
        <Slider
          value={[formData.confidenceThreshold]}
          onValueChange={handleThresholdChange}
          min={50}
          max={100}
          step={5}
          className="w-full"
        />
        <div className="flex justify-between text-xs text-gray-500 mt-2">
          <span>50%</span>
          <span>100%</span>
        </div>
      </div>

      {/* Notification Channels */}
      <div className="mb-8">
        <h3 className="font-semibold mb-4">Notification Channels</h3>
        
        <div className="space-y-4">
          <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
            <div>
              <Label className="font-medium">Email Notifications</Label>
              <p className="text-sm text-gray-600">Receive predictions via email</p>
            </div>
            <Switch
              checked={formData.enableEmailNotifications}
              onCheckedChange={handleToggleEmail}
              disabled={isLoading || isSaving}
            />
          </div>

          <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
            <div>
              <Label className="font-medium">In-App Notifications</Label>
              <p className="text-sm text-gray-600">See predictions in the notification center</p>
            </div>
            <Switch
              checked={formData.enableInAppNotifications}
              onCheckedChange={handleToggleInApp}
              disabled={isLoading || isSaving}
            />
          </div>
        </div>
      </div>

      {/* Preferred Leagues */}
      <div className="mb-8">
        <h3 className="font-semibold mb-4">Preferred Leagues (Optional)</h3>
        <p className="text-sm text-gray-600 mb-4">
          Leave empty to receive notifications for all leagues
        </p>
        
        <div className="grid grid-cols-2 gap-3">
          {AVAILABLE_LEAGUES.map((league) => (
            <label
              key={league}
              className="flex items-center p-3 border border-gray-200 rounded-lg cursor-pointer hover:bg-gray-50"
            >
              <input
                type="checkbox"
                checked={(formData.preferredLeagues || []).includes(league)}
                onChange={() => handleLeagueToggle(league)}
                disabled={isLoading || isSaving}
                className="w-4 h-4 rounded"
              />
              <span className="ml-3 text-sm">{league}</span>
            </label>
          ))}
        </div>
      </div>

      {/* Save Button */}
      <Button
        onClick={handleSave}
        disabled={isSaving || isLoading}
        className="w-full"
      >
        {isSaving ? 'Saving...' : 'Save Preferences'}
      </Button>
    </Card>
  );
}
