import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Filter, X } from 'lucide-react';

export interface PredictionFiltersState {
  confidenceLevel: 'all' | 'high' | 'medium' | 'low';
  riskLevel: 'all' | 'low' | 'medium' | 'high';
  league: string;
}

interface PredictionFiltersProps {
  onFiltersChange: (filters: PredictionFiltersState) => void;
  availableLeagues: string[];
}

export function PredictionFilters({ onFiltersChange, availableLeagues }: PredictionFiltersProps) {
  const [filters, setFilters] = useState<PredictionFiltersState>(() => {
    const saved = localStorage.getItem('predictionFilters');
    return saved ? JSON.parse(saved) : {
      confidenceLevel: 'all',
      riskLevel: 'all',
      league: 'all',
    };
  });

  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    localStorage.setItem('predictionFilters', JSON.stringify(filters));
    onFiltersChange(filters);
  }, [filters, onFiltersChange]);

  const handleReset = () => {
    const defaultFilters: PredictionFiltersState = {
      confidenceLevel: 'all',
      riskLevel: 'all',
      league: 'all',
    };
    setFilters(defaultFilters);
  };

  const activeFilterCount = [
    filters.confidenceLevel !== 'all' ? 1 : 0,
    filters.riskLevel !== 'all' ? 1 : 0,
    filters.league !== 'all' ? 1 : 0,
  ].reduce((a, b) => a + b, 0);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <Button
          variant="outline"
          size="sm"
          onClick={() => setIsOpen(!isOpen)}
          className="gap-2"
        >
          <Filter className="w-4 h-4" />
          Filters
          {activeFilterCount > 0 && (
            <Badge variant="secondary" className="ml-2">
              {activeFilterCount}
            </Badge>
          )}
        </Button>

        {activeFilterCount > 0 && (
          <Button
            variant="ghost"
            size="sm"
            onClick={handleReset}
            className="gap-1 text-muted-foreground hover:text-foreground"
          >
            <X className="w-4 h-4" />
            Reset
          </Button>
        )}
      </div>

      {isOpen && (
        <div className="bg-muted/50 p-4 rounded-lg space-y-4 border border-border">
          {/* Confidence Level Filter */}
          <div>
            <p className="text-sm font-medium text-foreground mb-2">Confidence Level</p>
            <div className="flex gap-2 flex-wrap">
              {(['all', 'high', 'medium', 'low'] as const).map((level) => (
                <Button
                  key={level}
                  variant={filters.confidenceLevel === level ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setFilters({ ...filters, confidenceLevel: level })}
                  className="capitalize"
                >
                  {level === 'all' ? 'All' : level === 'high' ? '>70%' : level === 'medium' ? '40-70%' : '<40%'}
                </Button>
              ))}
            </div>
          </div>

          {/* Risk Level Filter */}
          <div>
            <p className="text-sm font-medium text-foreground mb-2">Risk Level</p>
            <div className="flex gap-2 flex-wrap">
              {(['all', 'low', 'medium', 'high'] as const).map((risk) => (
                <Button
                  key={risk}
                  variant={filters.riskLevel === risk ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setFilters({ ...filters, riskLevel: risk })}
                  className="capitalize"
                >
                  {risk === 'all' ? 'All' : risk}
                </Button>
              ))}
            </div>
          </div>

          {/* League Filter */}
          {availableLeagues.length > 0 && (
            <div>
              <p className="text-sm font-medium text-foreground mb-2">League</p>
              <div className="flex gap-2 flex-wrap">
                <Button
                  variant={filters.league === 'all' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setFilters({ ...filters, league: 'all' })}
                >
                  All Leagues
                </Button>
                {availableLeagues.map((league) => (
                  <Button
                    key={league}
                    variant={filters.league === league ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setFilters({ ...filters, league })}
                  >
                    {league}
                  </Button>
                ))}
              </div>
            </div>
          )}


        </div>
      )}
    </div>
  );
}
