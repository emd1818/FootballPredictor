import React from 'react';

interface RecentFormDisplayProps {
  recentForm?: string; // e.g., "WWDLW" - last 5 matches
  teamName?: string;
}

/**
 * Display recent match results as W/D/L badges
 * Shows the last 5 matches in reverse chronological order (most recent on left)
 */
export const RecentFormDisplay: React.FC<RecentFormDisplayProps> = ({ recentForm, teamName }) => {
  if (!recentForm || recentForm.length === 0) {
    return null;
  }

  // Convert form string to array of results, most recent first
  const results = recentForm.split('').reverse();

  const getResultColor = (result: string) => {
    switch (result.toUpperCase()) {
      case 'W':
        return 'bg-green-100 dark:bg-green-900/40 text-green-700 dark:text-green-300 border-green-300 dark:border-green-700';
      case 'D':
        return 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 border-gray-300 dark:border-gray-600';
      case 'L':
        return 'bg-red-100 dark:bg-red-900/40 text-red-700 dark:text-red-300 border-red-300 dark:border-red-700';
      default:
        return 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 border-gray-300 dark:border-gray-600';
    }
  };

  const getResultLabel = (result: string) => {
    switch (result.toUpperCase()) {
      case 'W':
        return 'Win';
      case 'D':
        return 'Draw';
      case 'L':
        return 'Loss';
      default:
        return result;
    }
  };

  return (
    <div className="flex flex-col gap-1">
      <p className="text-xs text-muted-foreground">
        {teamName ? `${teamName} Recent Form` : 'Recent Form'}
      </p>
      <div className="flex gap-1">
        {results.map((result, index) => (
          <div
            key={index}
            className={`w-7 h-7 flex items-center justify-center rounded border font-semibold text-xs ${getResultColor(result)}`}
            title={getResultLabel(result)}
          >
            {result.toUpperCase()}
          </div>
        ))}
      </div>
    </div>
  );
};

export default RecentFormDisplay;
