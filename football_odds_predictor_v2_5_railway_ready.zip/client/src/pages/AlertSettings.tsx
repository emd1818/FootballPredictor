import { useState, useEffect } from 'react';
import { trpc } from '@/lib/trpc';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Bell, Mail, Inbox, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';

const AVAILABLE_LEAGUES = [
  'EPL',
  'La Liga',
  'Serie A',
  'Bundesliga',
  'Ligue 1',
  'Eredivisie',
  'Brazilian Serie A',
];

export function AlertSettings() {
  const [confidenceThreshold, setConfidenceThreshold] = useState(75);
  const [emailNotifications, setEmailNotifications] = useState(false);
  const [inAppNotifications, setInAppNotifications] = useState(true);
  const [selectedLeagues, setSelectedLeagues] = useState<string[]>([]);
  const [isSaving, setIsSaving] = useState(false);

  const { data: preferences, isLoading } = trpc.notifications.preferences.useQuery();
  const updateMutation = trpc.notifications.updatePreferences.useMutation();

  useEffect(() => {
    if (preferences) {
      setConfidenceThreshold(preferences.confidenceThreshold || 75);
      setEmailNotifications(preferences.enableEmailNotifications === 1);
      setInAppNotifications(preferences.enableInAppNotifications === 1);
      if (preferences.preferredLeagues) {
        try {
          const leagues = JSON.parse(preferences.preferredLeagues);
          setSelectedLeagues(Array.isArray(leagues) ? leagues : []);
        } catch {
          setSelectedLeagues([]);
        }
      }
    }
  }, [preferences]);

  const handleSave = async () => {
    setIsSaving(true);
    try {
      await updateMutation.mutateAsync({
        confidenceThreshold,
        enableEmailNotifications: emailNotifications,
        enableInAppNotifications: inAppNotifications,
        preferredLeagues: selectedLeagues.length > 0 ? selectedLeagues : undefined,
      });
      toast.success('Alert settings saved successfully!');
    } catch (error) {
      toast.error('Failed to save alert settings');
    } finally {
      setIsSaving(false);
    }
  };

  const toggleLeague = (league: string) => {
    setSelectedLeagues((prev) =>
      prev.includes(league) ? prev.filter((l) => l !== league) : [...prev, league]
    );
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p>Loading alert settings...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-8">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <Bell className="w-8 h-8 text-primary" />
            <h1 className="text-4xl font-bold">Alert Settings</h1>
          </div>
          <p className="text-muted-foreground">
            Configure how you receive notifications about high-confidence predictions
          </p>
        </div>

        {/* Confidence Threshold */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Confidence Threshold</CardTitle>
            <CardDescription>
              Only receive alerts for predictions with confidence above this level
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <Label>Minimum Confidence</Label>
                <Badge variant="secondary" className="text-lg px-3 py-1">
                  {confidenceThreshold}%
                </Badge>
              </div>
              <Slider
                value={[confidenceThreshold]}
                onValueChange={(value) => setConfidenceThreshold(value[0])}
                min={50}
                max={100}
                step={5}
                className="w-full"
              />
              <p className="text-sm text-muted-foreground">
                {confidenceThreshold >= 80
                  ? 'Very selective - only highest confidence predictions'
                  : confidenceThreshold >= 70
                    ? 'Balanced - good mix of predictions'
                    : 'Inclusive - more predictions but lower confidence'}
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Notification Channels */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Notification Channels</CardTitle>
            <CardDescription>Choose how you want to receive alerts</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center space-x-3 p-3 rounded-lg border border-border bg-muted/30 opacity-50">
              <Checkbox
                id="email"
                checked={false}
                disabled
              />
              <div className="flex-1">
                <Label htmlFor="email" className="flex items-center gap-2 cursor-not-allowed">
                  <Mail className="w-4 h-4" />
                  Email Notifications
                </Label>
                <p className="text-sm text-muted-foreground mt-1">
                  Email notifications are currently disabled
                </p>
              </div>
            </div>

            <div className="flex items-center space-x-3 p-3 rounded-lg border border-border hover:bg-muted/50">
              <Checkbox
                id="inapp"
                checked={inAppNotifications}
                onCheckedChange={(checked) => setInAppNotifications(checked as boolean)}
              />
              <div className="flex-1">
                <Label htmlFor="inapp" className="flex items-center gap-2 cursor-pointer">
                  <Inbox className="w-4 h-4" />
                  In-App Notifications
                </Label>
                <p className="text-sm text-muted-foreground mt-1">
                  See alerts in your notification inbox within the app
                </p>
              </div>
            </div>

            {!emailNotifications && !inAppNotifications && (
              <div className="flex items-start gap-3 p-3 rounded-lg bg-amber-50 border border-amber-200">
                <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
                <p className="text-sm text-amber-800">
                  You have disabled all notification channels. You won't receive any alerts.
                </p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* League Preferences */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>League Preferences</CardTitle>
            <CardDescription>
              Leave empty to receive alerts for all leagues, or select specific leagues
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-3">
              {AVAILABLE_LEAGUES.map((league) => (
                <div
                  key={league}
                  className="flex items-center space-x-2 p-2 rounded-lg border border-border hover:bg-muted/50 cursor-pointer"
                  onClick={() => toggleLeague(league)}
                >
                  <Checkbox
                    checked={selectedLeagues.includes(league)}
                    onCheckedChange={() => toggleLeague(league)}
                  />
                  <Label className="cursor-pointer flex-1">{league}</Label>
                </div>
              ))}
            </div>
            {selectedLeagues.length > 0 && (
              <div className="mt-4 p-3 rounded-lg bg-blue-50 border border-blue-200">
                <p className="text-sm text-blue-800">
                  Alerts will be sent for: <strong>{selectedLeagues.join(', ')}</strong>
                </p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Save Button */}
        <div className="flex gap-3">
          <Button
            onClick={handleSave}
            disabled={isSaving || updateMutation.isPending}
            className="flex-1"
            size="lg"
          >
            {isSaving || updateMutation.isPending ? 'Saving...' : 'Save Settings'}
          </Button>
        </div>

        {/* Info Section */}
        <Card className="mt-8 bg-blue-50 border-blue-200">
          <CardHeader>
            <CardTitle className="text-blue-900 flex items-center gap-2">
              <AlertCircle className="w-5 h-5" />
              How Alerts Work
            </CardTitle>
          </CardHeader>
          <CardContent className="text-blue-800 space-y-2 text-sm">
            <p>
              • Alerts are checked every 30 minutes when new predictions are generated
            </p>
            <p>
              • You'll receive one notification per high-confidence prediction
            </p>
            <p>
              • Each prediction is only notified once to avoid duplicates
            </p>
            <p>
              • Check your notification inbox to view all past alerts
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
