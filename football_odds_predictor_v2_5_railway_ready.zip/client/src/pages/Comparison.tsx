import { useState } from 'react';
import { trpc } from '@/lib/trpc';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart, Line } from 'recharts';

export default function Comparison() {
  const [daysBack, setDaysBack] = useState(30);
  
  const { data: comparisonStats, isLoading } = trpc.analytics.comparison.useQuery({ 
    daysBack 
  });

  const timePeriods = [
    { label: '7 days', value: 7 },
    { label: '14 days', value: 14 },
    { label: '30 days', value: 30 },
    { label: '60 days', value: 60 },
    { label: '90 days', value: 90 },
  ];

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-lg text-muted-foreground">Loading comparison data...</div>
      </div>
    );
  }

  if (!comparisonStats) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-lg text-muted-foreground">No data available</div>
      </div>
    );
  }

  // Prepare data for prediction type chart
  const typeChartData = comparisonStats.predictionTypes.map((type) => ({
    name: type.type.replace('_', ' ').toUpperCase(),
    accuracy: Math.round(type.accuracy * 10) / 10,
    predictions: type.totalPredictions,
    correct: type.correctPredictions,
  }));

  // Prepare data for confidence range chart
  const confidenceChartData = comparisonStats.confidenceRanges.map((range) => ({
    range: range.range,
    accuracy: Math.round(range.accuracy * 10) / 10,
    predictions: range.totalPredictions,
  }));

  return (
    <div className="min-h-screen bg-background p-4 sm:p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">Prediction Comparison</h1>
          <p className="text-muted-foreground">
            Analyze accuracy across different prediction types and confidence ranges
          </p>
        </div>

        {/* Time Period Selector */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Time Period</CardTitle>
            <CardDescription>Select the period to analyze</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {timePeriods.map((period) => (
                <Button
                  key={period.value}
                  variant={daysBack === period.value ? 'default' : 'outline'}
                  onClick={() => setDaysBack(period.value)}
                >
                  {period.label}
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Overall Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Overall Accuracy
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">
                {Math.round(comparisonStats.overallAccuracy * 10) / 10}%
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                {comparisonStats.totalCorrect} of {comparisonStats.totalPredictions} correct
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Total Predictions
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{comparisonStats.totalPredictions}</div>
              <p className="text-xs text-muted-foreground mt-1">
                Over {daysBack} days
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Correct Predictions
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{comparisonStats.totalCorrect}</div>
              <p className="text-xs text-muted-foreground mt-1">
                Successful predictions
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Accuracy by Prediction Type */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Accuracy by Prediction Type</CardTitle>
            <CardDescription>
              Compare accuracy across Home Win, Draw, and Away Win predictions
            </CardDescription>
          </CardHeader>
          <CardContent>
            {typeChartData.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={typeChartData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="accuracy" fill="#3b82f6" name="Accuracy %" />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                No prediction type data available
              </div>
            )}

            {/* Detailed Table */}
            <div className="mt-6 overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="border-b">
                  <tr>
                    <th className="text-left py-2 px-2">Prediction Type</th>
                    <th className="text-right py-2 px-2">Total</th>
                    <th className="text-right py-2 px-2">Correct</th>
                    <th className="text-right py-2 px-2">Accuracy</th>
                    <th className="text-right py-2 px-2">Avg Confidence</th>
                  </tr>
                </thead>
                <tbody>
                  {comparisonStats.predictionTypes.map((type) => (
                    <tr key={type.type} className="border-b hover:bg-muted/50">
                      <td className="py-2 px-2 font-medium">
                        {type.type.replace('_', ' ').toUpperCase()}
                      </td>
                      <td className="text-right py-2 px-2">{type.totalPredictions}</td>
                      <td className="text-right py-2 px-2">{type.correctPredictions}</td>
                      <td className="text-right py-2 px-2 font-semibold">
                        {Math.round(type.accuracy * 10) / 10}%
                      </td>
                      <td className="text-right py-2 px-2">
                        {Math.round(type.averageConfidence * 10) / 10}%
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        {/* Accuracy by Confidence Range */}
        <Card>
          <CardHeader>
            <CardTitle>Accuracy by Confidence Range</CardTitle>
            <CardDescription>
              How accuracy correlates with prediction confidence levels
            </CardDescription>
          </CardHeader>
          <CardContent>
            {confidenceChartData.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={confidenceChartData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="range" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line 
                    type="monotone" 
                    dataKey="accuracy" 
                    stroke="#10b981" 
                    name="Accuracy %" 
                    strokeWidth={2}
                  />
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                No confidence range data available
              </div>
            )}

            {/* Detailed Table */}
            <div className="mt-6 overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="border-b">
                  <tr>
                    <th className="text-left py-2 px-2">Confidence Range</th>
                    <th className="text-right py-2 px-2">Total</th>
                    <th className="text-right py-2 px-2">Correct</th>
                    <th className="text-right py-2 px-2">Accuracy</th>
                  </tr>
                </thead>
                <tbody>
                  {comparisonStats.confidenceRanges.map((range) => (
                    <tr key={range.range} className="border-b hover:bg-muted/50">
                      <td className="py-2 px-2 font-medium">{range.range}</td>
                      <td className="text-right py-2 px-2">{range.totalPredictions}</td>
                      <td className="text-right py-2 px-2">{range.correctPredictions}</td>
                      <td className="text-right py-2 px-2 font-semibold">
                        {Math.round(range.accuracy * 10) / 10}%
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        {/* Insights */}
        <Card className="mt-8 bg-blue-50 border-blue-200">
          <CardHeader>
            <CardTitle className="text-blue-900">Key Insights</CardTitle>
          </CardHeader>
          <CardContent className="text-blue-800">
            <ul className="space-y-2">
              {comparisonStats.predictionTypes.length > 0 && (
                <>
                  <li>
                    • Best performing prediction type:{' '}
                    <strong>
                      {
                        comparisonStats.predictionTypes.reduce((best, current) =>
                          current.accuracy > best.accuracy ? current : best
                        )?.type.replace('_', ' ').toUpperCase()
                      }
                    </strong>{' '}
                    with{' '}
                    <strong>
                      {Math.round(
                        Math.max(...comparisonStats.predictionTypes.map((t) => t.accuracy)) * 10
                      ) / 10}
                      %
                    </strong>{' '}
                    accuracy
                  </li>
                  <li>
                    • Average confidence across all predictions:{' '}
                    <strong>
                      {Math.round(
                        (comparisonStats.predictionTypes.reduce((sum, t) => sum + t.averageConfidence, 0) /
                          comparisonStats.predictionTypes.length) *
                          10
                      ) / 10}
                      %
                    </strong>
                  </li>
                </>
              )}
              {comparisonStats.confidenceRanges.length > 0 && (
                <li>
                  • Highest accuracy confidence range:{' '}
                  <strong>
                    {
                      comparisonStats.confidenceRanges.reduce((best, current) =>
                        current.accuracy > best.accuracy ? current : best
                      )?.range
                    }
                  </strong>{' '}
                  with{' '}
                  <strong>
                    {Math.round(
                      Math.max(...comparisonStats.confidenceRanges.map((r) => r.accuracy)) * 10
                    ) / 10}
                    %
                  </strong>{' '}
                  accuracy
                </li>
              )}
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
