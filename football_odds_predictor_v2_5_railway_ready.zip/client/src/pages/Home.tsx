import { useMemo } from "react";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { AppShell } from "@/components/AppShell";
import { ArrowUpRight, BarChart3, Clock3, Database, TrendingUp, Trophy, Wifi } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";

function pct(v: unknown) { return Number.isFinite(Number(v)) ? `${Number(v).toFixed(1)}%` : "—"; }
function odds(v: unknown) { return Number.isFinite(Number(v)) ? Number(v).toFixed(2) : "—"; }
function risk(v: string | null | undefined) { return (v ?? "medium").toUpperCase(); }

export default function Home() {
  const upcoming = trpc.matches.upcoming.useQuery(undefined, { refetchInterval: 5 * 60 * 1000 });
  const predictions = trpc.predictions.top.useQuery(undefined, { refetchInterval: 5 * 60 * 1000 });
  const performance = trpc.analytics.performance.useQuery({ daysBack: 30 }, { refetchInterval: 15 * 60 * 1000 });

  const nextMatches = upcoming.data ?? [];
  const top = predictions.data ?? [];
  const positive = useMemo(() => top.filter((p: any) => Number(p.expectedValue) > 0).slice(0, 6), [top]);
  const leagues = new Set(nextMatches.map((m: any) => m.league)).size;
  const lastOddsUpdate = nextMatches.map((m: any) => m.odds?.updatedAt).filter(Boolean).sort().at(-1);

  return <AppShell>
    <div className="fi-content">
      <section className="fi-hero">
        <div>
          <div className="fi-eyebrow"><span className="fi-dot"/> LIVE DATA · UPDATED CONTINUOUSLY</div>
          <h1>Football forecasting,<br/><em>measured against the market.</em></h1>
          <p>Independent model probabilities, bookmaker prices, expected value and historical performance in one workspace.</p>
        </div>
        <div className="fi-hero-card">
          <Trophy size={18}/><span>Next monitored match</span>
          {nextMatches[0] ? <strong>{nextMatches[0].homeTeam} <i>vs</i> {nextMatches[0].awayTeam}</strong> : <strong>No live fixture data</strong>}
          {nextMatches[0] && <small>{format(new Date(nextMatches[0].matchDate), "dd MMM · HH:mm")} · {nextMatches[0].league}</small>}
        </div>
      </section>

      <section className="fi-metrics">
        <Metric label="Upcoming matches" value={String(nextMatches.length)} sub={`${leagues} competitions`} icon={<Trophy/>}/>
        <Metric label="Positive EV candidates" value={String(positive.length)} sub="Latest model snapshots" icon={<TrendingUp/>}/>
        <Metric label="30d accuracy" value={performance.data?.totalPredictions ? pct(performance.data.accuracy) : "—"} sub={performance.data?.totalPredictions ? `${performance.data.totalPredictions} evaluated` : "No evaluated history yet"} icon={<BarChartIcon/>}/>
        <Metric label="Data freshness" value={lastOddsUpdate ? format(new Date(lastOddsUpdate), "HH:mm") : "—"} sub={lastOddsUpdate ? "Latest provider snapshot" : "Waiting for real odds"} icon={<Wifi/>}/>
      </section>

      <section className="fi-grid-main">
        <div className="fi-panel">
          <div className="fi-panel-head"><div><span className="fi-section-label">UPCOMING</span><h2>Real fixtures & market prices</h2></div><Link href="/predictions"><Button variant="outline" size="sm">Open predictions <ArrowUpRight size={14}/></Button></Link></div>
          {upcoming.isLoading ? <LoadingRows/> : nextMatches.length === 0 ? <EmptyState title="No real fixtures loaded" text="The application will not invent matches. Configure ODDS_API_KEY and run the ingestion pipeline."/> : <div className="fi-fixtures">{nextMatches.slice(0, 12).map((m: any) => <FixtureRow key={m.id} match={m}/>)}</div>}
        </div>

        <div className="fi-panel">
          <div className="fi-panel-head"><div><span className="fi-section-label">MODEL</span><h2>Best current opportunities</h2></div><span className="fi-live-chip">V2.3</span></div>
          {predictions.isLoading ? <LoadingRows count={4}/> : positive.length === 0 ? <EmptyState title="No positive-EV predictions" text="This is expected when there is no real model edge in the current market."/> : <div>{positive.map((p: any) => <PredictionRow key={p.id} p={p}/>)}</div>}
        </div>
      </section>

      <section className="fi-grid-bottom">
        <div className="fi-panel">
          <div className="fi-panel-head"><div><span className="fi-section-label">MODEL QUALITY</span><h2>Calibration & scoring</h2></div><Link href="/accuracy"><Button variant="ghost" size="sm">Details <ArrowUpRight size={14}/></Button></Link></div>
          <div className="fi-score-grid"><Score label="Brier score" value={performance.data?.totalPredictions ? performance.data.brierScore.toFixed(3) : "—"}/><Score label="Log loss" value={performance.data?.totalPredictions ? performance.data.logLoss.toFixed(3) : "—"}/><Score label="Calibration error" value={performance.data?.totalPredictions ? `${performance.data.calibrationError.toFixed(1)}%` : "—"}/><Score label="ROI" value={performance.data?.totalPredictions ? `${performance.data.roi.toFixed(1)}%` : "—"}/></div>
          <div className="fi-note"><Database size={15}/> Metrics are calculated from settled predictions only.</div>
        </div>
        <div className="fi-panel">
          <div className="fi-panel-head"><div><span className="fi-section-label">PIPELINE</span><h2>Data health</h2></div></div>
          <Health label="The Odds API" status={upcoming.isError ? "ERROR" : nextMatches.length ? "CONNECTED" : "WAITING"} detail="Upcoming events + bookmaker odds"/>
          <Health label="API-Football" status="CONNECTED" detail="Fixtures, form and H2H enrichment"/>
          <Health label="Prediction history" status={top.length ? "ACTIVE" : "WAITING"} detail="Immutable model snapshots"/>
          <Health label="Historical archive" status="PARTIAL" detail="Requires paid historical odds access"/>
        </div>
      </section>
    </div>
  </AppShell>;
}

function Metric({label,value,sub,icon}:{label:string;value:string;sub:string;icon:React.ReactNode}) { return <div className="fi-metric"><div className="fi-metric-icon">{icon}</div><span>{label}</span><strong>{value}</strong><small>{sub}</small></div> }
function Score({label,value}:{label:string;value:string}) { return <div><span>{label}</span><strong>{value}</strong></div> }
function Health({label,status,detail}:{label:string;status:string;detail:string}) { const good=status==='CONNECTED'||status==='ACTIVE'; return <div className="fi-health"><span className={good?'fi-health-dot':'fi-health-dot warn'}/><div><b>{label}</b><small>{detail}</small></div><Badge variant="outline">{status}</Badge></div> }
function FixtureRow({match}:{match:any}) { return <Link href={`/match/${match.id}`} className="fi-fixture"><div><b>{match.homeTeam}</b><span>vs</span><b>{match.awayTeam}</b><small>{match.league} · {format(new Date(match.matchDate), "dd MMM · HH:mm")}</small></div><div className="fi-odds"><span>H <b>{odds(match.odds?.bestHome)}</b></span><span>D <b>{odds(match.odds?.bestDraw)}</b></span><span>A <b>{odds(match.odds?.bestAway)}</b></span></div><div className="fi-book">{match.odds?.bookmakerCount ?? 0} books</div></Link> }
function PredictionRow({p}:{p:any}) { const m=p.match; const prob=p.normalizedProbabilities; return <Link href={`/match/${p.matchId}`} className="fi-prediction"><div><b>{m?.homeTeam ?? "—"} <span>vs</span> {m?.awayTeam ?? "—"}</b><small>{m?.league ?? "Unknown"} · {p.modelVersion}</small></div><div><small>MODEL</small><strong>{p.prediction==='home_win'?pct(prob?.homeWin):p.prediction==='draw'?pct(prob?.draw):pct(prob?.awayWin)}</strong></div><div><small>EV</small><strong className="positive">{Number(p.expectedValue)>0?`+${(Number(p.expectedValue)*100).toFixed(1)}%`:"—"}</strong></div><Badge variant="outline">{risk(p.riskLevel)}</Badge></Link> }
function EmptyState({title,text}:{title:string;text:string}) { return <div className="fi-empty"><Clock3 size={18}/><b>{title}</b><p>{text}</p></div> }
function LoadingRows({count=5}:{count?:number}) { return <div className="fi-loading">{Array.from({length:count}).map((_,i)=><div key={i}/>)}</div> }
function BarChartIcon(){return <BarChart3/>}
