import { Link, useRoute } from "wouter";
import { trpc } from "@/lib/trpc";
import { AppShell } from "@/components/AppShell";
import { ArrowLeft, ArrowUpRight, Clock3, Database, LineChart, ShieldCheck } from "lucide-react";
import { format } from "date-fns";
import { Badge } from "@/components/ui/badge";

export default function MatchLab() {
  const [, params] = useRoute("/match/:id");
  const id = Number(params?.id);
  const { data, isLoading, error } = trpc.matches.byId.useQuery({ id }, { enabled: Number.isInteger(id) });
  const { data: predictions } = trpc.predictions.forMatch.useQuery({ matchId: id }, { enabled: Number.isInteger(id) });
  const match = data?.match;
  const latest = predictions?.slice().sort((a,b)=>new Date(b.generatedAt).getTime()-new Date(a.generatedAt).getTime())[0];
  const history = data?.oddsHistory ?? [];
  const latestByBook = new Map<string, any>();
  for (const row of history) { const old=latestByBook.get(row.bookmaker); if(!old || new Date(row.sourceUpdatedAt ?? row.recordedAt).getTime()>new Date(old.sourceUpdatedAt ?? old.recordedAt).getTime()) latestByBook.set(row.bookmaker,row); }
  const books=Array.from(latestByBook.values());
  const best=(key:string)=>books.reduce<number|null>((best,row)=>{const n=Number(row[key]);return Number.isFinite(n)&&n>1&&(best===null||n>best)?n:best},null);
  if (isLoading) return <AppShell><div className="fi-content"><div className="fi-empty">Loading match intelligence…</div></div></AppShell>;
  if (error || !match) return <AppShell><div className="fi-content"><Link href="/" className="fi-back"><ArrowLeft size={15}/> Back to dashboard</Link><div className="fi-empty"><b>Match not available</b><p>This match is not present in the real-data store.</p></div></div></AppShell>;
  return <AppShell><div className="fi-content">
    <Link href="/" className="fi-back"><ArrowLeft size={15}/> Dashboard</Link>
    <div className="fi-match-hero"><div><span className="fi-section-label">MATCH LAB · REAL DATA</span><h1>{match.homeTeam} <em>vs</em> {match.awayTeam}</h1><p>{match.league} · {format(new Date(match.matchDate), "EEEE, dd MMMM yyyy · HH:mm")}</p></div><div className="fi-match-status"><span className="fi-dot"/> {match.status?.toUpperCase()}</div></div>
    <div className="fi-grid-main">
      <div className="fi-panel"><div className="fi-panel-head"><div><span className="fi-section-label">MODEL SNAPSHOT</span><h2>Probability vs market</h2></div>{latest && <Badge variant="outline">{latest.modelVersion}</Badge>}</div>
        {latest ? <><div className="fi-probability-grid"><Prob label="HOME" model={latest.homeProbability} market={latest.marketHomeProbability}/><Prob label="DRAW" model={latest.drawProbability} market={latest.marketDrawProbability}/><Prob label="AWAY" model={latest.awayProbability} market={latest.marketAwayProbability}/></div><div className="fi-value-strip"><div><span>Expected value</span><strong>{Number(latest.expectedValue)>0?`+${(Number(latest.expectedValue)*100).toFixed(2)}%`:`${(Number(latest.expectedValue)*100).toFixed(2)}%`}</strong></div><div><span>Risk</span><strong>{latest.riskLevel?.toUpperCase()}</strong></div><div><span>As of</span><strong>{format(new Date(latest.asOf),"HH:mm:ss")}</strong></div></div></> : <div className="fi-empty"><b>No prediction yet</b><p>The match has real market data but no model snapshot has been generated.</p></div>}
      </div>
      <div className="fi-panel"><div className="fi-panel-head"><div><span className="fi-section-label">BOOKMAKERS</span><h2>Best available prices</h2></div></div><Odds label="Home" value={best("homeWinOdds")}/><Odds label="Draw" value={best("drawOdds")}/><Odds label="Away" value={best("awayWinOdds")}/><div className="fi-note"><Database size={15}/> {books.length} bookmaker snapshots in the latest market state.</div></div>
    </div>
    <div className="fi-grid-bottom"><div className="fi-panel"><div className="fi-panel-head"><div><span className="fi-section-label">MARKET HISTORY</span><h2>Odds movement</h2></div><LineChart size={18}/></div><div className="fi-history">{history.slice(-12).map((r:any)=><div key={r.id}><span>{r.bookmaker}</span><b>{r.homeWinOdds}</b><b>{r.drawOdds}</b><b>{r.awayWinOdds}</b><small>{format(new Date(r.sourceUpdatedAt ?? r.recordedAt),"HH:mm")}</small></div>)}</div></div>
      <div className="fi-panel"><div className="fi-panel-head"><div><span className="fi-section-label">EXPLANATION</span><h2>Model factors</h2></div><ShieldCheck size={18}/></div>{latest ? <><Factor label="Home form" value={latest.homeFormScore}/><Factor label="Away form" value={latest.awayFormScore}/><Factor label="H2H advantage" value={latest.h2hAdvantage}/><Factor label="Bookmaker disagreement" value={latest.bookmakerDisagreement}/><div className="fi-note">AI reasoning is an explanation layer. It does not determine the model probability.</div></> : <div className="fi-empty">Awaiting model snapshot.</div>}</div>
    </div>
  </div></AppShell>;
}
function Prob({label,model,market}:{label:string;model:any;market:any}){return <div className="fi-prob"><span>{label}</span><strong>{model!=null?`${Number(model).toFixed(1)}%`:"—"}</strong><small>Market {market!=null?`${Number(market).toFixed(1)}%`:"—"}</small><div className="fi-prob-bar"><i style={{width:`${Math.min(100,Math.max(0,Number(model)||0))}%`}}/></div></div>}
function Odds({label,value}:{label:string;value:number|null}){return <div className="fi-odds-line"><span>{label}</span><strong>{value?value.toFixed(2):"—"}</strong></div>}
function Factor({label,value}:{label:string;value:any}){return <div className="fi-factor"><span>{label}</span><strong>{value==null?"—":value}</strong></div>}
