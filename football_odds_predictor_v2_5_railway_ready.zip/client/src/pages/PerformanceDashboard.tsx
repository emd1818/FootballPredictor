import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { trpc } from '@/lib/trpc';
import { TrendingUp, Target, Award, Zap } from 'lucide-react';

export default function PerformanceDashboard() {
  const [daysBack, setDaysBack] = useState(30);

  // Fetch performance metrics
  const { data: metrics, isLoading: metricsLoading } = trpc.analytics.performance.useQuery({ daysBack });
  const { data: leagueAccuracy, isLoading: leagueLoading } = trpc.analytics.accuracyByLeague.useQuery({ daysBack });
  const { data: predictionTypeAccuracy, isLoading: typeLoading } = trpc.analytics.accuracyByPredictionType.useQuery({ daysBack });

  const isLoading = metricsLoading || leagueLoading || typeLoading;

  const COLORS = ['#3b82f6', '#ef4444', '#10b981', '#f59e0b', '#8b5cf6', '#ec4899'];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-slate-900 mb-2">Performance Dashboard</h1>
          <p className="text-slate-600">Track the accuracy and performance of AI-powered predictions</p>
        </div>

        {/* Time Range Selector */}
        <div className="mb-6 flex gap-2">
          {[7, 14, 30, 60, 90].map((days) => (
            <Button
              key={days}
              variant={daysBack === days ? 'default' : 'outline'}
              onClick={() => setDaysBack(days)}
              size="sm"
            >
              {days}d
            </Button>
          ))}
        </div>

        {isLoading ? (
          <div className="text-center py-12">
            <p className="text-slate-600">Loading performance metrics...</p>
          </div>
        ) : metrics ? (
          <>
            {/* Key Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
              <Card className="p-6 bg-white">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-slate-600 mb-1">Total Predictions</p>
                    <p className="text-3xl font-bold text-slate-900">{metrics.totalPredictions}</p>
                  </div>
                  <Target className="h-10 w-10 text-blue-500" />
                </div>
              </Card>

              <Card className="p-6 bg-white">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-slate-600 mb-1">Accuracy Rate</p>
                    <div className="flex items-baseline gap-2">
                      <p className="text-3xl font-bold text-slate-900">{metrics.accuracy.toFixed(1)}%</p>
                      <Badge variant={metrics.accuracy > 55 ? 'default' : 'secondary'}>
                        {metrics.accuracy > 55 ? '+' : ''}{(metrics.accuracy - 50).toFixed(1)}%
                      </Badge>
                    </div>
                  </div>
                  <Award className="h-10 w-10 text-green-500" />
                </div>
              </Card>

              <Card className="p-6 bg-white">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-slate-600 mb-1">Correct Predictions</p>
                    <p className="text-3xl font-bold text-slate-900">{metrics.correctPredictions}</p>
                    <p className="text-xs text-slate-500 mt-1">
                      {metrics.totalPredictions > 0 
                        ? `${((metrics.correctPredictions / metrics.totalPredictions) * 100).toFixed(1)}% hit rate`
                        : 'N/A'}
                    </p>
                  </div>
                  <TrendingUp className="h-10 w-10 text-purple-500" />
                </div>
              </Card>

              <Card className="p-6 bg-white">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-slate-600 mb-1">Avg Confidence</p>
                    <p className="text-3xl font-bold text-slate-900">{metrics.averageConfidence.toFixed(1)}%</p>
                    <p className="text-xs text-slate-500 mt-1">Model confidence level</p>
                  </div>
                  <Zap className="h-10 w-10 text-yellow-500" />
                </div>
              </Card>
            </div>

            {/* Charts */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
              {/* Daily Performance Chart */}
              <Card className="p-6 bg-white">
                <h3 className="text-lg font-semibold text-slate-900 mb-4">Daily Performance</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={metrics.recentPerformance}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                    <XAxis 
                      dataKey="date" 
                      stroke="#94a3b8"
                      style={{ fontSize: '12px' }}
                    />
                    <YAxis stroke="#94a3b8" style={{ fontSize: '12px' }} />
                    <Tooltip 
                      contentStyle={{ backgroundColor: '#fff', border: '1px solid #e2e8f0' }}
                      formatter={(value) => typeof value === 'number' ? value.toFixed(1) : value}
                    />
                    <Legend />
                    <Line 
                      type="monotone" 
                      dataKey="accuracy" 
                      stroke="#3b82f6" 
                      dot={false}
                      name="Accuracy %"
                    />
                  </LineChart>
                </ResponsiveContainer>
              </Card>

              {/* Confidence Bucket Analysis */}
              <Card className="p-6 bg-white">
                <h3 className="text-lg font-semibold text-slate-900 mb-4">Accuracy by Confidence</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={metrics.predictionsByConfidence}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                    <XAxis 
                      dataKey="bucket" 
                      stroke="#94a3b8"
                      style={{ fontSize: '12px' }}
                    />
                    <YAxis stroke="#94a3b8" style={{ fontSize: '12px' }} />
                    <Tooltip 
                      contentStyle={{ backgroundColor: '#fff', border: '1px solid #e2e8f0' }}
                      formatter={(value) => typeof value === 'number' ? value.toFixed(1) : value}
                    />
                    <Legend />
                    <Bar 
                      dataKey="accuracy" 
                      fill="#10b981" 
                      name="Accuracy %"
                      radius={[8, 8, 0, 0]}
                    />
                  </BarChart>
                </ResponsiveContainer>
              </Card>
            </div>

            {/* League and Prediction Type Analysis */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Accuracy by League */}
              {leagueAccuracy && leagueAccuracy.length > 0 && (
                <Card className="p-6 bg-white">
                  <h3 className="text-lg font-semibold text-slate-900 mb-4">Accuracy by League</h3>
                  <div className="space-y-3">
                    {leagueAccuracy.map((league) => (
                      <div key={league.league} className="flex items-center justify-between">
                        <div className="flex-1">
                          <p className="text-sm font-medium text-slate-900">{league.league}</p>
                          <p className="text-xs text-slate-500">{league.predictions} predictions</p>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="w-32 bg-slate-200 rounded-full h-2">
                            <div
                              className="bg-blue-500 h-2 rounded-full"
                              style={{ width: `${league.accuracy}%` }}
                            />
                          </div>
                          <span className="text-sm font-semibold text-slate-900 w-12 text-right">
                            {league.accuracy.toFixed(1)}%
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </Card>
              )}

              {/* Accuracy by Prediction Type */}
              {predictionTypeAccuracy && predictionTypeAccuracy.length > 0 && (
                <Card className="p-6 bg-white">
                  <h3 className="text-lg font-semibold text-slate-900 mb-4">Accuracy by Prediction Type</h3>
                  <ResponsiveContainer width="100%" height={250}>
                    <PieChart>
                      <Pie
                        data={predictionTypeAccuracy}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ type, accuracy }) => `${type}: ${accuracy.toFixed(0)}%`}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="accuracy"
                      >
                        {predictionTypeAccuracy.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => typeof value === 'number' ? value.toFixed(1) : value} />
                    </PieChart>
                  </ResponsiveContainer>
                  <div className="mt-4 space-y-2">
                    {predictionTypeAccuracy.map((type, index) => (
                      <div key={type.type} className="flex items-center gap-2">
                        <div 
                          className="w-3 h-3 rounded-full"
                          style={{ backgroundColor: COLORS[index % COLORS.length] }}
                        />
                        <span className="text-sm text-slate-600">
                          {type.type}: {type.predictions} predictions
                        </span>
                      </div>
                    ))}
                  </div>
                </Card>
              )}
            </div>
          </>
        ) : (
          <div className="text-center py-12">
            <p className="text-slate-600">No performance data available yet. Predictions will appear here once matches are completed.</p>
          </div>
        )}
      </div>
    </div>
  );
}
