import { trpc } from '@/lib/trpc';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { TrendingUp, TrendingDown, AlertCircle } from 'lucide-react';
import { format } from 'date-fns';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';

export default function PredictionsDashboard() {
  const { data: predictions, isLoading, error } = trpc.predictions.top.useQuery();
  const [, navigate] = useLocation();

  if (error) {
    return (
      <div className="min-h-screen bg-background">
        {/* Navigation */}
        <nav className="border-b border-border bg-background/80 backdrop-blur-sm sticky top-0 z-50">
          <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-6 h-6 text-primary" />
              <h1 className="text-xl font-bold text-foreground">Football Odds Predictor</h1>
            </div>
            <Button variant="outline" onClick={() => navigate("/")}>
              Home
            </Button>
          </div>
        </nav>

        <div className="max-w-7xl mx-auto px-6 py-6">
          <div className="flex items-center gap-2 text-destructive">
            <AlertCircle className="w-5 h-5" />
            <p>Failed to load predictions. Please try again later.</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="border-b border-border bg-background/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-6 h-6 text-primary" />
            <h1 className="text-xl font-bold text-foreground">Football Odds Predictor</h1>
          </div>
          <Button variant="outline" onClick={() => navigate("/")}>
            Home
          </Button>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-6 py-6">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-foreground mb-2">Football Odds Predictions</h1>
          <p className="text-muted-foreground">AI-powered predictions based on odds movement analysis</p>
        </div>

        {/* Predictions Grid */}
        <div className="grid gap-4">
          {isLoading ? (
            // Loading skeletons
            Array.from({ length: 5 }).map((_, i) => (
              <Card key={i}>
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div className="space-y-2 flex-1">
                      <Skeleton className="h-6 w-64" />
                      <Skeleton className="h-4 w-48" />
                    </div>
                    <Skeleton className="h-8 w-20" />
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-4 w-3/4" />
                  </div>
                </CardContent>
              </Card>
            ))
          ) : predictions && predictions.length > 0 ? (
            predictions.map((pred) => (
              <PredictionCard key={pred.id} prediction={pred} />
            ))
          ) : (
            <Card>
              <CardContent className="pt-6">
                <p className="text-center text-muted-foreground">No predictions available yet. Check back soon!</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}

interface PredictionCardProps {
  prediction: any;
}

function PredictionCard({ prediction }: PredictionCardProps) {
  const match = prediction.match;
  
  if (!match) return null;

  const getPredictionColor = (pred: string) => {
    switch (pred) {
      case 'home_win':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200';
      case 'away_win':
        return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200';
      case 'draw':
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getPredictionLabel = (pred: string) => {
    switch (pred) {
      case 'home_win':
        return `${match.homeTeam} Win`;
      case 'away_win':
        return `${match.awayTeam} Win`;
      case 'draw':
        return 'Draw';
      default:
        return pred;
    }
  };

  const confidenceColor = prediction.confidence >= 70 ? 'text-green-600' : prediction.confidence >= 50 ? 'text-yellow-600' : 'text-orange-600';

  return (
    <Card className="hover:shadow-lg transition-shadow">
      <CardHeader>
        <div className="flex justify-between items-start">
          <div className="flex-1">
            <CardTitle className="text-xl">
              {match.homeTeam} vs {match.awayTeam}
            </CardTitle>
            <CardDescription>
              {match.league} • {format(new Date(match.matchDate), 'MMM dd, yyyy HH:mm')}
            </CardDescription>
          </div>
          <Badge className={getPredictionColor(prediction.prediction)}>
            {getPredictionLabel(prediction.prediction)}
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {/* Confidence Score */}
          <div>
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-medium text-foreground">Confidence</span>
              <span className={`text-lg font-bold ${confidenceColor}`}>{prediction.confidence}%</span>
            </div>
            <div className="w-full bg-muted rounded-full h-2">
              <div
                className="bg-gradient-to-r from-blue-500 to-purple-500 h-2 rounded-full transition-all"
                style={{ width: `${prediction.confidence}%` }}
              />
            </div>
          </div>

          {/* Scores */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground flex items-center gap-1">
                <TrendingUp className="w-3 h-3" /> Odds Movement
              </p>
              <p className="text-lg font-semibold text-foreground">{prediction.oddsMovementScore}%</p>
            </div>
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground flex items-center gap-1">
                <TrendingDown className="w-3 h-3" /> Volatility
              </p>
              <p className="text-lg font-semibold text-foreground">{prediction.volatilityScore}%</p>
            </div>
          </div>

          {/* Reasoning */}
          {prediction.reasoning && (
            <div className="bg-muted p-3 rounded-md">
              <p className="text-sm text-foreground">{prediction.reasoning}</p>
            </div>
          )}

          {/* Generated At */}
          <p className="text-xs text-muted-foreground">
            Generated {format(new Date(prediction.generatedAt), 'MMM dd, yyyy HH:mm')}
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
