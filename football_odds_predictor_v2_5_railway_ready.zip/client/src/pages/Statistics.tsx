import { useEffect, useState } from 'react';
import { trpc } from '@/lib/trpc';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

export function Statistics() {
  const [daysBack, setDaysBack] = useState(30);
  const { data: stats, isLoading, error } = trpc.analytics.statistics.useQuery({ daysBack });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p>Loading statistics...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Card className="border-destructive">
          <CardHeader>
            <CardTitle className="text-destructive">Error Loading Statistics</CardTitle>
          </CardHeader>
          <CardContent>
            <p>{error.message}</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!stats) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Card>
          <CardHeader>
            <CardTitle>No Data Available</CardTitle>
          </CardHeader>
          <CardContent>
            <p>No predictions have been evaluated yet. Check back later!</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const predictionTypeData = [
    { name: 'Home Win', value: stats.byPredictionType.homeWin.accuracy, count: stats.byPredictionType.homeWin.total },
    { name: 'Draw', value: stats.byPredictionType.draw.accuracy, count: stats.byPredictionType.draw.total },
    { name: 'Away Win', value: stats.byPredictionType.awayWin.accuracy, count: stats.byPredictionType.awayWin.total },
  ];

  const COLORS = ['#3b82f6', '#8b5cf6', '#ec4899'];

  return (
    <div className="min-h-screen bg-background p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">Prediction Statistics</h1>
          <p className="text-muted-foreground">Analyze the accuracy and performance of our AI predictions</p>
        </div>

        {/* Time Period Selector */}
        <div className="mb-8 flex gap-2">
          {[7, 14, 30, 60, 90].map((days) => (
            <button
              key={days}
              onClick={() => setDaysBack(days)}
              className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                daysBack === days
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-muted text-muted-foreground hover:bg-muted/80'
              }`}
            >
              {days}d
            </button>
          ))}
        </div>

        {/* Overall Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Overall Accuracy</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{stats.accuracyPercentage}%</div>
              <p className="text-xs text-muted-foreground mt-1">
                {stats.correctPredictions} of {stats.totalPredictions} correct
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Predictions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{stats.totalPredictions}</div>
              <p className="text-xs text-muted-foreground mt-1">
                {stats.correctPredictions} successful predictions
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Success Rate</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{stats.correctPredictions}/{stats.totalPredictions}</div>
              <p className="text-xs text-muted-foreground mt-1">
                {stats.totalPredictions > 0 ? Math.round((stats.correctPredictions / stats.totalPredictions) * 100) : 0}% win rate
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Accuracy by Prediction Type */}
          <Card>
            <CardHeader>
              <CardTitle>Accuracy by Prediction Type</CardTitle>
              <CardDescription>Performance breakdown by prediction outcome</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={predictionTypeData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis domain={[0, 100]} />
                  <Tooltip formatter={(value) => `${value}%`} />
                  <Bar dataKey="value" fill="#3b82f6" name="Accuracy %" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Accuracy by Confidence Bucket */}
          <Card>
            <CardHeader>
              <CardTitle>Accuracy by Confidence Level</CardTitle>
              <CardDescription>How accuracy correlates with confidence score</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={stats.byConfidenceBucket}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="bucket" />
                  <YAxis domain={[0, 100]} />
                  <Tooltip formatter={(value) => `${value}%`} />
                  <Bar dataKey="accuracy" fill="#8b5cf6" name="Accuracy %" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* League Performance */}
        <Card>
          <CardHeader>
            <CardTitle>Performance by League</CardTitle>
            <CardDescription>Accuracy across different football leagues</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="border-b">
                  <tr>
                    <th className="text-left py-2 px-4 font-semibold">League</th>
                    <th className="text-center py-2 px-4 font-semibold">Predictions</th>
                    <th className="text-center py-2 px-4 font-semibold">Correct</th>
                    <th className="text-center py-2 px-4 font-semibold">Accuracy</th>
                  </tr>
                </thead>
                <tbody>
                  {stats.byLeague.map((league) => (
                    <tr key={league.league} className="border-b hover:bg-muted/50">
                      <td className="py-2 px-4">{league.league}</td>
                      <td className="text-center py-2 px-4">{league.total}</td>
                      <td className="text-center py-2 px-4">{league.correct}</td>
                      <td className="text-center py-2 px-4">
                        <span className={`font-semibold ${league.accuracy >= 50 ? 'text-green-600' : 'text-red-600'}`}>
                          {league.accuracy}%
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        {/* Prediction Type Details */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-8">
          {[
            { type: 'Home Win', data: stats.byPredictionType.homeWin, color: '#3b82f6' },
            { type: 'Draw', data: stats.byPredictionType.draw, color: '#8b5cf6' },
            { type: 'Away Win', data: stats.byPredictionType.awayWin, color: '#ec4899' },
          ].map((item) => (
            <Card key={item.type}>
              <CardHeader>
                <CardTitle className="text-base">{item.type}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div>
                    <p className="text-sm text-muted-foreground">Total Predictions</p>
                    <p className="text-2xl font-bold">{item.data.total}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Correct</p>
                    <p className="text-2xl font-bold text-green-600">{item.data.correct}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Accuracy</p>
                    <p className="text-2xl font-bold" style={{ color: item.color }}>
                      {item.data.accuracy}%
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
