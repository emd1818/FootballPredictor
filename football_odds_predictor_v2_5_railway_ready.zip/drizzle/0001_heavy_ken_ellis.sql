CREATE TABLE `dataSources` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(128) NOT NULL,
	`source` varchar(128) NOT NULL,
	`lastFetchedAt` timestamp,
	`status` enum('active','inactive','error') DEFAULT 'active',
	`errorMessage` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `dataSources_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `matches` (
	`id` int AUTO_INCREMENT NOT NULL,
	`externalId` varchar(128) NOT NULL,
	`homeTeam` varchar(128) NOT NULL,
	`awayTeam` varchar(128) NOT NULL,
	`league` varchar(128) NOT NULL,
	`matchDate` timestamp NOT NULL,
	`status` enum('upcoming','live','finished','cancelled') DEFAULT 'upcoming',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `matches_id` PRIMARY KEY(`id`),
	CONSTRAINT `matches_externalId_unique` UNIQUE(`externalId`)
);
--> statement-breakpoint
CREATE TABLE `oddsHistory` (
	`id` int AUTO_INCREMENT NOT NULL,
	`matchId` int NOT NULL,
	`homeWinOdds` varchar(32) NOT NULL,
	`drawOdds` varchar(32) NOT NULL,
	`awayWinOdds` varchar(32) NOT NULL,
	`homeWinMovement` varchar(32),
	`drawMovement` varchar(32),
	`awayWinMovement` varchar(32),
	`bookmaker` varchar(128) NOT NULL,
	`recordedAt` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `oddsHistory_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `predictions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`matchId` int NOT NULL,
	`prediction` enum('home_win','draw','away_win') NOT NULL,
	`confidence` int NOT NULL,
	`reasoning` text,
	`oddsMovementScore` int,
	`volatilityScore` int,
	`aiModel` varchar(64) DEFAULT 'v1',
	`generatedAt` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `predictions_id` PRIMARY KEY(`id`)
);
