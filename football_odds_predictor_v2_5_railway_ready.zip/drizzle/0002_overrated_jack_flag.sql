CREATE TABLE `notificationPreferences` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`confidenceThreshold` int NOT NULL DEFAULT 75,
	`enableEmailNotifications` int NOT NULL DEFAULT 1,
	`enableInAppNotifications` int NOT NULL DEFAULT 1,
	`preferredLeagues` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `notificationPreferences_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `notifications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`predictionId` int NOT NULL,
	`matchId` int NOT NULL,
	`title` varchar(255) NOT NULL,
	`message` text NOT NULL,
	`confidence` int NOT NULL,
	`prediction` enum('home_win','draw','away_win') NOT NULL,
	`isRead` int NOT NULL DEFAULT 0,
	`notificationType` enum('email','in_app','both') NOT NULL DEFAULT 'both',
	`sentAt` timestamp NOT NULL DEFAULT (now()),
	`readAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `notifications_id` PRIMARY KEY(`id`)
);
