CREATE TABLE `matchResults` (
	`id` int AUTO_INCREMENT NOT NULL,
	`matchId` int NOT NULL,
	`result` enum('home_win','draw','away_win') NOT NULL,
	`homeScore` int,
	`awayScore` int,
	`resultRecordedAt` timestamp NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `matchResults_id` PRIMARY KEY(`id`),
	CONSTRAINT `matchResults_matchId_unique` UNIQUE(`matchId`)
);
--> statement-breakpoint
CREATE TABLE `predictionAccuracy` (
	`id` int AUTO_INCREMENT NOT NULL,
	`predictionId` int NOT NULL,
	`matchId` int NOT NULL,
	`prediction` enum('home_win','draw','away_win') NOT NULL,
	`confidence` int NOT NULL,
	`actualResult` enum('home_win','draw','away_win') NOT NULL,
	`isCorrect` int NOT NULL,
	`confidenceBucket` varchar(32) NOT NULL,
	`evaluatedAt` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `predictionAccuracy_id` PRIMARY KEY(`id`)
);
