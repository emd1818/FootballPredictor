ALTER TABLE `matches` ADD `homeTeamId` int;--> statement-breakpoint
ALTER TABLE `matches` ADD `awayTeamId` int;--> statement-breakpoint
ALTER TABLE `matches` ADD `leagueId` int;