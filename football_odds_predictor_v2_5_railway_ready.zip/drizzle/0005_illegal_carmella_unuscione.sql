ALTER TABLE `predictions` ADD `homeFormScore` int DEFAULT 50;--> statement-breakpoint
ALTER TABLE `predictions` ADD `awayFormScore` int DEFAULT 50;--> statement-breakpoint
ALTER TABLE `predictions` ADD `h2hAdvantage` int DEFAULT 0;--> statement-breakpoint
ALTER TABLE `predictions` ADD `riskLevel` enum('low','medium','high') DEFAULT 'medium';--> statement-breakpoint
ALTER TABLE `predictions` ADD `valueScore` int DEFAULT 50;--> statement-breakpoint
ALTER TABLE `predictions` ADD `keyInsights` text;--> statement-breakpoint
ALTER TABLE `predictions` ADD `bookmakerDisagreement` int DEFAULT 0;