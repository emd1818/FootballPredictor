ALTER TABLE `predictions` ADD `homeWinOdds` varchar(32) DEFAULT '2.00';--> statement-breakpoint
ALTER TABLE `predictions` ADD `drawOdds` varchar(32) DEFAULT '3.00';--> statement-breakpoint
ALTER TABLE `predictions` ADD `awayWinOdds` varchar(32) DEFAULT '3.50';