ALTER TABLE `predictions` DROP COLUMN `homeFormScore`;--> statement-breakpoint
ALTER TABLE `predictions` DROP COLUMN `awayFormScore`;--> statement-breakpoint
ALTER TABLE `predictions` DROP COLUMN `h2hAdvantage`;--> statement-breakpoint
ALTER TABLE `predictions` DROP COLUMN `valueScore`;