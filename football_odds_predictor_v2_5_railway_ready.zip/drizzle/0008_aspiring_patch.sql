ALTER TABLE `predictions` ADD `homeFormScore` int;--> statement-breakpoint
ALTER TABLE `predictions` ADD `awayFormScore` int;--> statement-breakpoint
ALTER TABLE `predictions` ADD `h2hAdvantage` int;