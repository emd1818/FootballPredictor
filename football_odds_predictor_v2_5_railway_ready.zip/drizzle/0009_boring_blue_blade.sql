ALTER TABLE `predictions` ADD `recentFormHome` varchar(32);--> statement-breakpoint
ALTER TABLE `predictions` ADD `recentFormAway` varchar(32);