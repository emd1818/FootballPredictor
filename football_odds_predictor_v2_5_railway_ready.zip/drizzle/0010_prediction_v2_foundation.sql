-- Prediction V2 foundation: immutable model snapshots, probability metrics and safe indexes.
ALTER TABLE `predictions`
  ADD `modelVersion` varchar(32) NOT NULL DEFAULT 'v2',
  ADD `homeProbability` decimal(7,4),
  ADD `drawProbability` decimal(7,4),
  ADD `awayProbability` decimal(7,4),
  ADD `marketHomeProbability` decimal(7,4),
  ADD `marketDrawProbability` decimal(7,4),
  ADD `marketAwayProbability` decimal(7,4),
  ADD `expectedValue` decimal(8,5),
  ADD `valueFlag` int NOT NULL DEFAULT 0,
  ADD `asOf` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP;

CREATE INDEX `odds_match_recorded_idx` ON `oddsHistory` (`matchId`, `recordedAt`);
CREATE INDEX `odds_bookmaker_match_idx` ON `oddsHistory` (`bookmaker`, `matchId`);
CREATE INDEX `predictions_match_generated_idx` ON `predictions` (`matchId`, `generatedAt`);
CREATE INDEX `predictions_model_idx` ON `predictions` (`modelVersion`);

ALTER TABLE `predictionAccuracy`
  ADD `predictedProbability` decimal(7,4),
  ADD `brierScore` decimal(8,6),
  ADD `logLoss` decimal(8,6),
  ADD `oddsAtPrediction` decimal(7,3),
  ADD `expectedValue` decimal(8,5),
  ADD `profitUnits` decimal(8,5);

-- Remove duplicate evaluations before enforcing the one-evaluation-per-snapshot rule.
DELETE pa1 FROM `predictionAccuracy` pa1
INNER JOIN `predictionAccuracy` pa2
  ON pa1.`predictionId` = pa2.`predictionId` AND pa1.`id` > pa2.`id`;
CREATE UNIQUE INDEX `prediction_accuracy_prediction_unique` ON `predictionAccuracy` (`predictionId`);

-- A user has one notification-preference record.
DELETE np1 FROM `notificationPreferences` np1
INNER JOIN `notificationPreferences` np2
  ON np1.`userId` = np2.`userId` AND np1.`id` > np2.`id`;
CREATE UNIQUE INDEX `notification_preferences_user_unique` ON `notificationPreferences` (`userId`);
