-- Provider timestamp makes odds ingestion idempotent and preserves the real source update time.
ALTER TABLE `oddsHistory` ADD `sourceUpdatedAt` timestamp NULL;
CREATE INDEX `odds_source_updated_idx` ON `oddsHistory` (`matchId`, `bookmaker`, `sourceUpdatedAt`);
