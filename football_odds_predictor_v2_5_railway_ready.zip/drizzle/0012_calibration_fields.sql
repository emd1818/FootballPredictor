ALTER TABLE `predictions` ADD `calibrationTemperature` decimal(5,3) DEFAULT 1.000;
ALTER TABLE `predictions` ADD `calibrationSamples` int NOT NULL DEFAULT 0;
