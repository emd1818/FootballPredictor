import { decimal, index, int, mysqlEnum, mysqlTable, text, timestamp, uniqueIndex, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const matches = mysqlTable("matches", {
  id: int("id").autoincrement().primaryKey(),
  externalId: varchar("externalId", { length: 128 }).notNull().unique(),
  homeTeam: varchar("homeTeam", { length: 128 }).notNull(),
  awayTeam: varchar("awayTeam", { length: 128 }).notNull(),
  league: varchar("league", { length: 128 }).notNull(),
  matchDate: timestamp("matchDate").notNull(),
  homeTeamId: int("homeTeamId"), // API-Football team ID
  awayTeamId: int("awayTeamId"), // API-Football team ID
  leagueId: int("leagueId"), // API-Football league ID
  status: mysqlEnum("status", ["upcoming", "live", "finished", "cancelled"]).default("upcoming"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Match = typeof matches.$inferSelect;
export type InsertMatch = typeof matches.$inferInsert;

export const oddsHistory = mysqlTable("oddsHistory", {
  id: int("id").autoincrement().primaryKey(),
  matchId: int("matchId").notNull(),
  homeWinOdds: varchar("homeWinOdds", { length: 32 }).notNull(),
  drawOdds: varchar("drawOdds", { length: 32 }).notNull(),
  awayWinOdds: varchar("awayWinOdds", { length: 32 }).notNull(),
  homeWinMovement: varchar("homeWinMovement", { length: 32 }), // percentage change
  drawMovement: varchar("drawMovement", { length: 32 }),
  awayWinMovement: varchar("awayWinMovement", { length: 32 }),
  bookmaker: varchar("bookmaker", { length: 128 }).notNull(),
  sourceUpdatedAt: timestamp("sourceUpdatedAt"), // provider timestamp used for idempotent ingestion
  recordedAt: timestamp("recordedAt").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [
  index("odds_match_recorded_idx").on(table.matchId, table.recordedAt),
  index("odds_bookmaker_match_idx").on(table.bookmaker, table.matchId),
  index("odds_source_updated_idx").on(table.matchId, table.bookmaker, table.sourceUpdatedAt),
]);

export type OddsHistory = typeof oddsHistory.$inferSelect;
export type InsertOddsHistory = typeof oddsHistory.$inferInsert;

export const predictions = mysqlTable("predictions", {
  id: int("id").autoincrement().primaryKey(),
  matchId: int("matchId").notNull(),
  prediction: mysqlEnum("prediction", ["home_win", "draw", "away_win"]).notNull(),
  confidence: int("confidence").notNull(), // 0-100 percentage
  reasoning: text("reasoning"),
  oddsMovementScore: int("oddsMovementScore"), // 0-100
  volatilityScore: int("volatilityScore"), // 0-100
  riskLevel: mysqlEnum("riskLevel", ["low", "medium", "high"]).default("medium"),
  homeFormScore: int("homeFormScore"), // 0-100 (real team form from API-Football)
  awayFormScore: int("awayFormScore"), // 0-100 (real team form from API-Football)
  h2hAdvantage: int("h2hAdvantage"), // -100 to +100 (head-to-head advantage)
  recentFormHome: varchar("recentFormHome", { length: 32 }), // e.g., "WWDLW" - last 5 matches
  recentFormAway: varchar("recentFormAway", { length: 32 }), // e.g., "WWDLW" - last 5 matches
  keyInsights: text("keyInsights"), // JSON array of insights
  bookmakerDisagreement: int("bookmakerDisagreement").default(0), // 0-100
  homeWinOdds: varchar("homeWinOdds", { length: 32 }).default("2.00"),
  drawOdds: varchar("drawOdds", { length: 32 }).default("3.00"),
  awayWinOdds: varchar("awayWinOdds", { length: 32 }).default("3.50"),
  aiModel: varchar("aiModel", { length: 64 }).default("v2"),
  modelVersion: varchar("modelVersion", { length: 32 }).default("v2").notNull(),
  homeProbability: decimal("homeProbability", { precision: 7, scale: 4 }),
  drawProbability: decimal("drawProbability", { precision: 7, scale: 4 }),
  awayProbability: decimal("awayProbability", { precision: 7, scale: 4 }),
  marketHomeProbability: decimal("marketHomeProbability", { precision: 7, scale: 4 }),
  marketDrawProbability: decimal("marketDrawProbability", { precision: 7, scale: 4 }),
  marketAwayProbability: decimal("marketAwayProbability", { precision: 7, scale: 4 }),
  expectedValue: decimal("expectedValue", { precision: 8, scale: 5 }),
  valueFlag: int("valueFlag").default(0).notNull(),
  calibrationTemperature: decimal("calibrationTemperature", { precision: 5, scale: 3 }).default("1.000"),
  calibrationSamples: int("calibrationSamples").default(0).notNull(),
  asOf: timestamp("asOf").defaultNow().notNull(),
  generatedAt: timestamp("generatedAt").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [
  index("predictions_match_generated_idx").on(table.matchId, table.generatedAt),
  index("predictions_model_idx").on(table.modelVersion),
]);

export type Prediction = typeof predictions.$inferSelect;
export type InsertPrediction = typeof predictions.$inferInsert;

export const dataSources = mysqlTable("dataSources", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 128 }).notNull(),
  source: varchar("source", { length: 128 }).notNull(), // "oddsportal", "sofascore", "api", etc
  lastFetchedAt: timestamp("lastFetchedAt"),
  status: mysqlEnum("status", ["active", "inactive", "error"]).default("active"),
  errorMessage: text("errorMessage"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type DataSource = typeof dataSources.$inferSelect;
export type InsertDataSource = typeof dataSources.$inferInsert;

export const notificationPreferences = mysqlTable("notificationPreferences", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  confidenceThreshold: int("confidenceThreshold").default(75).notNull(),
  enableEmailNotifications: int("enableEmailNotifications").default(1).notNull(),
  enableInAppNotifications: int("enableInAppNotifications").default(1).notNull(),
  preferredLeagues: text("preferredLeagues"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [uniqueIndex("notification_preferences_user_unique").on(table.userId)]);

export type NotificationPreference = typeof notificationPreferences.$inferSelect;
export type InsertNotificationPreference = typeof notificationPreferences.$inferInsert;

export const notifications = mysqlTable("notifications", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  predictionId: int("predictionId").notNull(),
  matchId: int("matchId").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  message: text("message").notNull(),
  confidence: int("confidence").notNull(),
  prediction: mysqlEnum("prediction", ["home_win", "draw", "away_win"]).notNull(),
  isRead: int("isRead").default(0).notNull(),
  notificationType: mysqlEnum("notificationType", ["email", "in_app", "both"]).default("both").notNull(),
  sentAt: timestamp("sentAt").defaultNow().notNull(),
  readAt: timestamp("readAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = typeof notifications.$inferInsert;

export const matchResults = mysqlTable("matchResults", {
  id: int("id").autoincrement().primaryKey(),
  matchId: int("matchId").notNull().unique(),
  result: mysqlEnum("result", ["home_win", "draw", "away_win"]).notNull(),
  homeScore: int("homeScore"),
  awayScore: int("awayScore"),
  resultRecordedAt: timestamp("resultRecordedAt").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type MatchResult = typeof matchResults.$inferSelect;
export type InsertMatchResult = typeof matchResults.$inferInsert;

export const predictionAccuracy = mysqlTable("predictionAccuracy", {
  id: int("id").autoincrement().primaryKey(),
  predictionId: int("predictionId").notNull(),
  matchId: int("matchId").notNull(),
  prediction: mysqlEnum("prediction", ["home_win", "draw", "away_win"]).notNull(),
  confidence: int("confidence").notNull(),
  actualResult: mysqlEnum("actualResult", ["home_win", "draw", "away_win"]).notNull(),
  isCorrect: int("isCorrect").notNull(), // 1 for correct, 0 for incorrect
  confidenceBucket: varchar("confidenceBucket", { length: 32 }).notNull(),
  predictedProbability: decimal("predictedProbability", { precision: 7, scale: 4 }),
  brierScore: decimal("brierScore", { precision: 8, scale: 6 }),
  logLoss: decimal("logLoss", { precision: 8, scale: 6 }),
  oddsAtPrediction: decimal("oddsAtPrediction", { precision: 7, scale: 3 }),
  expectedValue: decimal("expectedValue", { precision: 8, scale: 5 }),
  profitUnits: decimal("profitUnits", { precision: 8, scale: 5 }),
  evaluatedAt: timestamp("evaluatedAt").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [uniqueIndex("prediction_accuracy_prediction_unique").on(table.predictionId)]);

export type PredictionAccuracy = typeof predictionAccuracy.$inferSelect;
export type InsertPredictionAccuracy = typeof predictionAccuracy.$inferInsert;
