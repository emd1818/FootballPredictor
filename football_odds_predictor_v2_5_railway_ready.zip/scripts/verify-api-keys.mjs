import fs from 'node:fs';

function loadDotEnv(path = '.env') {
  if (!fs.existsSync(path)) return;
  for (const line of fs.readFileSync(path, 'utf8').split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const i = trimmed.indexOf('=');
    if (i <= 0) continue;
    const key = trimmed.slice(0, i).trim();
    const value = trimmed.slice(i + 1).trim().replace(/^['"]|['"]$/g, '');
    if (!process.env[key]) process.env[key] = value;
  }
}
loadDotEnv();

const checks = [
  {
    name: 'The Odds API',
    url: `https://api.the-odds-api.com/v4/sports?apiKey=${process.env.ODDS_API_KEY}`,
    headers: { Accept: 'application/json' },
    ok: r => Array.isArray(r),
  },
  {
    name: 'API-Football',
    url: 'https://v3.football.api-sports.io/status',
    headers: { 'x-apisports-key': process.env.API_FOOTBALL_KEY, Accept: 'application/json' },
    ok: r => !!r?.response,
  },
];

for (const check of checks) {
  try {
    const response = await fetch(check.url, { headers: check.headers });
    const text = await response.text();
    let body;
    try { body = JSON.parse(text); } catch { body = text; }
    console.log(`${check.name}: HTTP ${response.status} ${response.ok && check.ok(body) ? 'OK' : 'FAILED'}`);
    if (!response.ok) console.log(typeof body === 'string' ? body.slice(0, 300) : JSON.stringify(body).slice(0, 500));
  } catch (error) {
    console.log(`${check.name}: NETWORK ERROR — ${error?.message || error}`);
  }
}
