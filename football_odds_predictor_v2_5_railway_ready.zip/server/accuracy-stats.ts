import { getDb } from './db';
import { predictionAccuracy, matchResults } from '../drizzle/schema';
import { eq, and, gte, sql } from 'drizzle-orm';

export interface AccuracyStats {
  totalPredictions: number;
  correctPredictions: number;
  accuracy: number;
  byConfidenceLevel: {
    high: { total: number; correct: number; accuracy: number };
    medium: { total: number; correct: number; accuracy: number };
    low: { total: number; correct: number; accuracy: number };
  };
  byLeague: {
    [league: string]: { total: number; correct: number; accuracy: number };
  };
  roi: number;
  valueBetsAccuracy: number;
}

/**
 * Get overall accuracy statistics
 */
export async function getAccuracyStats(): Promise<AccuracyStats> {
  try {
    // Get all predictions with results
    const db = await getDb();
    if (!db) {
      throw new Error('Database not available');
    }
    const predictions = await db.select().from(predictionAccuracy);

    if (predictions.length === 0) {
      return {
        totalPredictions: 0,
        correctPredictions: 0,
        accuracy: 0,
        byConfidenceLevel: {
          high: { total: 0, correct: 0, accuracy: 0 },
          medium: { total: 0, correct: 0, accuracy: 0 },
          low: { total: 0, correct: 0, accuracy: 0 },
        },
        byLeague: {},
        roi: 0,
        valueBetsAccuracy: 0,
      };
    }

    // Overall stats
    const totalPredictions = predictions.length;
    const correctPredictions = predictions.filter((p: typeof predictions[0]) => p.isCorrect === 1).length;
    const accuracy = (correctPredictions / totalPredictions) * 100;

    // By confidence level
    const highConfidence = predictions.filter((p: typeof predictions[0]) => p.confidence >= 70);
    const mediumConfidence = predictions.filter((p: typeof predictions[0]) => p.confidence >= 40 && p.confidence < 70);
    const lowConfidence = predictions.filter((p: typeof predictions[0]) => p.confidence < 40);

    const byConfidenceLevel = {
      high: {
        total: highConfidence.length,
        correct: highConfidence.filter((p: typeof predictions[0]) => p.isCorrect === 1).length,
        accuracy: highConfidence.length > 0 
          ? (highConfidence.filter((p: typeof predictions[0]) => p.isCorrect === 1).length / highConfidence.length) * 100
          : 0,
      },
      medium: {
        total: mediumConfidence.length,
        correct: mediumConfidence.filter((p: typeof predictions[0]) => p.isCorrect === 1).length,
        accuracy: mediumConfidence.length > 0
          ? (mediumConfidence.filter((p: typeof predictions[0]) => p.isCorrect === 1).length / mediumConfidence.length) * 100
          : 0,
      },
      low: {
        total: lowConfidence.length,
        correct: lowConfidence.filter((p: typeof predictions[0]) => p.isCorrect === 1).length,
        accuracy: lowConfidence.length > 0
          ? (lowConfidence.filter((p: typeof predictions[0]) => p.isCorrect === 1).length / lowConfidence.length) * 100
          : 0,
      },
    };

    // By league (placeholder - would need league info in predictionAccuracy table)
    const byLeague: { [league: string]: { total: number; correct: number; accuracy: number } } = {};

    // ROI calculation (simplified: assume 1.5x payout for correct predictions)
    const roi = ((correctPredictions * 1.5 - totalPredictions) / totalPredictions) * 100;

    // Value bets accuracy (high confidence + good odds)
    // For now, assume value bets are high confidence predictions
    const valueBets = highConfidence;
    const valueBetsAccuracy = valueBets.length > 0
      ? (valueBets.filter((p: typeof predictions[0]) => p.isCorrect === 1).length / valueBets.length) * 100
      : 0;

    return {
      totalPredictions,
      correctPredictions,
      accuracy,
      byConfidenceLevel,
      byLeague,
      roi,
      valueBetsAccuracy,
    };
  } catch (error) {
    console.error('[AccuracyStats] Error calculating stats:', error);
    return {
      totalPredictions: 0,
      correctPredictions: 0,
      accuracy: 0,
      byConfidenceLevel: {
        high: { total: 0, correct: 0, accuracy: 0 },
        medium: { total: 0, correct: 0, accuracy: 0 },
        low: { total: 0, correct: 0, accuracy: 0 },
      },
      byLeague: {},
      roi: 0,
      valueBetsAccuracy: 0,
    };
  }
}

/**
 * Record a prediction result
 */
export async function recordPredictionResult(
  predictionId: number,
  matchId: number,
  prediction: 'home_win' | 'draw' | 'away_win',
  confidence: number,
  actualResult: 'home_win' | 'draw' | 'away_win'
): Promise<void> {
  try {
    const db = await getDb();
    if (!db) {
      throw new Error('Database not available');
    }
    const isCorrect = prediction === actualResult ? 1 : 0;
    const confidenceBucket = getConfidenceBucket(confidence);

    await db.insert(predictionAccuracy).values({
      predictionId,
      matchId,
      prediction,
      confidence,
      actualResult,
      isCorrect,
      confidenceBucket,
      evaluatedAt: new Date(),
    });
  } catch (error) {
    console.error('[AccuracyStats] Error recording prediction result:', error);
    throw error;
  }
}

/**
 * Get confidence bucket for grouping
 */
function getConfidenceBucket(confidence: number): string {
  const bucket = Math.floor(confidence / 10) * 10;
  return `${bucket}-${bucket + 10}`;
}
