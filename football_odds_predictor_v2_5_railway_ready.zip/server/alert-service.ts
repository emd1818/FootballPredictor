import { getDb } from './db';
import { notificationPreferences, notifications, predictions, matches } from '../drizzle/schema';
import { eq, and, gte, lte, desc } from 'drizzle-orm';
import { notifyOwner } from './_core/notification';

export interface AlertCheckResult {
  totalChecked: number;
  alertsSent: number;
  errors: string[];
}

export async function checkAndSendAlerts(): Promise<AlertCheckResult> {
  const db = await getDb();
  if (!db) throw new Error('Database not available');

  const result: AlertCheckResult = {
    totalChecked: 0,
    alertsSent: 0,
    errors: [],
  };

  try {
    // Get all users with notification preferences
    const userPreferences = await db
      .select()
      .from(notificationPreferences);

    if (userPreferences.length === 0) {
      return result;
    }

    // For each user, check if there are new high-confidence predictions
    for (const pref of userPreferences) {
      try {
        await processUserAlerts(db, pref, result);
      } catch (error) {
        const errorMsg = error instanceof Error ? error.message : String(error);
        result.errors.push(`Error processing alerts for user ${pref.userId}: ${errorMsg}`);
      }
    }
  } catch (error) {
    const errorMsg = error instanceof Error ? error.message : String(error);
    result.errors.push(`Fatal error in checkAndSendAlerts: ${errorMsg}`);
  }

  return result;
}

async function processUserAlerts(
  db: any,
  pref: any,
  result: AlertCheckResult
): Promise<void> {
  // Get recent high-confidence predictions for this user's preferences
  const confidenceThreshold = pref.confidenceThreshold || 75;
  const preferredLeaguesStr = pref.preferredLeagues || '';
  const preferredLeagues = preferredLeaguesStr ? preferredLeaguesStr.split(',').map((l: string) => l.trim()) : [];

  // Get recent predictions above threshold
  const recentPredictions = await db
    .select({
      id: predictions.id,
      matchId: predictions.matchId,
      prediction: predictions.prediction,
      confidence: predictions.confidence,
      reasoning: predictions.reasoning,
    })
    .from(predictions)
    .where(and(
      gte(predictions.confidence, confidenceThreshold),
      gte(predictions.generatedAt, new Date(Date.now() - 2 * 60 * 60 * 1000)),
    ))
    .orderBy(desc(predictions.generatedAt))
    .limit(100);

  result.totalChecked += recentPredictions.length;

  // Filter by user's preferred leagues if specified
  let predictionsToNotify = recentPredictions;
  if (preferredLeagues.length > 0) {
    // Get match info for league filtering
    const matchIds = recentPredictions.map((p: any) => p.matchId);
    const matchInfo = await db
      .select({
        id: matches.id,
        league: matches.league,
      })
      .from(matches)
      .where(
        matchIds.length > 0
          ? and(...matchIds.map((id: number) => eq(matches.id, id)))
          : undefined
      );

    const leagueMap = new Map(matchInfo.map((m: any) => [m.id, m.league]));
    predictionsToNotify = recentPredictions.filter((p: any) =>
      preferredLeagues.includes(leagueMap.get(p.matchId) || '')
    );
  }

  // Check which predictions haven't been notified yet
  for (const pred of predictionsToNotify as any[]) {
    try {
      // Check if notification already sent
      const existingNotif = await db
        .select()
        .from(notifications)
        .where(
          and(
            eq(notifications.userId, pref.userId),
            eq(notifications.predictionId, pred.id)
          )
        )
        .limit(1);

      if (existingNotif.length > 0) {
        continue; // Already notified
      }

      // Get match info
      const match = await db
        .select()
        .from(matches)
        .where(eq(matches.id, pred.matchId))
        .limit(1);

      if (match.length === 0) continue;

      const matchData = match[0];
      const title = `High Confidence Prediction: ${matchData.homeTeam} vs ${matchData.awayTeam}`;
      const message = `${pred.prediction === 'home_win' ? matchData.homeTeam : pred.prediction === 'away_win' ? matchData.awayTeam : 'Draw'} with ${pred.confidence}% confidence. ${pred.reasoning || ''}`;

      // Determine notification type
      const notificationType = pref.enableEmailNotifications && pref.enableInAppNotifications
        ? 'both'
        : pref.enableEmailNotifications
          ? 'email'
          : 'in_app';

      // Save notification
      await db.insert(notifications).values({
        userId: pref.userId,
        predictionId: pred.id,
        matchId: pred.matchId,
        title,
        message,
        confidence: pred.confidence,
        prediction: pred.prediction,
        notificationType,
        sentAt: new Date(),
      });

      result.alertsSent++;
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : String(error);
      result.errors.push(`Error sending alert for prediction ${pred.id}: ${errorMsg}`);
    }
  }
}

export async function getUserNotifications(userId: number, limit: number = 20): Promise<any[]> {
  const db = await getDb();
  if (!db) throw new Error('Database not available');

  return db
    .select()
    .from(notifications)
    .where(eq(notifications.userId, userId))
    .orderBy((t) => t.sentAt)
    .limit(limit);
}

export async function markNotificationAsRead(notificationId: number): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error('Database not available');

  await db
    .update(notifications)
    .set({ isRead: 1, readAt: new Date() })
    .where(eq(notifications.id, notificationId));
}

export async function getUserPreferences(userId: number): Promise<any> {
  const db = await getDb();
  if (!db) throw new Error('Database not available');

  const prefs = await db
    .select()
    .from(notificationPreferences)
    .where(eq(notificationPreferences.userId, userId))
    .limit(1);

  return prefs.length > 0 ? prefs[0] : null;
}

export async function updateUserPreferences(
  userId: number,
  data: {
    confidenceThreshold?: number;
    enableEmailNotifications?: boolean;
    enableInAppNotifications?: boolean;
    preferredLeagues?: string[];
  }
): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error('Database not available');

  const preferredLeaguesStr = data.preferredLeagues ? data.preferredLeagues.join(',') : undefined;

  const updateData: any = {};
  if (data.confidenceThreshold !== undefined) updateData.confidenceThreshold = data.confidenceThreshold;
  if (data.enableEmailNotifications !== undefined) updateData.enableEmailNotifications = data.enableEmailNotifications ? 1 : 0;
  if (data.enableInAppNotifications !== undefined) updateData.enableInAppNotifications = data.enableInAppNotifications ? 1 : 0;
  if (preferredLeaguesStr !== undefined) updateData.preferredLeagues = preferredLeaguesStr;

  // Check if preferences exist
  const existing = await getUserPreferences(userId);

  if (existing) {
    await db
      .update(notificationPreferences)
      .set(updateData)
      .where(eq(notificationPreferences.userId, userId));
  } else {
    await db.insert(notificationPreferences).values({
      userId,
      confidenceThreshold: data.confidenceThreshold || 75,
      enableEmailNotifications: data.enableEmailNotifications !== false ? 1 : 0,
      enableInAppNotifications: data.enableInAppNotifications !== false ? 1 : 0,
      preferredLeagues: preferredLeaguesStr || null,
    });
  }
}
