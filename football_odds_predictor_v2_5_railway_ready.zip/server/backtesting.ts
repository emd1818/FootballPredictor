import { getDb } from './db';
import { predictionAccuracy, predictions, matches } from '../drizzle/schema';
import { and, gte, lte, eq, desc } from 'drizzle-orm';

export interface BacktestReport {
  periodDays: number;
  predictions: number;
  accuracy: number;
  brierScore: number;
  logLoss: number;
  roi: number;
  profitUnits: number;
  averageExpectedValue: number;
  valueBets: number;
  valueBetAccuracy: number;
  note: string;
}

/**
 * Historical replay evaluator. It uses immutable prediction snapshots that existed
 * before the result was known. This prevents overwriting a prediction with hindsight.
 * A full model re-fit backtest requires an external historical fixture/odds archive.
 */
export async function runHistoricalReplay(daysBack = 90): Promise<BacktestReport> {
  const db = await getDb();
  if (!db) throw new Error('Database not available');
  const cutoff = new Date(Date.now() - daysBack * 86400000);
  const rows = await db.select({
    accuracy: predictionAccuracy,
    prediction: predictions,
    match: matches,
  }).from(predictionAccuracy)
    .innerJoin(predictions, eq(predictionAccuracy.predictionId, predictions.id))
    .innerJoin(matches, eq(predictionAccuracy.matchId, matches.id))
    .where(gte(predictionAccuracy.evaluatedAt, cutoff))
    .orderBy(desc(predictions.generatedAt));

  if (!rows.length) return { periodDays:daysBack, predictions:0, accuracy:0, brierScore:0, logLoss:0, roi:0, profitUnits:0, averageExpectedValue:0, valueBets:0, valueBetAccuracy:0, note:'No evaluated immutable prediction snapshots are available yet.' };
  const n=rows.length;
  const correct=rows.filter(r=>r.accuracy.isCorrect===1).length;
  const profit=rows.reduce((s,r)=>s+Number(r.accuracy.profitUnits||0),0);
  const brier=rows.reduce((s,r)=>s+Number(r.accuracy.brierScore||0),0)/n;
  const logLoss=rows.reduce((s,r)=>s+Number(r.accuracy.logLoss||0),0)/n;
  const ev=rows.reduce((s,r)=>s+Number(r.accuracy.expectedValue||0),0)/n;
  const valueRows=rows.filter(r=>Number(r.accuracy.expectedValue||0)>0.03);
  const valueCorrect=valueRows.filter(r=>r.accuracy.isCorrect===1).length;
  return {
    periodDays:daysBack, predictions:n, accuracy:correct/n*100, brierScore:brier, logLoss, roi:profit/n*100,
    profitUnits:profit, averageExpectedValue:ev, valueBets:valueRows.length,
    valueBetAccuracy:valueRows.length?valueCorrect/valueRows.length*100:0,
    note:'Replay evaluation only. No future data is used after each prediction snapshot; model re-fitting requires a historical feature/odds archive.'
  };
}
