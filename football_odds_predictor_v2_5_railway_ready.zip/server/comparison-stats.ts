import { getDb } from './db';
import { predictions, predictionAccuracy } from '../drizzle/schema';
import { eq, gte } from 'drizzle-orm';

export interface PredictionTypeComparison {
  type: 'home_win' | 'draw' | 'away_win';
  totalPredictions: number;
  correctPredictions: number;
  accuracy: number;
  averageConfidence: number;
}

export interface ConfidenceRangeComparison {
  range: string;
  minConfidence: number;
  maxConfidence: number;
  totalPredictions: number;
  correctPredictions: number;
  accuracy: number;
}

export interface ComparisonStats {
  timePeriod: string;
  predictionTypes: PredictionTypeComparison[];
  confidenceRanges: ConfidenceRangeComparison[];
  overallAccuracy: number;
  totalPredictions: number;
  totalCorrect: number;
}

/**
 * Calculate accuracy comparison by prediction type
 */
export async function getComparisonByPredictionType(
  days: number = 30
): Promise<PredictionTypeComparison[]> {
  const db = await getDb();
  if (!db) throw new Error('Database not available');

  const cutoffDate = new Date();
  cutoffDate.setDate(cutoffDate.getDate() - days);

  // Fetch all predictions and their accuracy
  const records = await db
    .select({
      id: predictions.id,
      prediction: predictions.prediction,
      confidence: predictions.confidence,
      isCorrect: predictionAccuracy.isCorrect,
    })
    .from(predictions)
    .leftJoin(
      predictionAccuracy,
      eq(predictions.id, predictionAccuracy.predictionId)
    )
    .where(gte(predictions.createdAt, cutoffDate));

  // Group by prediction type
  const typeMap = new Map<string, { total: number; correct: number; confidences: number[] }>();

  for (const record of records) {
    const type = record.prediction || 'unknown';
    if (!typeMap.has(type)) {
      typeMap.set(type, { total: 0, correct: 0, confidences: [] });
    }

    const stats = typeMap.get(type)!;
    stats.total++;
    if (record.isCorrect === 1) {
      stats.correct++;
    }
    if (record.confidence) {
      stats.confidences.push(record.confidence);
    }
  }

  // Convert to result format
  const results: PredictionTypeComparison[] = [];
  const entries = Array.from(typeMap.entries());
  for (const [type, stats] of entries) {
    const avgConfidence =
      stats.confidences.length > 0
        ? stats.confidences.reduce((a: number, b: number) => a + b, 0) / stats.confidences.length
        : 0;

    results.push({
      type: type as 'home_win' | 'draw' | 'away_win',
      totalPredictions: stats.total,
      correctPredictions: stats.correct,
      accuracy: stats.total > 0 ? (stats.correct / stats.total) * 100 : 0,
      averageConfidence: avgConfidence,
    });
  }

  return results;
}

/**
 * Calculate accuracy comparison by confidence range
 */
export async function getComparisonByConfidenceRange(
  days: number = 30
): Promise<ConfidenceRangeComparison[]> {
  const db = await getDb();
  if (!db) throw new Error('Database not available');

  const cutoffDate = new Date();
  cutoffDate.setDate(cutoffDate.getDate() - days);

  // Fetch all predictions and their accuracy
  const records = await db
    .select({
      id: predictions.id,
      confidence: predictions.confidence,
      isCorrect: predictionAccuracy.isCorrect,
    })
    .from(predictions)
    .leftJoin(
      predictionAccuracy,
      eq(predictions.id, predictionAccuracy.predictionId)
    )
    .where(gte(predictions.createdAt, cutoffDate));

  const confidenceRanges = [
    { label: '40-50%', min: 40, max: 50 },
    { label: '50-60%', min: 50, max: 60 },
    { label: '60-70%', min: 60, max: 70 },
    { label: '70-80%', min: 70, max: 80 },
    { label: '80-90%', min: 80, max: 90 },
    { label: '90-100%', min: 90, max: 100 },
  ];

  const results: ConfidenceRangeComparison[] = [];

  for (const range of confidenceRanges) {
    let total = 0;
    let correct = 0;

    for (const record of records) {
      const confidence = record.confidence || 0;
      if (confidence >= range.min && confidence < range.max) {
        total++;
        if (record.isCorrect === 1) {
          correct++;
        }
      }
    }

    results.push({
      range: range.label,
      minConfidence: range.min,
      maxConfidence: range.max,
      totalPredictions: total,
      correctPredictions: correct,
      accuracy: total > 0 ? (correct / total) * 100 : 0,
    });
  }

  return results;
}

/**
 * Get complete comparison statistics
 */
export async function getComparisonStats(days: number = 30): Promise<ComparisonStats> {
  const predictionTypes = await getComparisonByPredictionType(days);
  const confidenceRanges = await getComparisonByConfidenceRange(days);

  const totalPredictions = predictionTypes.reduce((sum, t) => sum + t.totalPredictions, 0);
  const totalCorrect = predictionTypes.reduce((sum, t) => sum + t.correctPredictions, 0);
  const overallAccuracy = totalPredictions > 0 ? (totalCorrect / totalPredictions) * 100 : 0;

  return {
    timePeriod: `Last ${days} days`,
    predictionTypes,
    confidenceRanges,
    overallAccuracy,
    totalPredictions,
    totalCorrect,
  };
}
