import { createOrUpdateMatch, recordOddsHistory, getLatestOddsForBookmaker } from './db';
import type { InsertMatch, InsertOddsHistory } from '../drizzle/schema';
import { fetchMultipleLeaguesOdds, extractOddsData, isApiKeyConfigured, type OddsEvent } from './odds-api-client';
import { resolveTeamIdByName } from './team-stats-client';

const LEAGUE_MAP: Record<string, { leagueId: number; name: string }> = {
  soccer_epl: { leagueId: 39, name: 'Premier League' },
  soccer_efl_champ: { leagueId: 40, name: 'Championship' },
  soccer_england_league1: { leagueId: 41, name: 'League One' },
  soccer_spain_la_liga: { leagueId: 140, name: 'La Liga' },
  soccer_spain_segunda_division: { leagueId: 141, name: 'La Liga 2' },
  soccer_italy_serie_a: { leagueId: 135, name: 'Serie A' },
  soccer_italy_serie_b: { leagueId: 136, name: 'Serie B' },
  soccer_germany_bundesliga: { leagueId: 78, name: 'Bundesliga' },
  soccer_germany_bundesliga2: { leagueId: 79, name: 'Bundesliga 2' },
  soccer_france_ligue_one: { leagueId: 61, name: 'Ligue 1' },
  soccer_france_ligue_two: { leagueId: 62, name: 'Ligue 2' },
  soccer_netherlands_eredivisie: { leagueId: 88, name: 'Eredivisie' },
  soccer_portugal_primeira_liga: { leagueId: 94, name: 'Primeira Liga' },
  soccer_belgium_first_div: { leagueId: 144, name: 'Belgian First Division' },
  soccer_austria_bundesliga: { leagueId: 218, name: 'Austrian Bundesliga' },
  soccer_denmark_superliga: { leagueId: 119, name: 'Danish Superliga' },
  soccer_greece_super_league: { leagueId: 197, name: 'Greek Super League' },
  soccer_norway_eliteserien: { leagueId: 103, name: 'Eliteserien' },
  soccer_poland_ekstraklasa: { leagueId: 106, name: 'Ekstraklasa' },
  soccer_spl: { leagueId: 179, name: 'Scottish Premiership' },
  soccer_sweden_allsvenskan: { leagueId: 113, name: 'Allsvenskan' },
  soccer_switzerland_superleague: { leagueId: 207, name: 'Swiss Super League' },
  soccer_turkey_super_league: { leagueId: 203, name: 'Turkish Super League' },
  soccer_usa_mls: { leagueId: 253, name: 'MLS' },
  soccer_brazil_campeonato: { leagueId: 71, name: 'Serie A Brazil' },
  soccer_brazil_serie_b: { leagueId: 72, name: 'Serie B Brazil' },
  soccer_argentina_primera_division: { leagueId: 128, name: 'Argentina Primera División' },
  soccer_mexico_ligamx: { leagueId: 262, name: 'Liga MX' },
  soccer_saudi_arabia_pro_league: { leagueId: 307, name: 'Saudi Pro League' },
  soccer_uefa_champs_league: { leagueId: 2, name: 'UEFA Champions League' },
  soccer_uefa_europa_league: { leagueId: 3, name: 'UEFA Europa League' },
  soccer_uefa_europa_conference_league: { leagueId: 848, name: 'UEFA Conference League' },
};

function parseLeagueKey(event: OddsEvent) {
  const mapped = LEAGUE_MAP[event.sport_key];
  return mapped ?? { leagueId: null, name: event.sport_title || event.sport_key };
}

function movement(current: number, previous?: string) {
  const prev = Number(previous);
  if (!Number.isFinite(prev) || prev <= 1) return '0';
  return (((current - prev) / prev) * 100).toFixed(4);
}

/** Real-data-only ingestion. Missing/failed providers never produce synthetic football data. */
export async function fetchAndProcessOddsData(): Promise<{ matchesAdded:number; oddsRecorded:number; errors:string[] }> {
  const errors:string[]=[]; let matchesAdded=0; let oddsRecorded=0;
  if (!isApiKeyConfigured()) return { matchesAdded:0, oddsRecorded:0, errors:['ODDS_API_KEY is not configured; production ingestion refuses to use synthetic data.'] };
  try {
    const events=await fetchMultipleLeaguesOdds();
    for(const event of events){
      try{
        const league=parseLeagueKey(event);
        const [homeTeamId, awayTeamId] = await Promise.all([
          resolveTeamIdByName(event.home_team),
          resolveTeamIdByName(event.away_team),
        ]);
        const match = await createOrUpdateMatch({
          externalId:event.id, homeTeam:event.home_team, awayTeam:event.away_team,
          league:league.name, matchDate:new Date(event.commence_time),
          homeTeamId, awayTeamId, leagueId:league.leagueId, status:'upcoming'
        });
        if(!match?.id) throw new Error('Match upsert returned no id');
        matchesAdded++;
        const extracted=extractOddsData(event).filter(o=>Number(o.homeWinOdds)>1 && Number(o.drawOdds)>1 && Number(o.awayWinOdds)>1);
        for(const odds of extracted){
          const previous=await getLatestOddsForBookmaker(match.id, odds.bookmaker);
          const sourceUpdatedAt = new Date(odds.sourceUpdatedAt);
          if (!Number.isNaN(sourceUpdatedAt.getTime()) && previous?.sourceUpdatedAt && new Date(previous.sourceUpdatedAt).getTime() === sourceUpdatedAt.getTime()) {
            continue; // Same provider snapshot; keep ingestion idempotent.
          }
          await recordOddsHistory({
            matchId:match.id, homeWinOdds:odds.homeWinOdds, drawOdds:odds.drawOdds, awayWinOdds:odds.awayWinOdds,
            homeWinMovement:movement(Number(odds.homeWinOdds), previous?.homeWinOdds),
            drawMovement:movement(Number(odds.drawOdds), previous?.drawOdds),
            awayWinMovement:movement(Number(odds.awayWinOdds), previous?.awayWinOdds),
            bookmaker:odds.bookmaker, sourceUpdatedAt: Number.isNaN(sourceUpdatedAt.getTime()) ? null : sourceUpdatedAt, recordedAt:new Date(),
          });
          oddsRecorded++;
        }
      }catch(error){ errors.push(`${event.home_team} vs ${event.away_team}: ${error instanceof Error?error.message:String(error)}`); }
    }
  }catch(error){ errors.push(`Odds ingestion failed: ${error instanceof Error?error.message:String(error)}`); }
  return { matchesAdded, oddsRecorded, errors };
}

export async function updateAllMatchOdds(){
  const result=await fetchAndProcessOddsData();
  return { matchesUpdated:result.matchesAdded, oddsRecorded:result.oddsRecorded, errors:result.errors };
}
