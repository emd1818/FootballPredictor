import { eq, and, gte, lt, desc, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, matches, oddsHistory, predictions, dataSources, notificationPreferences, notifications, matchResults, predictionAccuracy, InsertMatch, InsertOddsHistory, InsertPrediction, InsertNotificationPreference, InsertNotification, InsertMatchResult, InsertPredictionAccuracy } from "../drizzle/schema";
import { recordMatchResult, getPerformanceMetrics, getAccuracyByLeague, getAccuracyByPredictionType } from './performance-analytics';

// Re-export performance analytics functions
export { recordMatchResult, getPerformanceMetrics, getAccuracyByLeague, getAccuracyByPredictionType };
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

let _dbHealth: { expires: number; ok: boolean } | null = null;
export async function hasUsableDatabase(): Promise<boolean> {
  if (_dbHealth && _dbHealth.expires > Date.now()) return _dbHealth.ok;
  const db = await getDb();
  if (!db) { _dbHealth = { expires: Date.now() + 15_000, ok: false }; return false; }
  try {
    await db.execute(sql`SELECT 1`);
    _dbHealth = { expires: Date.now() + 15_000, ok: true };
    return true;
  } catch (error) {
    console.warn('[Database] Health check failed:', error instanceof Error ? error.message : error);
    _dbHealth = { expires: Date.now() + 15_000, ok: false };
    return false;
  }
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// Matches
export async function createOrUpdateMatch(match: InsertMatch) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const existing = await db.select().from(matches).where(eq(matches.externalId, match.externalId || '')).limit(1);
  
  if (existing.length > 0) {
    await db.update(matches).set({
      homeTeam: match.homeTeam,
      awayTeam: match.awayTeam,
      league: match.league,
      matchDate: match.matchDate,
      homeTeamId: match.homeTeamId,
      awayTeamId: match.awayTeamId,
      leagueId: match.leagueId,
      status: match.status,
      updatedAt: new Date(),
    }).where(eq(matches.id, existing[0].id));
    return existing[0];
  } else {
    await db.insert(matches).values(match);
    const inserted = await db.select().from(matches).where(eq(matches.externalId, match.externalId || '')).limit(1);
    return inserted[0];
  }
}

export async function getUpcomingMatches(limit: number = 50) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const now = new Date();
  const rows = await db.select().from(matches).where(gte(matches.matchDate, now)).orderBy((m) => m.matchDate).limit(limit);
  if (!rows.length) return [];

  const history = await getOddsHistoryForMatches(rows.map((m) => m.id));
  const byMatch = new Map<number, typeof history>();
  for (const item of history) {
    const list = byMatch.get(item.matchId) ?? [];
    list.push(item);
    byMatch.set(item.matchId, list);
  }

  return rows.map((match) => {
    const snapshots = byMatch.get(match.id) ?? [];
    const latestByBookmaker = new Map<string, (typeof history)[number]>();
    for (const snapshot of snapshots) {
      const current = latestByBookmaker.get(snapshot.bookmaker);
      const currentTime = current ? new Date(current.sourceUpdatedAt ?? current.recordedAt).getTime() : -1;
      const nextTime = new Date(snapshot.sourceUpdatedAt ?? snapshot.recordedAt).getTime();
      if (!current || nextTime >= currentTime) latestByBookmaker.set(snapshot.bookmaker, snapshot);
    }

    const latest = Array.from(latestByBookmaker.values());
    const best = { home: null as number | null, draw: null as number | null, away: null as number | null };
    for (const odds of latest) {
      const h = Number(odds.homeWinOdds), d = Number(odds.drawOdds), a = Number(odds.awayWinOdds);
      if (Number.isFinite(h) && h > 1 && (best.home === null || h > best.home)) best.home = h;
      if (Number.isFinite(d) && d > 1 && (best.draw === null || d > best.draw)) best.draw = d;
      if (Number.isFinite(a) && a > 1 && (best.away === null || a > best.away)) best.away = a;
    }

    const latestTimestamp = latest.reduce<Date | null>((max, item) => {
      const value = new Date(item.sourceUpdatedAt ?? item.recordedAt);
      return !max || value > max ? value : max;
    }, null);

    return {
      ...match,
      odds: {
        bookmakerCount: latest.length,
        bestHome: best.home,
        bestDraw: best.draw,
        bestAway: best.away,
        updatedAt: latestTimestamp,
      },
    };
  });
}

export async function getMatchById(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.select().from(matches).where(eq(matches.id, id)).limit(1);
  return result.length > 0 ? result[0] : null;
}

// Odds History
export async function getLatestOddsForBookmaker(matchId: number, bookmaker: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.select().from(oddsHistory)
    .where(and(eq(oddsHistory.matchId, matchId), eq(oddsHistory.bookmaker, bookmaker)))
    .orderBy(desc(oddsHistory.sourceUpdatedAt), desc(oddsHistory.recordedAt)).limit(1);
  return result[0] ?? null;
}

export async function recordOdds(oddsRecord: InsertOddsHistory) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return db.insert(oddsHistory).values(oddsRecord);
}

export async function getOddsHistoryForMatches(matchIds: number[]) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  if (!matchIds.length) return [];
  return db.select().from(oddsHistory).where(sql`${oddsHistory.matchId} in (${sql.join(matchIds.map(id => sql`${id}`), sql`, `)})`).orderBy(oddsHistory.recordedAt);
}

export async function getOddsHistoryForMatch(matchId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return db.select().from(oddsHistory).where(eq(oddsHistory.matchId, matchId)).orderBy((o) => o.recordedAt);
}

// Predictions
export async function createPrediction(prediction: InsertPrediction) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return db.insert(predictions).values(prediction);
}

export async function getTopPredictions(limit: number = 20) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  // Get date range (include today through 7 days for more variety)
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const sevenDaysFromNow = new Date(today);
  sevenDaysFromNow.setDate(sevenDaysFromNow.getDate() + 7);
  
  // Get all predictions for today's matches
  const allResults = await db
    .select()
    .from(predictions)
    .innerJoin(matches, eq(predictions.matchId, matches.id))
    .where(and(gte(matches.matchDate, today), lt(matches.matchDate, sevenDaysFromNow)))
    .orderBy(desc(predictions.generatedAt));

  // Immutable snapshots are retained. For the public "top" feed use the latest snapshot per match.
  const uniqueByMatch = new Map<number, any>();
  for (const result of allResults) {
    const matchId = result.predictions.matchId;
    if (!uniqueByMatch.has(matchId)) uniqueByMatch.set(matchId, result);
  }
  
  // Convert back to array, sort by confidence, and limit
  const topPredictions = Array.from(uniqueByMatch.values())
    .sort((a: any, b: any) => b.predictions.confidence - a.predictions.confidence)
    .slice(0, limit);
  
  // Extract just the predictions
  return topPredictions.map((r: any) => r.predictions);

}

export async function getPredictionsForMatch(matchId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return db.select().from(predictions).where(eq(predictions.matchId, matchId));
}

// Data Sources
export async function updateDataSourceStatus(id: number, status: "active" | "inactive" | "error", errorMessage?: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return db.update(dataSources).set({ status, errorMessage, lastFetchedAt: new Date() }).where(eq(dataSources.id, id));
}

// Notification Preferences
export async function getOrCreateNotificationPreferences(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const existing = await db.select().from(notificationPreferences).where(eq(notificationPreferences.userId, userId)).limit(1);
  
  if (existing.length > 0) {
    return existing[0];
  }
  
  const newPrefs: InsertNotificationPreference = {
    userId,
    confidenceThreshold: 75,
    enableEmailNotifications: 1,
    enableInAppNotifications: 1,
  };
  
  await db.insert(notificationPreferences).values(newPrefs);
  return newPrefs;
}

export async function updateNotificationPreferences(userId: number, prefs: Partial<InsertNotificationPreference>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return db.update(notificationPreferences).set(prefs).where(eq(notificationPreferences.userId, userId));
}

export async function getUserNotifications(userId: number, limit: number = 50) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return db.select().from(notifications).where(eq(notifications.userId, userId)).orderBy((n) => n.sentAt).limit(limit);
}

export async function createNotification(notification: InsertNotification) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return db.insert(notifications).values(notification);
}

export async function markNotificationAsRead(notificationId: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return db.update(notifications).set({ isRead: 1, readAt: new Date() }).where(and(eq(notifications.id, notificationId), eq(notifications.userId, userId)));
}


export async function recordOddsHistory(oddsRecord: InsertOddsHistory) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return db.insert(oddsHistory).values(oddsRecord);
}

export async function getUnreadNotifications(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return db.select().from(notifications).where(
    and(
      eq(notifications.userId, userId),
      eq(notifications.isRead, 0)
    )
  ).orderBy((n) => n.sentAt);
}

export async function deleteNotification(notificationId: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return db.delete(notifications).where(and(eq(notifications.id, notificationId), eq(notifications.userId, userId)));
}
