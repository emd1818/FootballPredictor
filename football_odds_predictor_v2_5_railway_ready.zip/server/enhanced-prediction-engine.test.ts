import { describe, it, expect, vi, beforeEach } from 'vitest';
import { generateEnhancedPrediction, generateTopEnhancedPredictions, type EnhancedPredictionInput } from './enhanced-prediction-engine';
import type { Match, OddsHistory } from '../drizzle/schema';
import * as llm from './_core/llm';

// Mock LLM to avoid rate limits during testing
vi.mock('./_core/llm', () => ({
  invokeLLM: vi.fn(async () => ({
    choices: [{
      message: {
        content: 'This is a strong prediction based on the odds movement and market analysis.',
      },
    }],
  })),
}));

describe('Enhanced Prediction Engine', () => {
  const mockMatch: Match = {
    id: 1,
    externalId: 'test-match-1',
    homeTeam: 'Manchester United',
    awayTeam: 'Liverpool',
    league: 'EPL',
    matchDate: new Date(Date.now() + 24 * 60 * 60 * 1000), // Tomorrow
    homeTeamId: 33,
    awayTeamId: 34,
    leagueId: 39,
    createdAt: new Date(),
    updatedAt: new Date(),
  };

  const mockOddsHistory: OddsHistory[] = [
    {
      id: 1,
      matchId: 1,
      homeWinOdds: '2.10',
      drawOdds: '3.40',
      awayWinOdds: '3.50',
      homeWinMovement: '2.5',
      drawMovement: '-1.2',
      awayWinMovement: '0.8',
      bookmaker: 'Bet365',
      recordedAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
      createdAt: new Date(),
      updatedAt: new Date(),
    },
    {
      id: 2,
      matchId: 1,
      homeWinOdds: '2.15',
      drawOdds: '3.35',
      awayWinOdds: '3.45',
      homeWinMovement: '2.4',
      drawMovement: '-1.5',
      awayWinMovement: '0.5',
      bookmaker: 'Bet365',
      recordedAt: new Date(Date.now() - 1 * 60 * 60 * 1000),
      createdAt: new Date(),
      updatedAt: new Date(),
    },
  ];

  describe('generateEnhancedPrediction', () => {
    it('should generate a valid prediction with all required fields', async () => {
      const input: EnhancedPredictionInput = {
        match: mockMatch,
        oddsHistory: mockOddsHistory,
      };

      const prediction = await generateEnhancedPrediction(input);

      expect(prediction).toHaveProperty('prediction');
      expect(prediction).toHaveProperty('confidence');
      expect(prediction).toHaveProperty('reasoning');
      expect(prediction).toHaveProperty('factors');
      expect(prediction).toHaveProperty('keyInsights');
      expect(prediction).toHaveProperty('riskLevel');
      expect(prediction).toHaveProperty('valueScore');

      // Validate prediction type
      expect(['home_win', 'draw', 'away_win']).toContain(prediction.prediction);

      // Validate confidence range (0-100%)
      expect(prediction.confidence).toBeGreaterThanOrEqual(0);
      expect(prediction.confidence).toBeLessThanOrEqual(100);

      // Validate factors
      expect(prediction.factors.oddsMovementScore).toBeGreaterThanOrEqual(0);
      expect(prediction.factors.oddsMovementScore).toBeLessThanOrEqual(100);
      expect(prediction.factors.volatilityScore).toBeGreaterThanOrEqual(0);
      expect(prediction.factors.volatilityScore).toBeLessThanOrEqual(100);
      expect(prediction.factors.homeFormScore).toBeGreaterThanOrEqual(0);
      expect(prediction.factors.homeFormScore).toBeLessThanOrEqual(100);
      expect(prediction.factors.awayFormScore).toBeGreaterThanOrEqual(0);
      expect(prediction.factors.awayFormScore).toBeLessThanOrEqual(100);
      expect(prediction.factors.h2hAdvantage).toBeGreaterThanOrEqual(-100);
      expect(prediction.factors.h2hAdvantage).toBeLessThanOrEqual(100);
      expect(prediction.factors.impliedProbability).toBeGreaterThanOrEqual(0);
      expect(prediction.factors.impliedProbability).toBeLessThanOrEqual(100);
      expect(prediction.factors.bookmakerDisagreement).toBeGreaterThanOrEqual(0);
      expect(prediction.factors.bookmakerDisagreement).toBeLessThanOrEqual(100);

      // Validate risk level
      expect(['low', 'medium', 'high']).toContain(prediction.riskLevel);

      // Validate value score
      expect(prediction.valueScore).toBeGreaterThanOrEqual(0);
      expect(prediction.valueScore).toBeLessThanOrEqual(100);

      // Validate key insights
      expect(Array.isArray(prediction.keyInsights)).toBe(true);
      expect(prediction.keyInsights.length).toBeGreaterThan(0);
    }, { timeout: 15000 });

    it('should handle empty odds history gracefully', async () => {
      const input: EnhancedPredictionInput = {
        match: mockMatch,
        oddsHistory: [],
      };

      const prediction = await generateEnhancedPrediction(input);

      expect(prediction).toHaveProperty('prediction');
      expect(prediction.confidence).toBeGreaterThanOrEqual(0);
      expect(prediction.confidence).toBeLessThanOrEqual(100);
    }, { timeout: 15000 });

    it('should generate different predictions for different odds', async () => {
      const input1: EnhancedPredictionInput = {
        match: mockMatch,
        oddsHistory: [
          {
            ...mockOddsHistory[0],
            homeWinOdds: '1.50', // Strong home favorite
            drawOdds: '4.00',
            awayWinOdds: '6.00',
          },
        ],
      };

      const input2: EnhancedPredictionInput = {
        match: mockMatch,
        oddsHistory: [
          {
            ...mockOddsHistory[0],
            homeWinOdds: '3.50', // Weak home team
            drawOdds: '3.40',
            awayWinOdds: '2.00',
          },
        ],
      };

      const prediction1 = await generateEnhancedPrediction(input1);
      const prediction2 = await generateEnhancedPrediction(input2);

      // Predictions should be different based on odds
      expect(prediction1.factors.impliedProbability).not.toBe(prediction2.factors.impliedProbability);
    }, { timeout: 15000 });
  });

  describe('generateTopEnhancedPredictions', () => {
    it('should generate and rank multiple predictions', async () => {
      const inputs: EnhancedPredictionInput[] = [
        {
          match: { ...mockMatch, id: 1, homeTeam: 'Team A', awayTeam: 'Team B' },
          oddsHistory: mockOddsHistory,
        },
        {
          match: { ...mockMatch, id: 2, homeTeam: 'Team C', awayTeam: 'Team D' },
          oddsHistory: mockOddsHistory,
        },
        {
          match: { ...mockMatch, id: 3, homeTeam: 'Team E', awayTeam: 'Team F' },
          oddsHistory: mockOddsHistory,
        },
      ];

      const predictions = await generateTopEnhancedPredictions(inputs, 3);

      expect(predictions.length).toBeLessThanOrEqual(3);
      expect(predictions.length).toBeGreaterThan(0);

      // Verify predictions are sorted by confidence (descending)
      for (let i = 0; i < predictions.length - 1; i++) {
        expect(predictions[i].confidence).toBeGreaterThanOrEqual(predictions[i + 1].confidence);
      }

      // Verify each prediction has a matchId
      predictions.forEach(pred => {
        expect(pred).toHaveProperty('matchId');
        expect(pred.matchId).toBeGreaterThan(0);
      });
    }, { timeout: 30000 });

    it('should respect the limit parameter', async () => {
      const inputs: EnhancedPredictionInput[] = Array.from({ length: 10 }, (_, i) => ({
        match: { ...mockMatch, id: i + 1, homeTeam: `Team ${i}A`, awayTeam: `Team ${i}B` },
        oddsHistory: mockOddsHistory,
      }));

      const predictions = await generateTopEnhancedPredictions(inputs, 5);

      expect(predictions.length).toBeLessThanOrEqual(5);
    }, { timeout: 30000 });

    it('should handle errors gracefully and continue with other predictions', async () => {
      const inputs: EnhancedPredictionInput[] = [
        {
          match: { ...mockMatch, id: 1, homeTeam: 'Team A', awayTeam: 'Team B' },
          oddsHistory: mockOddsHistory,
        },
        {
          match: { ...mockMatch, id: 2, homeTeam: 'Team C', awayTeam: 'Team D' },
          oddsHistory: mockOddsHistory,
        },
      ];

      const predictions = await generateTopEnhancedPredictions(inputs, 2);

      // Should return valid predictions
      expect(predictions.length).toBeGreaterThan(0);
      expect(predictions.length).toBeLessThanOrEqual(2);
    }, { timeout: 30000 });
  });
});
