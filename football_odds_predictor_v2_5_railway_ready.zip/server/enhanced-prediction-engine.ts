/**
 * Backward-compatible adapter for the former Enhanced Prediction Engine.
 * The project now has one authoritative model: Prediction Engine V2.
 */
import type { Match, OddsHistory } from '../drizzle/schema';
import { generatePrediction, generateTopPredictions, type PredictionInput } from './prediction-engine';

export interface EnhancedPredictionInput { match: Match; oddsHistory: OddsHistory[]; homeTeamId?: number; awayTeamId?: number; leagueId?: number; season?: number; }
export interface EnhancedPredictionFactors {
  oddsMovementScore:number; volatilityScore:number; homeFormScore:number; awayFormScore:number; h2hAdvantage:number;
  impliedProbability:number; marketConsensus:string; bookmakerDisagreement:number;
}
export interface EnhancedGeneratedPrediction {
  prediction:'home_win'|'draw'|'away_win'; confidence:number; reasoning:string; factors:EnhancedPredictionFactors;
  keyInsights:string[]; riskLevel:'low'|'medium'|'high'; valueScore:number;
}

export async function generateEnhancedPrediction(input: EnhancedPredictionInput): Promise<EnhancedGeneratedPrediction> {
  const prediction=await generatePrediction(input);
  const implied = prediction.prediction==='home_win' ? prediction.marketHomeProbability : prediction.prediction==='draw' ? prediction.marketDrawProbability : prediction.marketAwayProbability;
  return {
    prediction:prediction.prediction, confidence:prediction.confidence, reasoning:prediction.reasoning,
    factors:{
      oddsMovementScore:prediction.oddsMovementScore, volatilityScore:prediction.volatilityScore,
      homeFormScore:prediction.homeFormScore ?? 50, awayFormScore:prediction.awayFormScore ?? 50,
      h2hAdvantage:prediction.h2hAdvantage ?? 0, impliedProbability:implied ?? 33,
      marketConsensus:prediction.prediction==='home_win'?'home':prediction.prediction==='draw'?'draw':'away',
      bookmakerDisagreement:prediction.bookmakerDisagreement ?? 0,
    },
    keyInsights:[
      `Model probability: H ${(prediction.homeProbability ?? 33).toFixed(1)}% / D ${(prediction.drawProbability ?? 33).toFixed(1)}% / A ${(prediction.awayProbability ?? 33).toFixed(1)}%`,
      `Market probability: H ${(prediction.marketHomeProbability ?? 33).toFixed(1)}% / D ${(prediction.marketDrawProbability ?? 33).toFixed(1)}% / A ${(prediction.marketAwayProbability ?? 33).toFixed(1)}%`,
      prediction.valueFlag ? `Positive expected value: ${((prediction.expectedValue ?? 0)*100).toFixed(1)}%` : 'No positive expected value threshold met',
    ],
    riskLevel:prediction.riskLevel ?? 'medium', valueScore:prediction.valueScore ?? 0,
  };
}

export async function generateTopEnhancedPredictions(inputs: EnhancedPredictionInput[], limit=20) {
  const predictions=await generateTopPredictions(inputs.map(i=>({match:i.match, oddsHistory:i.oddsHistory})),limit);
  return predictions.map(p=>({
    ...p, factors:{ oddsMovementScore:p.oddsMovementScore, volatilityScore:p.volatilityScore, homeFormScore:p.homeFormScore??50, awayFormScore:p.awayFormScore??50, h2hAdvantage:p.h2hAdvantage??0, impliedProbability:p.prediction==='home_win'?p.marketHomeProbability??33:p.prediction==='draw'?p.marketDrawProbability??33:p.marketAwayProbability??33, marketConsensus:p.prediction==='home_win'?'home':p.prediction==='draw'?'draw':'away', bookmakerDisagreement:p.bookmakerDisagreement??0 },
    keyInsights:[], valueScore:p.valueScore??0,
  }));
}
