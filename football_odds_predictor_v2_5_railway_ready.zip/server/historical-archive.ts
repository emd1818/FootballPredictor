import { createOrUpdateMatch, getLatestOddsForBookmaker, recordOddsHistory } from './db';
import { fetchHistoricalFootballOddsSnapshot, extractOddsData } from './odds-api-client';
import { resolveTeamIdByName } from './team-stats-client';

const LEAGUE_MAP: Record<string, { leagueId: number; name: string }> = {
  soccer_epl: { leagueId: 39, name: 'Premier League' },
  soccer_efl_champ: { leagueId: 40, name: 'Championship' },
  soccer_spain_la_liga: { leagueId: 140, name: 'La Liga' },
  soccer_italy_serie_a: { leagueId: 135, name: 'Serie A' },
  soccer_germany_bundesliga: { leagueId: 78, name: 'Bundesliga' },
  soccer_france_ligue_one: { leagueId: 61, name: 'Ligue 1' },
  soccer_netherlands_eredivisie: { leagueId: 88, name: 'Eredivisie' },
  soccer_portugal_primeira_liga: { leagueId: 94, name: 'Primeira Liga' },
  soccer_belgium_first_div: { leagueId: 144, name: 'Belgian First Division' },
  soccer_uefa_champs_league: { leagueId: 2, name: 'UEFA Champions League' },
  soccer_uefa_europa_league: { leagueId: 3, name: 'UEFA Europa League' },
  soccer_uefa_europa_conference_league: { leagueId: 848, name: 'UEFA Conference League' },
};

function movement(current: number, previous?: string) {
  const prev = Number(previous);
  if (!Number.isFinite(prev) || prev <= 1) return '0';
  return (((current - prev) / prev) * 100).toFixed(4);
}

/**
 * Archive a historical odds snapshot without generating predictions.
 * This is deliberately ingestion-only: backtests must never call the live prediction pipeline.
 */
export async function archiveHistoricalOddsSnapshot(sportKey: string, date: Date) {
  if (process.env.HISTORICAL_ARCHIVE_ENABLED !== 'true') {
    throw new Error('Historical archive is disabled. Set HISTORICAL_ARCHIVE_ENABLED=true explicitly.');
  }
  const snapshot = await fetchHistoricalFootballOddsSnapshot(sportKey, date);
  const league = LEAGUE_MAP[sportKey] ?? { leagueId: null, name: sportKey };
  let matches = 0;
  let odds = 0;
  let skipped = 0;

  for (const event of snapshot.events) {
    const [homeTeamId, awayTeamId] = await Promise.all([
      resolveTeamIdByName(event.home_team),
      resolveTeamIdByName(event.away_team),
    ]);
    const match = await createOrUpdateMatch({
      externalId: event.id,
      homeTeam: event.home_team,
      awayTeam: event.away_team,
      league: league.name,
      matchDate: new Date(event.commence_time),
      homeTeamId,
      awayTeamId,
      leagueId: league.leagueId,
      status: new Date(event.commence_time) < new Date() ? 'finished' : 'upcoming',
    });
    matches++;

    for (const row of extractOddsData(event)) {
      const previous = await getLatestOddsForBookmaker(match.id, row.bookmaker);
      const sourceUpdatedAt = new Date(row.sourceUpdatedAt);
      if (previous?.sourceUpdatedAt && sourceUpdatedAt.getTime() === new Date(previous.sourceUpdatedAt).getTime()) {
        skipped++;
        continue;
      }
      await recordOddsHistory({
        matchId: match.id,
        homeWinOdds: row.homeWinOdds,
        drawOdds: row.drawOdds,
        awayWinOdds: row.awayWinOdds,
        homeWinMovement: movement(Number(row.homeWinOdds), previous?.homeWinOdds),
        drawMovement: movement(Number(row.drawOdds), previous?.drawOdds),
        awayWinMovement: movement(Number(row.awayWinOdds), previous?.awayWinOdds),
        bookmaker: row.bookmaker,
        sourceUpdatedAt: Number.isFinite(sourceUpdatedAt.getTime()) ? sourceUpdatedAt : null,
        recordedAt: new Date(snapshot.timestamp),
      });
      odds++;
    }
  }

  return { sportKey, requestedDate: date.toISOString(), snapshotTimestamp: snapshot.timestamp, matches, odds, skipped };
}

function resultFromGoals(homeGoals: number, awayGoals: number) {
  if (homeGoals > awayGoals) return 'home_win' as const;
  if (homeGoals < awayGoals) return 'away_win' as const;
  return 'draw' as const;
}

/**
 * Import final results for one league/date and evaluate all immutable predictions.
 * API-Football exposes completed fixtures by date/league/season; matching is by team IDs and kickoff proximity.
 */
export async function syncHistoricalResults(date: string, leagueId: number, season: number) {
  if (process.env.HISTORICAL_ARCHIVE_ENABLED !== 'true') {
    throw new Error('Historical archive is disabled. Set HISTORICAL_ARCHIVE_ENABLED=true explicitly.');
  }
  const { fetchCompletedFixturesForDate } = await import('./team-stats-client');
  const { getDb } = await import('./db');
  const { matches, matchResults } = await import('../drizzle/schema');
  const { and, eq, gte, lte } = await import('drizzle-orm');
  const { recordMatchResult } = await import('./performance-analytics');
  const db = await getDb();
  if (!db) throw new Error('Database not available');

  const fixtures = await fetchCompletedFixturesForDate(date, leagueId, season);
  let matched = 0;
  let evaluated = 0;
  const toleranceMs = 3 * 60 * 60 * 1000;

  for (const fixture of fixtures) {
    const kickoff = new Date(fixture.date).getTime();
    const candidates = await db.select().from(matches).where(and(
      eq(matches.homeTeamId, fixture.homeTeamId),
      eq(matches.awayTeamId, fixture.awayTeamId),
      eq(matches.leagueId, leagueId),
      gte(matches.matchDate, new Date(kickoff - toleranceMs)),
      lte(matches.matchDate, new Date(kickoff + toleranceMs)),
    )).limit(5);
    const match = candidates[0];
    if (!match) continue;
    matched++;
    await recordMatchResult(match.id, resultFromGoals(fixture.homeGoals, fixture.awayGoals), fixture.homeGoals, fixture.awayGoals);
    evaluated++;
  }

  return { date, leagueId, season, fixtures: fixtures.length, matched, evaluated };
}
