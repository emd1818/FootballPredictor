import { fetchMultipleLeaguesOdds, extractOddsData, type OddsEvent } from './odds-api-client';
import { generatePrediction, type GeneratedPrediction } from './prediction-engine';

export interface LiveMatch {
  id: number;
  externalId: string;
  homeTeam: string;
  awayTeam: string;
  league: string;
  leagueId: number | null;
  matchDate: Date;
  status: 'upcoming';
  homeTeamId: null;
  awayTeamId: null;
  odds: { bookmakerCount: number; bestHome: number | null; bestDraw: number | null; bestAway: number | null; updatedAt: Date | null };
  dataMode: 'live-api';
}

export interface LivePrediction extends GeneratedPrediction {
  matchId: number;
  match: LiveMatch;
  dataMode: 'live-api';
}

const leagueNames: Record<string, { id: number; name: string }> = {
  soccer_epl: { id: 39, name: 'Premier League' },
  soccer_spain_la_liga: { id: 140, name: 'La Liga' },
  soccer_italy_serie_a: { id: 135, name: 'Serie A' },
  soccer_germany_bundesliga: { id: 78, name: 'Bundesliga' },
  soccer_france_ligue_one: { id: 61, name: 'Ligue 1' },
  soccer_netherlands_eredivisie: { id: 88, name: 'Eredivisie' },
  soccer_portugal_primeira_liga: { id: 94, name: 'Primeira Liga' },
  soccer_turkey_super_league: { id: 203, name: 'Turkish Super League' },
  soccer_uefa_champs_league: { id: 2, name: 'UEFA Champions League' },
  soccer_uefa_europa_league: { id: 3, name: 'UEFA Europa League' },
  soccer_uefa_europa_conference_league: { id: 848, name: 'UEFA Conference League' },
};

function stableId(value: string) {
  let hash = 2166136261;
  for (let i = 0; i < value.length; i++) {
    hash ^= value.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  return Math.abs(hash | 0) || 1;
}

function transform(event: OddsEvent): { match: LiveMatch; history: any[] } {
  const league = leagueNames[event.sport_key];
  const id = stableId(event.id);
  const rows = extractOddsData(event).filter(o => Number(o.homeWinOdds) > 1 && Number(o.drawOdds) > 1 && Number(o.awayWinOdds) > 1);
  const latestByBook = new Map<string, any>();
  for (const row of rows) latestByBook.set(row.bookmaker, row);
  const latest = [...latestByBook.values()];
  const best = {
    home: latest.length ? Math.max(...latest.map(r => Number(r.homeWinOdds))) : null,
    draw: latest.length ? Math.max(...latest.map(r => Number(r.drawOdds))) : null,
    away: latest.length ? Math.max(...latest.map(r => Number(r.awayWinOdds))) : null,
  };
  const updated = latest.map(r => new Date(r.sourceUpdatedAt)).filter(d => Number.isFinite(d.getTime())).sort((a,b)=>b.getTime()-a.getTime())[0] ?? null;
  const match: LiveMatch = {
    id,
    externalId: event.id,
    homeTeam: event.home_team,
    awayTeam: event.away_team,
    league: league?.name ?? event.sport_title,
    leagueId: league?.id ?? null,
    matchDate: new Date(event.commence_time),
    status: 'upcoming', homeTeamId: null, awayTeamId: null,
    odds: { bookmakerCount: latest.length, bestHome: best.home, bestDraw: best.draw, bestAway: best.away, updatedAt: updated },
    dataMode: 'live-api',
  };
  const now = new Date();
  const history = rows.map((r, i) => ({
    id: stableId(`${event.id}:${r.bookmaker}:${r.sourceUpdatedAt}:${i}`), matchId: id,
    bookmaker: r.bookmaker, homeWinOdds: r.homeWinOdds, drawOdds: r.drawOdds, awayWinOdds: r.awayWinOdds,
    homeWinMovement: '0', drawMovement: '0', awayWinMovement: '0', sourceUpdatedAt: new Date(r.sourceUpdatedAt), recordedAt: now,
  }));
  return { match, history };
}

let cache: { expires: number; matches: LiveMatch[]; histories: Map<number, any[]> } | null = null;
const CACHE_MS = 5 * 60 * 1000;

export async function getLiveMatches(force = false) {
  if (!force && cache && cache.expires > Date.now()) return cache;
  const events = await fetchMultipleLeaguesOdds();
  const transformed = events
    .filter(e => new Date(e.commence_time).getTime() >= Date.now())
    .map(transform)
    .sort((a,b) => a.match.matchDate.getTime() - b.match.matchDate.getTime());
  cache = { expires: Date.now() + CACHE_MS, matches: transformed.map(x => x.match), histories: new Map(transformed.map(x => [x.match.id, x.history])) };
  return cache;
}

export async function getLivePredictions(limit = 20) {
  const live = await getLiveMatches();
  const candidates = live.matches.slice(0, Math.min(limit, Number(process.env.LIVE_PREDICTION_LIMIT || 12)));
  const results: LivePrediction[] = [];
  for (const match of candidates) {
    try {
      // No database means no API-Football team IDs. This is deliberately labelled as a market fallback;
      // it never invents form/H2H data. Full V2.3 team modelling activates automatically when DB-enriched data exists.
      const prediction = await generatePrediction({ match: match as any, oddsHistory: live.histories.get(match.id) || [] }, { skipAiReasoning: true });
      results.push({ ...prediction, matchId: match.id, match, dataMode: 'live-api' });
    } catch (error) {
      console.warn('[LiveData] prediction failed:', match.homeTeam, match.awayTeam, error);
    }
  }
  return results.sort((a,b) => (Number(b.expectedValue ?? -1e9) - Number(a.expectedValue ?? -1e9)) || (b.confidence-a.confidence));
}

export function clearLiveCache() { cache = null; }
