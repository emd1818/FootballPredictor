import { describe, it, expect, beforeEach, vi } from 'vitest';
import { getMatchOfTheDay } from './match-of-day';

describe('Match of the Day', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('should handle database errors gracefully', async () => {
    // Test that the function handles errors gracefully
    const result = await getMatchOfTheDay();
    // Result should be null or have valid structure
    if (result !== null) {
      expect(result).toHaveProperty('predictionId');
    }
  });

  it('should identify the most interesting match based on confidence', async () => {
    const result = await getMatchOfTheDay();
    
    // Result can be null if no predictions exist, or should have expected structure
    if (result) {
      expect(result).toHaveProperty('predictionId');
      expect(result).toHaveProperty('matchId');
      expect(result).toHaveProperty('homeTeam');
      expect(result).toHaveProperty('awayTeam');
      expect(result).toHaveProperty('confidence');
      expect(result).toHaveProperty('volatilityScore');
      expect(result).toHaveProperty('interestingnessScore');
      
      // Validate confidence is a number between 0-100
      expect(result.confidence).toBeGreaterThanOrEqual(0);
      expect(result.confidence).toBeLessThanOrEqual(100);
      
      // Validate volatility score is non-negative
      expect(result.volatilityScore).toBeGreaterThanOrEqual(0);
      
      // Validate interestingness score is calculated
      expect(result.interestingnessScore).toBeGreaterThanOrEqual(0);
    }
  });

  it('should calculate interestingness score correctly', async () => {
    const result = await getMatchOfTheDay();
    
    if (result) {
      // Interestingness = (confidence * 0.7) + (volatility * 0.3)
      const expectedScore = (result.confidence * 0.7) + (result.volatilityScore * 0.3);
      expect(result.interestingnessScore).toBe(Math.round(expectedScore * 100) / 100);
    }
  });

  it('should return prediction with valid structure', async () => {
    const result = await getMatchOfTheDay();
    
    if (result) {
      expect(typeof result.predictionId).toBe('number');
      expect(typeof result.matchId).toBe('number');
      expect(typeof result.homeTeam).toBe('string');
      expect(typeof result.awayTeam).toBe('string');
      expect(typeof result.confidence).toBe('number');
      expect(['home_win', 'draw', 'away_win']).toContain(result.prediction);
    }
  });

  it('should handle matches with no odds history gracefully', async () => {
    const result = await getMatchOfTheDay();
    
    // Should not throw error even if no odds history exists
    expect(result).toBeDefined();
  });
});
