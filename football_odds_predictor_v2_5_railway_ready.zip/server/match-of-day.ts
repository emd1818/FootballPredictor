import { getDb } from './db';
import { matches, predictions, oddsHistory } from '../drizzle/schema';
import { eq, and, gte, lt, desc } from 'drizzle-orm';

/**
 * Identifies the most interesting match of the day based on:
 * - Highest confidence score
 * - Significant odds movement
 * - High volatility indicating market uncertainty
 */
export async function getMatchOfTheDay() {
  const db = await getDb();
  if (!db) {
    console.warn('[MatchOfDay] Database not available');
    return null;
  }

  try {
    // Get today's date range, extending to 7 days
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const sevenDaysFromNow = new Date(today);
    sevenDaysFromNow.setDate(sevenDaysFromNow.getDate() + 7);

    // Fetch upcoming predictions with highest confidence (next 7 days)
    const topPredictions = await db
      .select({
        predictionId: predictions.id,
        matchId: predictions.matchId,
        homeTeam: matches.homeTeam,
        awayTeam: matches.awayTeam,
        matchDate: matches.matchDate,
        league: matches.league,
        prediction: predictions.prediction,
        confidence: predictions.confidence,
        reasoning: predictions.reasoning,
        oddsMovementScore: predictions.oddsMovementScore,
        volatilityScore: predictions.volatilityScore,
      })
      .from(predictions)
      .innerJoin(matches, eq(predictions.matchId, matches.id))
      .where(
        and(
          gte(matches.matchDate, today),
          lt(matches.matchDate, sevenDaysFromNow)
        )
      )
      .orderBy(desc(predictions.confidence))
      .limit(1);

    if (topPredictions.length === 0) {
      console.log('[MatchOfDay] No predictions found for the next 7 days');
      return null;
    }

    const topPrediction = topPredictions[0];

    // Calculate odds volatility for this match
    const oddsRecords = await db
      .select()
      .from(oddsHistory)
      .where(eq(oddsHistory.matchId, topPrediction.matchId))
      .orderBy(desc(oddsHistory.recordedAt));

    let volatilityScore = topPrediction.volatilityScore || 0;
    if (oddsRecords.length > 1) {
      // Calculate average odds movement across bookmakers
      const movements = oddsRecords
        .slice(0, 5) // Use last 5 records
        .map(record => {
          const homeMovement = parseFloat(record.homeWinMovement || '0');
          const drawMovement = parseFloat(record.drawMovement || '0');
          const awayMovement = parseFloat(record.awayWinMovement || '0');
          return Math.abs(homeMovement) + Math.abs(drawMovement) + Math.abs(awayMovement);
        });

      volatilityScore = movements.reduce((a, b) => a + b, 0) / movements.length;
    }

    // Calculate "interestingness" score
    const interestingnessScore = (topPrediction.confidence * 0.7) + (volatilityScore * 0.3);

    return {
      predictionId: topPrediction.predictionId,
      matchId: topPrediction.matchId,
      homeTeam: topPrediction.homeTeam,
      awayTeam: topPrediction.awayTeam,
      matchDate: topPrediction.matchDate,
      league: topPrediction.league,
      prediction: topPrediction.prediction,
      confidence: topPrediction.confidence,
      reasoning: topPrediction.reasoning,
      oddsMovementScore: topPrediction.oddsMovementScore || 0,
      volatilityScore: Math.round(volatilityScore * 100) / 100,
      interestingnessScore: Math.round(interestingnessScore * 100) / 100,
    };
  } catch (error) {
    console.error('[MatchOfDay] Error fetching match of the day:', error);
    return null;
  }
}

export type MatchOfDay = Awaited<ReturnType<typeof getMatchOfTheDay>>;
