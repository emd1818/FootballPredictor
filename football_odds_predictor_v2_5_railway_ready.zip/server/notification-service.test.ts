import { describe, it, expect, beforeEach, vi } from 'vitest';
import { shouldNotify, notifyHighConfidencePrediction, getPredictionLabel } from './notification-service';

describe('NotificationService', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('shouldNotify', () => {
    it('should return true when confidence exceeds threshold', async () => {
      const result = await shouldNotify(1, 80);
      expect(result).toBe(true);
    });

    it('should return true when confidence equals threshold', async () => {
      const result = await shouldNotify(1, 75);
      expect(result).toBe(true);
    });

    it('should return false when confidence is below threshold', async () => {
      const result = await shouldNotify(1, 70);
      expect(result).toBe(false);
    });
  });

  describe('notifyHighConfidencePrediction', () => {
    it('should create notification for high-confidence prediction', async () => {
      const trigger = {
        userId: 1,
        predictionId: 1,
        matchId: 1,
        confidence: 85,
        prediction: 'home_win' as const,
        reasoning: 'Strong odds movement',
      };

      // Mock the database functions
      vi.mock('./db', () => ({
        getOrCreateNotificationPreferences: vi.fn().mockResolvedValue({
          confidenceThreshold: 75,
          enableEmailNotifications: 1,
          enableInAppNotifications: 1,
        }),
        getMatchById: vi.fn().mockResolvedValue({
          id: 1,
          homeTeam: 'Manchester United',
          awayTeam: 'Liverpool',
          league: 'Premier League',
          matchDate: new Date(),
          status: 'upcoming',
        }),
        createNotification: vi.fn().mockResolvedValue({ id: 1 }),
      }));

      // Note: In a real test, we would verify the notification was created
      // For now, just verify the function doesn't throw
      await expect(notifyHighConfidencePrediction(trigger)).resolves.not.toThrow();
    });

    it('should not notify when confidence is below threshold', async () => {
      const trigger = {
        userId: 1,
        predictionId: 1,
        matchId: 1,
        confidence: 70,
        prediction: 'home_win' as const,
        reasoning: 'Weak signal',
      };

      // Should complete without error but not create notification
      await expect(notifyHighConfidencePrediction(trigger)).resolves.not.toThrow();
    });
  });

  describe('getPredictionLabel', () => {
    it('should return home team name for home_win prediction', () => {
      const label = getPredictionLabel('home_win', 'Manchester United', 'Liverpool');
      expect(label).toBe('Manchester United Win');
    });

    it('should return away team name for away_win prediction', () => {
      const label = getPredictionLabel('away_win', 'Manchester United', 'Liverpool');
      expect(label).toBe('Liverpool Win');
    });

    it('should return Draw for draw prediction', () => {
      const label = getPredictionLabel('draw', 'Manchester United', 'Liverpool');
      expect(label).toBe('Draw');
    });

    it('should return prediction string for unknown prediction', () => {
      const label = getPredictionLabel('unknown', 'Team A', 'Team B');
      expect(label).toBe('unknown');
    });
  });
});
