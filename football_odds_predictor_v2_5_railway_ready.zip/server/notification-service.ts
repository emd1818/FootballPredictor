/**
 * Notification Service
 * Handles sending notifications to users when high-confidence predictions are generated
 */

import { createNotification, getOrCreateNotificationPreferences, getMatchById } from './db';
import { notifyOwner } from './_core/notification';
import type { InsertNotification } from '../drizzle/schema';

export interface NotificationTrigger {
  userId: number;
  predictionId: number;
  matchId: number;
  confidence: number;
  prediction: 'home_win' | 'draw' | 'away_win';
  reasoning?: string;
}

/**
 * Check if a prediction should trigger a notification
 */
export async function shouldNotify(userId: number, confidence: number): Promise<boolean> {
  try {
    const prefs = await getOrCreateNotificationPreferences(userId);
    return confidence >= (prefs.confidenceThreshold || 75);
  } catch (error) {
    console.error('[NotificationService] Error checking notification preferences:', error);
    return false;
  }
}

/**
 * Send notification for a high-confidence prediction
 */
export async function notifyHighConfidencePrediction(trigger: NotificationTrigger): Promise<void> {
  try {
    // Check if user should be notified
    const shouldSend = await shouldNotify(trigger.userId, trigger.confidence);
    if (!shouldSend) {
      console.log(`[NotificationService] Prediction ${trigger.predictionId} below threshold for user ${trigger.userId}`);
      return;
    }

    // Get match details
    const match = await getMatchById(trigger.matchId);
    if (!match) {
      console.warn(`[NotificationService] Match ${trigger.matchId} not found`);
      return;
    }

    // Get user preferences
    const prefs = await getOrCreateNotificationPreferences(trigger.userId);

    // Prepare notification message
    const predictionLabel = getPredictionLabel(trigger.prediction, match.homeTeam, match.awayTeam);
    const title = `High-Confidence Prediction: ${predictionLabel}`;
    const message = `${match.homeTeam} vs ${match.awayTeam} (${match.league}) - Confidence: ${trigger.confidence}%${trigger.reasoning ? `\n\n${trigger.reasoning}` : ''}`;

    // Create notification record
    const notificationType = getNotificationType(prefs);
    const notification: InsertNotification = {
      userId: trigger.userId,
      predictionId: trigger.predictionId,
      matchId: trigger.matchId,
      title,
      message,
      confidence: trigger.confidence,
      prediction: trigger.prediction,
      notificationType,
      isRead: 0,
    };

    await createNotification(notification);
    console.log(`[NotificationService] Created notification for user ${trigger.userId}, prediction ${trigger.predictionId}`);

    // Send email notification if enabled
    if (prefs.enableEmailNotifications) {
      await sendEmailNotification(trigger.userId, title, message);
    }

    // Notify owner about high-confidence prediction
    if (trigger.confidence >= 85) {
      await notifyOwner({
        title: `🔥 Very High Confidence Prediction (${trigger.confidence}%)`,
        content: `${predictionLabel}\n${match.homeTeam} vs ${match.awayTeam}\n${match.league}\n\n${trigger.reasoning || 'No reasoning provided'}`,
      });
    }
  } catch (error) {
    console.error('[NotificationService] Error sending notification:', error);
  }
}

/**
 * Send email notification
 */
async function sendEmailNotification(userId: number, title: string, message: string): Promise<void> {
  try {
    console.log(`[NotificationService] Email notification would be sent to user ${userId}: ${title}`);
    // In production, integrate with email service (SendGrid, AWS SES, etc.)
    // For now, just log it
  } catch (error) {
    console.error('[NotificationService] Error sending email:', error);
  }
}

/**
 * Get notification type based on user preferences
 */
function getNotificationType(prefs: any): 'email' | 'in_app' | 'both' {
  if (prefs.enableEmailNotifications && prefs.enableInAppNotifications) {
    return 'both';
  } else if (prefs.enableEmailNotifications) {
    return 'email';
  } else {
    return 'in_app';
  }
}

/**
 * Get human-readable prediction label
 */
export function getPredictionLabel(prediction: string, homeTeam: string, awayTeam: string): string {
  switch (prediction) {
    case 'home_win':
      return `${homeTeam} Win`;
    case 'away_win':
      return `${awayTeam} Win`;
    case 'draw':
      return 'Draw';
    default:
      return prediction;
  }
}

/**
 * Batch notify for multiple high-confidence predictions
 */
export async function notifyBatch(triggers: NotificationTrigger[]): Promise<void> {
  console.log(`[NotificationService] Processing ${triggers.length} notifications`);
  
  for (const trigger of triggers) {
    await notifyHighConfidencePrediction(trigger);
  }
  
  console.log('[NotificationService] Batch notification processing complete');
}
