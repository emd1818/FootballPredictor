import { describe, it, expect, beforeEach, vi } from 'vitest';
import {
  fetchFootballOdds,
  fetchMultipleLeaguesOdds,
  extractOddsData,
  isApiKeyConfigured,
  type OddsEvent,
} from './odds-api-client';

describe('OddsApiClient', () => {
  beforeEach(() => {
    // Clear environment variable before each test
    delete process.env.ODDS_API_KEY;
  });

  describe('isApiKeyConfigured', () => {
    it('should return false when ODDS_API_KEY is not set', () => {
      expect(isApiKeyConfigured()).toBe(false);
    });

    it('should return true when ODDS_API_KEY is set', () => {
      process.env.ODDS_API_KEY = 'test-api-key';
      expect(isApiKeyConfigured()).toBe(true);
    });
  });

  describe('fetchFootballOdds', () => {
    it('should return empty array when API key is not configured', async () => {
      const result = await fetchFootballOdds();
      expect(result).toEqual([]);
    });

    it('should return empty array on API error', async () => {
      process.env.ODDS_API_KEY = 'invalid-key';
      
      // Mock fetch to simulate API error
      global.fetch = vi.fn(() =>
        Promise.resolve({
          ok: false,
          status: 401,
          statusText: 'Unauthorized',
        } as Response)
      );

      const result = await fetchFootballOdds();
      expect(result).toEqual([]);
    });
  });

  describe('extractOddsData', () => {
    it('should extract odds data from event bookmakers', () => {
      const mockEvent: OddsEvent = {
        id: 'test-event-1',
        sport_key: 'soccer_epl',
        sport_title: 'Premier League',
        commence_time: '2024-12-02T15:00:00Z',
        home_team: 'Manchester United',
        away_team: 'Liverpool',
        bookmakers: [
          {
            key: 'bet365',
            title: 'Bet365',
            last_update: '2024-12-02T14:00:00Z',
            markets: [
              {
                key: 'h2h',
                outcomes: [
                  { name: 'Manchester United', price: 2.1 },
                  { name: 'Draw', price: 3.5 },
                  { name: 'Liverpool', price: 3.2 },
                ],
              },
            ],
          },
          {
            key: 'unibet',
            title: 'Unibet',
            last_update: '2024-12-02T14:00:00Z',
            markets: [
              {
                key: 'h2h',
                outcomes: [
                  { name: 'Manchester United', price: 2.15 },
                  { name: 'Draw', price: 3.4 },
                  { name: 'Liverpool', price: 3.15 },
                ],
              },
            ],
          },
        ],
      };

      const result = extractOddsData(mockEvent);

      expect(result).toHaveLength(2);
      expect(result[0]).toEqual({
        bookmaker: 'Bet365',
        homeWinOdds: '2.1',
        drawOdds: '3.5',
        awayWinOdds: '3.2',
      });
      expect(result[1]).toEqual({
        bookmaker: 'Unibet',
        homeWinOdds: '2.15',
        drawOdds: '3.4',
        awayWinOdds: '3.15',
      });
    });

    it('should handle events with missing draw outcome', () => {
      const mockEvent: OddsEvent = {
        id: 'test-event-2',
        sport_key: 'soccer_epl',
        sport_title: 'Premier League',
        commence_time: '2024-12-02T15:00:00Z',
        home_team: 'Arsenal',
        away_team: 'Chelsea',
        bookmakers: [
          {
            key: 'bet365',
            title: 'Bet365',
            last_update: '2024-12-02T14:00:00Z',
            markets: [
              {
                key: 'h2h',
                outcomes: [
                  { name: 'Arsenal', price: 1.9 },
                  { name: 'Chelsea', price: 3.8 },
                ],
              },
            ],
          },
        ],
      };

      const result = extractOddsData(mockEvent);

      expect(result).toHaveLength(1);
      expect(result[0]).toEqual({
        bookmaker: 'Bet365',
        homeWinOdds: '1.9',
        drawOdds: '0',
        awayWinOdds: '3.8',
      });
    });

    it('should return empty array for events with no bookmakers', () => {
      const mockEvent: OddsEvent = {
        id: 'test-event-3',
        sport_key: 'soccer_epl',
        sport_title: 'Premier League',
        commence_time: '2024-12-02T15:00:00Z',
        home_team: 'Tottenham',
        away_team: 'Manchester City',
        bookmakers: [],
      };

      const result = extractOddsData(mockEvent);
      expect(result).toEqual([]);
    });
  });

  describe('fetchMultipleLeaguesOdds', () => {
    it('should return empty array when API key is not configured', async () => {
      const result = await fetchMultipleLeaguesOdds();
      expect(result).toEqual([]);
    });
  });
});
