/**
 * The Odds API Client
 * Fetches live football odds from multiple bookmakers
 * API Documentation: https://the-odds-api.com/liveapi/guides/v4/
 */

const ODDS_API_BASE_URL = 'https://api.the-odds-api.com/v4';

export interface OddsOutcome {
  name: string;
  price: number;
}

export interface OddsMarket {
  key: string;
  outcomes: OddsOutcome[];
}

export interface Bookmaker {
  key: string;
  title: string;
  last_update: string;
  markets: OddsMarket[];
}

export interface OddsEvent {
  id: string;
  sport_key: string;
  sport_title: string;
  commence_time: string;
  home_team: string;
  away_team: string;
  bookmakers: Bookmaker[];
}

export interface OddsApiResponse {
  events: OddsEvent[];
  nextUpdate?: string;
}

/**
 * Fetch live football odds from The Odds API
 */
export async function fetchFootballOdds(): Promise<OddsEvent[]> {
  const apiKey = process.env.ODDS_API_KEY;
  
  if (!apiKey) {
    console.warn('[OddsAPI] No API key configured. Real-data ingestion is disabled.');
    return [];
  }

  try {
    // Fetch upcoming soccer/football matches with odds
    const params = new URLSearchParams({
      apiKey,
      regions: 'eu,uk', // Europe and UK bookmakers
      markets: 'h2h', // Head-to-head (moneyline) odds
      oddsFormat: 'decimal', // Decimal odds format
    });

    const sportKey = (process.env.ODDS_LEAGUES || 'soccer_epl').split(',').map(v => v.trim()).filter(Boolean)[0] || 'soccer_epl';
    const response = await fetch(`${ODDS_API_BASE_URL}/sports/${sportKey}/odds?${params}`,  {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
      },
    });

    if (!response.ok) {
      if (response.status === 401) {
        console.error('[OddsAPI] Unauthorized - invalid API key');
      } else if (response.status === 429) {
        console.error('[OddsAPI] Rate limit exceeded');
      } else {
        console.error(`[OddsAPI] Error: ${response.status} ${response.statusText}`);
      }
      return [];
    }

    const data = (await response.json()) as OddsApiResponse | OddsEvent[];
    const events = Array.isArray(data) ? data : (data as OddsApiResponse).events || [];
    console.log(`[OddsAPI] Fetched ${events.length} football matches with odds`);
    return events;
  } catch (error) {
    console.error('[OddsAPI] Failed to fetch odds:', error);
    return [];
  }
}

/**
 * Fetch odds for multiple football leagues
 */
let leagueRotationIndex = 0;

/**
 * Fetch odds from a rotating subset of configured leagues.
 * This prevents a free/low-quota plan from spending one request per league every 30 minutes.
 * Set ODDS_LEAGUES_PER_CYCLE to the number appropriate for the subscription.
 */
export async function fetchMultipleLeaguesOdds(): Promise<OddsEvent[]> {
  const apiKey = process.env.ODDS_API_KEY;
  if (!apiKey) {
    console.warn('[OddsAPI] No API key configured. Real-data ingestion is disabled.');
    return [];
  }

  const leagues = (process.env.ODDS_LEAGUES || [
    'soccer_epl', 'soccer_spain_la_liga', 'soccer_italy_serie_a',
    'soccer_germany_bundesliga', 'soccer_france_ligue_one',
    'soccer_netherlands_eredivisie', 'soccer_portugal_primeira_liga',
    'soccer_turkey_super_league', 'soccer_uefa_champs_league',
    'soccer_uefa_europa_league', 'soccer_uefa_europa_conference_league',
  ].join(',')).split(',').map(v => v.trim()).filter(Boolean);

  if (!leagues.length) return [];

  const configuredCount = Math.max(1, Number(process.env.ODDS_LEAGUES_PER_CYCLE || '2'));
  const count = Math.min(configuredCount, leagues.length);
  const selected = Array.from({ length: count }, (_, offset) => leagues[(leagueRotationIndex + offset) % leagues.length]);
  leagueRotationIndex = (leagueRotationIndex + count) % leagues.length;

  const allEvents: OddsEvent[] = [];
  for (const league of selected) {
    try {
      const params = new URLSearchParams({
        apiKey, regions: process.env.ODDS_REGIONS || 'eu,uk',
        markets: 'h2h', oddsFormat: 'decimal',
      });
      const response = await fetch(`${ODDS_API_BASE_URL}/sports/${league}/odds?${params}`, {
        method: 'GET', headers: { Accept: 'application/json' },
      });
      if (response.ok) {
        const data = await response.json() as OddsApiResponse | OddsEvent[];
        const events = Array.isArray(data) ? data : (data as OddsApiResponse).events || [];
        allEvents.push(...events);
        console.log(`[OddsAPI] Fetched ${events.length} matches from ${league}`);
      } else {
        const errorText = await response.text().catch(() => '');
        console.warn(`[OddsAPI] Failed ${league}: ${response.status} ${response.statusText}`, errorText.slice(0, 160));
      }
    } catch (error) {
      console.warn(`[OddsAPI] Failed ${league}:`, error);
    }
  }

  // Same event can appear through overlapping provider/league feeds. Keep one event per external event id.
  const unique = new Map<string, OddsEvent>();
  for (const event of allEvents) unique.set(event.id, event);
  console.log(`[OddsAPI] Cycle fetched ${unique.size} unique football matches from ${selected.join(', ')}`);
  return [...unique.values()];
}

/**
 * Extract odds movement data from bookmakers
 */
export function extractOddsData(event: OddsEvent) {
  const oddsData: Array<{
    bookmaker: string;
    sourceUpdatedAt: string;
    homeWinOdds: string;
    drawOdds: string;
    awayWinOdds: string;
  }> = [];

  for (const bookmaker of event.bookmakers) {
    const h2hMarket = bookmaker.markets.find((m) => m.key === 'h2h');
    if (!h2hMarket || h2hMarket.outcomes.length < 2) continue;

    // Extract odds for home win, draw, and away win
    const homeOutcome = h2hMarket.outcomes.find((o) => o.name === event.home_team);
    const awayOutcome = h2hMarket.outcomes.find((o) => o.name === event.away_team);

    // For soccer, there might be a draw outcome
    const drawOutcome = h2hMarket.outcomes.find((o) => o.name === 'Draw');

    if (homeOutcome && awayOutcome) {
      oddsData.push({
        bookmaker: bookmaker.title,
        sourceUpdatedAt: bookmaker.last_update,
        homeWinOdds: homeOutcome.price.toString(),
        drawOdds: drawOutcome?.price.toString() || '0',
        awayWinOdds: awayOutcome.price.toString(),
      });
    }
  }

  return oddsData;
}

/**
 * Check if API key is configured
 */
export function isApiKeyConfigured(): boolean {
  return !!process.env.ODDS_API_KEY;
}

/**
 * Fetch one historical odds snapshot. Requires a paid The Odds API plan.
 * The API returns the closest snapshot at or before the requested timestamp.
 */
export async function fetchHistoricalFootballOddsSnapshot(
  sportKey: string,
  date: Date,
  regions = 'eu,uk',
  market = 'h2h',
): Promise<{ timestamp: string; previousTimestamp?: string; nextTimestamp?: string; events: OddsEvent[] }> {
  const apiKey = process.env.ODDS_API_KEY;
  if (!apiKey) throw new Error('ODDS_API_KEY is not configured');
  const params = new URLSearchParams({
    apiKey,
    regions,
    markets: market,
    oddsFormat: 'decimal',
    date: date.toISOString(),
  });
  const response = await fetch(`${ODDS_API_BASE_URL}/historical/sports/${sportKey}/odds?${params}`, {
    headers: { Accept: 'application/json' },
  });
  if (!response.ok) {
    const body = await response.text().catch(() => '');
    throw new Error(`Historical Odds API ${response.status} ${response.statusText}: ${body.slice(0, 300)}`);
  }
  const payload = await response.json() as any;
  return {
    timestamp: payload.timestamp,
    previousTimestamp: payload.previous_timestamp,
    nextTimestamp: payload.next_timestamp,
    events: Array.isArray(payload.data) ? payload.data : [],
  };
}
