import { getDb } from './db';
import { matchResults, predictionAccuracy, predictions, matches } from '../drizzle/schema';
import { eq, and, gte, lte } from 'drizzle-orm';

export interface PerformanceMetrics {
  totalPredictions: number;
  correctPredictions: number;
  accuracy: number; // percentage
  averageConfidence: number;
  winRate: number; // percentage
  roi: number; // return on investment
  brierScore: number;
  logLoss: number;
  calibrationError: number;
  predictionsByConfidence: ConfidenceBucketStats[];
  recentPerformance: DailyPerformance[];
}

export interface ConfidenceBucketStats {
  bucket: string;
  count: number;
  correct: number;
  accuracy: number;
}

export interface DailyPerformance {
  date: string;
  predictions: number;
  correct: number;
  accuracy: number;
}

/**
 * Record a match result and evaluate predictions
 */
export async function recordMatchResult(
  matchId: number,
  result: 'home_win' | 'draw' | 'away_win',
  homeScore?: number,
  awayScore?: number
): Promise<void> {
  const db = await getDb();
  if (!db) {
    console.warn('[PerformanceAnalytics] Database not available');
    return;
  }

  try {
    // Record the match result
    await db.insert(matchResults).values({
      matchId,
      result,
      homeScore,
      awayScore,
      resultRecordedAt: new Date(),
    }).onDuplicateKeyUpdate({
      set: {
        result,
        homeScore,
        awayScore,
        resultRecordedAt: new Date(),
      },
    });

    // Get all predictions for this match
    const matchPredictions = await db
      .select()
      .from(predictions)
      .where(eq(predictions.matchId, matchId));

    // Evaluate each prediction
    for (const pred of matchPredictions) {
      const isCorrect = pred.prediction === result ? 1 : 0;
      const confidenceBucket = getConfidenceBucket(pred.confidence);
      const probability = Number(pred.prediction === 'home_win' ? pred.homeProbability : pred.prediction === 'draw' ? pred.drawProbability : pred.awayProbability) / 100;
      const safeProbability = Number.isFinite(probability) && probability > 0 ? Math.min(0.999999, probability) : Math.max(0.000001, pred.confidence / 100);
      const brier = (['home_win','draw','away_win'] as const).reduce((sum, outcome) => {
        const p = Number(pred[outcome === 'home_win' ? 'homeProbability' : outcome === 'draw' ? 'drawProbability' : 'awayProbability']) / 100;
        const y = outcome === result ? 1 : 0;
        return sum + (Number.isFinite(p) ? (p-y)*(p-y) : 0);
      }, 0);
      const logLoss = -Math.log(safeProbability);
      const odds = Number(pred.prediction === 'home_win' ? pred.homeWinOdds : pred.prediction === 'draw' ? pred.drawOdds : pred.awayWinOdds);
      const profitUnits = Number.isFinite(odds) && odds > 1 ? (isCorrect ? odds - 1 : -1) : 0;

      await db.insert(predictionAccuracy).values({
        predictionId: pred.id, matchId, prediction: pred.prediction, confidence: pred.confidence, actualResult: result, isCorrect, confidenceBucket,
        predictedProbability: safeProbability * 100, brierScore: brier, logLoss, oddsAtPrediction: Number.isFinite(odds) ? odds : null,
        expectedValue: pred.expectedValue, profitUnits, evaluatedAt: new Date(),
      }).onDuplicateKeyUpdate({
        set: { actualResult: result, isCorrect, predictedProbability: safeProbability * 100, brierScore: brier, logLoss, oddsAtPrediction: Number.isFinite(odds) ? odds : null, expectedValue: pred.expectedValue, profitUnits, evaluatedAt: new Date() },
      });
    }

    console.log(`[PerformanceAnalytics] Recorded result for match ${matchId}: ${result}`);
  } catch (error) {
    console.error('[PerformanceAnalytics] Failed to record match result:', error);
    throw error;
  }
}

/**
 * Get overall performance metrics
 */
export async function getPerformanceMetrics(
  daysBack: number = 30
): Promise<PerformanceMetrics> {
  const db = await getDb();
  if (!db) {
    console.warn('[PerformanceAnalytics] Database not available');
    return {
      totalPredictions: 0,
      correctPredictions: 0,
      accuracy: 0,
      averageConfidence: 0,
      winRate: 0,
      roi: 0,
      brierScore: 0,
      logLoss: 0,
      calibrationError: 0,
      predictionsByConfidence: [],
      recentPerformance: [],
    };
  }

  try {
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - daysBack);

    // Get all evaluated predictions in the time range
    const accuracyData = await db
      .select()
      .from(predictionAccuracy)
      .where(gte(predictionAccuracy.evaluatedAt, cutoffDate));

    if (accuracyData.length === 0) {
      return {
        totalPredictions: 0,
        correctPredictions: 0,
        accuracy: 0,
        averageConfidence: 0,
        winRate: 0,
        roi: 0,
        brierScore: 0,
        logLoss: 0,
        calibrationError: 0,
        predictionsByConfidence: [],
        recentPerformance: [],
      };
    }

    // Calculate overall metrics
    const totalPredictions = accuracyData.length;
    const correctPredictions = accuracyData.filter(a => a.isCorrect === 1).length;
    const accuracy = (correctPredictions / totalPredictions) * 100;
    const averageConfidence = accuracyData.reduce((sum, a) => sum + a.confidence, 0) / totalPredictions;
    const averagePredictedProbability = accuracyData.reduce((sum, a) => sum + Number(a.predictedProbability || a.confidence), 0) / totalPredictions;

    // Calculate by confidence bucket
    const bucketMap = new Map<string, { count: number; correct: number }>();
    for (const acc of accuracyData) {
      const bucket = acc.confidenceBucket;
      const current = bucketMap.get(bucket) || { count: 0, correct: 0 };
      current.count++;
      if (acc.isCorrect === 1) current.correct++;
      bucketMap.set(bucket, current);
    }

    const predictionsByConfidence: ConfidenceBucketStats[] = Array.from(bucketMap.entries())
      .map(([bucket, stats]) => ({
        bucket,
        count: stats.count,
        correct: stats.correct,
        accuracy: (stats.correct / stats.count) * 100,
      }))
      .sort((a, b) => {
        const aMin = parseInt(a.bucket.split('-')[0]);
        const bMin = parseInt(b.bucket.split('-')[0]);
        return aMin - bMin;
      });

    // Calculate daily performance
    const dailyMap = new Map<string, { predictions: number; correct: number }>();
    for (const acc of accuracyData) {
      const date = new Date(acc.evaluatedAt).toISOString().split('T')[0];
      const current = dailyMap.get(date) || { predictions: 0, correct: 0 };
      current.predictions++;
      if (acc.isCorrect === 1) current.correct++;
      dailyMap.set(date, current);
    }

    const recentPerformance: DailyPerformance[] = Array.from(dailyMap.entries())
      .map(([date, stats]) => ({
        date,
        predictions: stats.predictions,
        correct: stats.correct,
        accuracy: (stats.correct / stats.predictions) * 100,
      }))
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
      .slice(-30); // Last 30 days

    const brierScore = accuracyData.reduce((sum, a) => sum + Number(a.brierScore || 0), 0) / totalPredictions;
    const logLoss = accuracyData.reduce((sum, a) => sum + Number(a.logLoss || 0), 0) / totalPredictions;
    const totalProfit = accuracyData.reduce((sum, a) => sum + Number(a.profitUnits || 0), 0);
    const roi = totalPredictions ? (totalProfit / totalPredictions) * 100 : 0;

    // Calibration error must compare predicted probability with empirical frequency
    // within the same probability bucket, not with overall accuracy.
    const calibrationBuckets = new Map<string, { predicted: number; correct: number; count: number }>();
    for (const acc of accuracyData) {
      const bucket = acc.confidenceBucket;
      const current = calibrationBuckets.get(bucket) || { predicted: 0, correct: 0, count: 0 };
      current.predicted += Number(acc.predictedProbability ?? acc.confidence) / 100;
      current.correct += acc.isCorrect === 1 ? 1 : 0;
      current.count += 1;
      calibrationBuckets.set(bucket, current);
    }
    const calibrationError = calibrationBuckets.size
      ? Array.from(calibrationBuckets.values()).reduce((sum, b) => sum + Math.abs(b.predicted / b.count - b.correct / b.count), 0) / calibrationBuckets.size * 100
      : 0;

    return { totalPredictions, correctPredictions, accuracy, averageConfidence, winRate: accuracy, roi, brierScore, logLoss, calibrationError, predictionsByConfidence, recentPerformance };
  } catch (error) {
    console.error('[PerformanceAnalytics] Failed to get performance metrics:', error);
    throw error;
  }
}

/**
 * Get accuracy by league
 */
export async function getAccuracyByLeague(
  daysBack: number = 30
): Promise<Array<{ league: string; accuracy: number; predictions: number }>> {
  const db = await getDb();
  if (!db) {
    console.warn('[PerformanceAnalytics] Database not available');
    return [];
  }

  try {
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - daysBack);

    const accuracyData = await db
      .select({
        league: matches.league,
        isCorrect: predictionAccuracy.isCorrect,
      })
      .from(predictionAccuracy)
      .innerJoin(matches, eq(predictionAccuracy.matchId, matches.id))
      .where(gte(predictionAccuracy.evaluatedAt, cutoffDate));

    const leagueMap = new Map<string, { predictions: number; correct: number }>();
    for (const acc of accuracyData) {
      const league = acc.league || 'Unknown';
      const current = leagueMap.get(league) || { predictions: 0, correct: 0 };
      current.predictions++;
      if (acc.isCorrect === 1) current.correct++;
      leagueMap.set(league, current);
    }

    return Array.from(leagueMap.entries())
      .map(([league, stats]) => ({
        league,
        accuracy: (stats.correct / stats.predictions) * 100,
        predictions: stats.predictions,
      }))
      .sort((a, b) => b.predictions - a.predictions);
  } catch (error) {
    console.error('[PerformanceAnalytics] Failed to get accuracy by league:', error);
    return [];
  }
}

/**
 * Get accuracy by prediction type
 */
export async function getAccuracyByPredictionType(
  daysBack: number = 30
): Promise<Array<{ type: string; accuracy: number; predictions: number }>> {
  const db = await getDb();
  if (!db) {
    console.warn('[PerformanceAnalytics] Database not available');
    return [];
  }

  try {
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - daysBack);

    const accuracyData = await db
      .select()
      .from(predictionAccuracy)
      .where(gte(predictionAccuracy.evaluatedAt, cutoffDate));

    const typeMap = new Map<string, { predictions: number; correct: number }>();
    for (const acc of accuracyData) {
      const type = acc.prediction;
      const current = typeMap.get(type) || { predictions: 0, correct: 0 };
      current.predictions++;
      if (acc.isCorrect === 1) current.correct++;
      typeMap.set(type, current);
    }

    return Array.from(typeMap.entries())
      .map(([type, stats]) => ({
        type: type.replace('_', ' ').toUpperCase(),
        accuracy: (stats.correct / stats.predictions) * 100,
        predictions: stats.predictions,
      }))
      .sort((a, b) => b.predictions - a.predictions);
  } catch (error) {
    console.error('[PerformanceAnalytics] Failed to get accuracy by prediction type:', error);
    return [];
  }
}

/**
 * Helper function to get confidence bucket
 */
function getConfidenceBucket(confidence: number): string {
  const bucket = Math.floor(confidence / 10) * 10;
  return `${bucket}-${bucket + 10}`;
}
