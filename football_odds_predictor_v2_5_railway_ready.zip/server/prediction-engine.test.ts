import { describe, it, expect, vi } from 'vitest';
import { generatePrediction, getFootballSeason, generateTopPredictions } from './prediction-engine';
import type { Match, OddsHistory } from '../drizzle/schema';

// Mock the LLM module
vi.mock('./_core/llm', () => ({
  invokeLLM: vi.fn(async () => ({
    choices: [
      {
        message: {
          content: 'Manchester United has stronger odds movement suggesting a home win.',
        },
      },
    ],
  })),
}));

describe('Prediction Engine', () => {
  const mockMatch: Match = {
    id: 1,
    externalId: 'match_1',
    homeTeam: 'Manchester United',
    awayTeam: 'Liverpool',
    league: 'Premier League',
    matchDate: new Date(Date.now() + 24 * 60 * 60 * 1000),
    status: 'upcoming',
    createdAt: new Date(),
    updatedAt: new Date(),
  };

  const mockOddsHistory: OddsHistory[] = [
    {
      id: 1,
      matchId: 1,
      homeWinOdds: '2.1',
      drawOdds: '3.2',
      awayWinOdds: '3.5',
      homeWinMovement: '-5.0',
      drawMovement: '2.0',
      awayWinMovement: '3.0',
      bookmaker: 'Bet365',
      sourceUpdatedAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
      recordedAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
      createdAt: new Date(),
    },
    {
      id: 2,
      matchId: 1,
      homeWinOdds: '2.0',
      drawOdds: '3.3',
      awayWinOdds: '3.6',
      homeWinMovement: '-4.8',
      drawMovement: '3.1',
      awayWinMovement: '2.9',
      bookmaker: 'William Hill',
      sourceUpdatedAt: new Date(Date.now() - 1 * 60 * 60 * 1000),
      recordedAt: new Date(Date.now() - 1 * 60 * 60 * 1000),
      createdAt: new Date(),
    },
  ];

  it('should generate a prediction with valid structure', async () => {
    const prediction = await generatePrediction({
      match: mockMatch,
      oddsHistory: mockOddsHistory,
    });

    expect(prediction).toBeDefined();
    expect(prediction.prediction).toMatch(/^(home_win|draw|away_win)$/);
    expect(prediction.confidence).toBeGreaterThanOrEqual(0);
    expect(prediction.confidence).toBeLessThanOrEqual(100);
    expect(prediction.reasoning).toBeTruthy();
    expect(prediction.oddsMovementScore).toBeGreaterThanOrEqual(0);
    expect(prediction.oddsMovementScore).toBeLessThanOrEqual(100);
    expect(prediction.volatilityScore).toBeGreaterThanOrEqual(0);
    expect(prediction.volatilityScore).toBeLessThanOrEqual(100);
  });

  it('should identify home win when home odds are lowest', async () => {
    const prediction = await generatePrediction({
      match: mockMatch,
      oddsHistory: mockOddsHistory,
    });

    expect(prediction.prediction).toBe('home_win');
  });

  it('should calculate odds movement score correctly', async () => {
    const prediction = await generatePrediction({
      match: mockMatch,
      oddsHistory: mockOddsHistory,
    });

    // With -5% and -4.8% movements, should have non-zero movement score
    expect(prediction.oddsMovementScore).toBeGreaterThan(0);
  });

  it('should handle empty odds history gracefully', async () => {
    const prediction = await generatePrediction({
      match: mockMatch,
      oddsHistory: [],
    });

    expect(prediction).toBeDefined();
    expect(prediction.prediction).toBeDefined();
    expect(prediction.confidence).toBeLessThanOrEqual(50); // Lower confidence with no data
  });

  it('should generate top predictions and rank by confidence', async () => {
    const matches: Match[] = [
      mockMatch,
      {
        ...mockMatch,
        id: 2,
        externalId: 'match_2',
        homeTeam: 'Chelsea',
        awayTeam: 'Arsenal',
      },
      {
        ...mockMatch,
        id: 3,
        externalId: 'match_3',
        homeTeam: 'Tottenham',
        awayTeam: 'Manchester City',
      },
    ];

    const inputs = matches.map((match) => ({
      match,
      oddsHistory: mockOddsHistory.map((oh) => ({
        ...oh,
        matchId: match.id,
      })),
    }));

    const topPredictions = await generateTopPredictions(inputs, 2);

    expect(topPredictions).toHaveLength(2);
    expect(topPredictions[0].confidence).toBeGreaterThanOrEqual(topPredictions[1].confidence);
    expect(topPredictions[0].matchId).toBeDefined();
    expect(topPredictions[1].matchId).toBeDefined();
  });

  it('should limit predictions to requested count', async () => {
    const matches: Match[] = Array.from({ length: 10 }, (_, i) => ({
      ...mockMatch,
      id: i + 1,
      externalId: `match_${i + 1}`,
    }));

    const inputs = matches.map((match) => ({
      match,
      oddsHistory: mockOddsHistory.map((oh) => ({
        ...oh,
        matchId: match.id,
      })),
    }));

    const topPredictions = await generateTopPredictions(inputs, 5);

    expect(topPredictions.length).toBeLessThanOrEqual(5);
  });
});

describe('football season boundaries', () => {
  it('keeps January-June in the previous season', () => {
    expect(getFootballSeason('2026-01-15T12:00:00Z')).toBe(2025);
    expect(getFootballSeason('2026-06-30T12:00:00Z')).toBe(2025);
  });
  it('starts a new season in July', () => {
    expect(getFootballSeason('2026-07-01T12:00:00Z')).toBe(2026);
  });
});
