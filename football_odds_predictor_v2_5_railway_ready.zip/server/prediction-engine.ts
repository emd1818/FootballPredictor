/**
 * Prediction Engine V2
 *
 * The engine treats bookmaker odds as a market prior, not as the prediction itself.
 * An independent team-strength / goal model is blended with the market and then
 * calibrated into probabilities. AI is used only as an explanation layer.
 */
import { invokeLLM } from './_core/llm';
import type { Match, OddsHistory } from '../drizzle/schema';
import { notifyBatch } from './notification-service';
import { getWalkForwardCalibration, applyTemperature } from './probability-calibration';
import {
  fetchTeamFormStats,
  fetchHeadToHeadStats,
  analyzeTeamForm,
  analyzeH2HAdvantage,
  type TeamFormStats,
  type HeadToHeadStats,
} from './team-stats-client';

export type Outcome = 'home_win' | 'draw' | 'away_win';

export interface PredictionInput {
  match: Match;
  oddsHistory: OddsHistory[];
}

export interface GeneratedPrediction {
  prediction: Outcome;
  confidence: number;
  reasoning: string;
  oddsMovementScore: number;
  volatilityScore: number;
  homeFormScore?: number;
  awayFormScore?: number;
  h2hAdvantage?: number;
  recentFormHome?: string;
  recentFormAway?: string;
  bookmakerDisagreement?: number;
  riskLevel?: 'low' | 'medium' | 'high';
  valueScore?: number;
  expectedValue?: number;
  valueFlag?: boolean;
  homeProbability?: number;
  drawProbability?: number;
  awayProbability?: number;
  marketHomeProbability?: number;
  marketDrawProbability?: number;
  marketAwayProbability?: number;
  asOf?: Date;
  modelVersion?: string;
  calibrationTemperature?: number;
  calibrationSamples?: number;
  homeWinOdds: number;
  drawOdds: number;
  awayWinOdds: number;
}

interface Probabilities {
  home: number;
  draw: number;
  away: number;
}

interface OddsAnalysis {
  market: Probabilities;
  bestOdds: Probabilities;
  movementScore: number;
  volatilityScore: number;
  disagreement: number;
  asOf: Date;
}

const MODEL_VERSION = 'v2.3';

/** European football season: Aug 2025-Jun 2026 is season 2025. */
export function getFootballSeason(date: Date | string): number {
  const d = new Date(date);
  return d.getMonth() >= 6 ? d.getFullYear() : d.getFullYear() - 1;
}

function clamp(value: number, min = 0, max = 1) {
  return Math.max(min, Math.min(max, value));
}

function normalize3(values: Probabilities): Probabilities {
  const total = values.home + values.draw + values.away;
  if (!Number.isFinite(total) || total <= 0) return { home: 1 / 3, draw: 1 / 3, away: 1 / 3 };
  return { home: values.home / total, draw: values.draw / total, away: values.away / total };
}

function median(values: number[]) {
  if (!values.length) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
}

function stddev(values: number[]) {
  if (values.length < 2) return 0;
  const mean = values.reduce((a, b) => a + b, 0) / values.length;
  return Math.sqrt(values.reduce((s, v) => s + (v - mean) ** 2, 0) / values.length);
}

function validOdds(row: OddsHistory) {
  const h = Number(row.homeWinOdds);
  const d = Number(row.drawOdds);
  const a = Number(row.awayWinOdds);
  return h > 1 && d > 1 && a > 1 && [h, d, a].every(Number.isFinite);
}

function probabilitiesFromOdds(home: number, draw: number, away: number): Probabilities {
  return normalize3({ home: 1 / home, draw: 1 / draw, away: 1 / away });
}

function getLatestByBookmaker(history: OddsHistory[]) {
  const byBookmaker = new Map<string, OddsHistory>();
  for (const row of history.filter(validOdds)) {
    const current = byBookmaker.get(row.bookmaker);
    const rowTime = row.sourceUpdatedAt ? new Date(row.sourceUpdatedAt).getTime() : new Date(row.recordedAt).getTime();
    const currentTime = current ? (current.sourceUpdatedAt ? new Date(current.sourceUpdatedAt).getTime() : new Date(current.recordedAt).getTime()) : -Infinity;
    if (!current || rowTime > currentTime) {
      byBookmaker.set(row.bookmaker, row);
    }
  }
  return [...byBookmaker.values()];
}

function analyzeOdds(history: OddsHistory[]): OddsAnalysis {
  const latest = getLatestByBookmaker(history);
  if (!latest.length) {
    return {
      market: { home: 1 / 3, draw: 1 / 3, away: 1 / 3 },
      bestOdds: { home: 2, draw: 3, away: 3.5 },
      movementScore: 0,
      volatilityScore: 0,
      disagreement: 0,
      asOf: new Date(),
    };
  }

  const probs = latest.map(r => probabilitiesFromOdds(Number(r.homeWinOdds), Number(r.drawOdds), Number(r.awayWinOdds)));
  const market = normalize3({
    home: median(probs.map(p => p.home)),
    draw: median(probs.map(p => p.draw)),
    away: median(probs.map(p => p.away)),
  });

  const bestOdds = {
    home: Math.max(...latest.map(r => Number(r.homeWinOdds))),
    draw: Math.max(...latest.map(r => Number(r.drawOdds))),
    away: Math.max(...latest.map(r => Number(r.awayWinOdds))),
  };

  const sourceTimes = latest.map(r => r.sourceUpdatedAt ? new Date(r.sourceUpdatedAt).getTime() : new Date(r.recordedAt).getTime()).filter(Number.isFinite);
  const asOf = sourceTimes.length ? new Date(Math.max(...sourceTimes)) : new Date(Math.max(...latest.map(r => new Date(r.recordedAt).getTime())));

  const disagreementRaw = Math.max(
    stddev(probs.map(p => p.home)),
    stddev(probs.map(p => p.draw)),
    stddev(probs.map(p => p.away)),
  );
  const disagreement = clamp(disagreementRaw / 0.08, 0, 1) * 100;

  const historyByBookmaker = new Map<string, OddsHistory[]>();
  for (const row of history.filter(validOdds)) {
    const list = historyByBookmaker.get(row.bookmaker) || [];
    list.push(row);
    historyByBookmaker.set(row.bookmaker, list.sort((a, b) => new Date(a.recordedAt).getTime() - new Date(b.recordedAt).getTime()));
  }

  const movementSignals: number[] = [];
  const volatilitySignals: number[] = [];
  for (const rows of historyByBookmaker.values()) {
    const recent = rows.slice(-8);
    if (recent.length < 2) continue;
    const series = recent.map(r => probabilitiesFromOdds(Number(r.homeWinOdds), Number(r.drawOdds), Number(r.awayWinOdds)));
    const deltas = [
      Math.abs(series[series.length - 1].home - series[0].home),
      Math.abs(series[series.length - 1].draw - series[0].draw),
      Math.abs(series[series.length - 1].away - series[0].away),
    ];
    movementSignals.push(...deltas);
    volatilitySignals.push(stddev(series.map(p => p.home)), stddev(series.map(p => p.draw)), stddev(series.map(p => p.away)));
  }

  return {
    market,
    bestOdds,
    movementScore: clamp((median(movementSignals) / 0.10), 0, 1) * 100,
    volatilityScore: clamp((median(volatilitySignals) / 0.06), 0, 1) * 100,
    disagreement,
    asOf,
  };
}

function poisson3way(homeXg: number, awayXg: number): Probabilities {
  const maxGoals = 8;
  const factorial = (n: number) => n <= 1 ? 1 : Array.from({ length: n }, (_, i) => i + 1).reduce((a, b) => a * b, 1);
  const pois = (lambda: number, k: number) => Math.exp(-lambda) * lambda ** k / factorial(k);
  let home = 0, draw = 0, away = 0;
  for (let h = 0; h <= maxGoals; h++) {
    for (let a = 0; a <= maxGoals; a++) {
      const p = pois(homeXg, h) * pois(awayXg, a);
      if (h > a) home += p;
      else if (h === a) draw += p;
      else away += p;
    }
  }
  return normalize3({ home, draw, away });
}

function buildTeamModel(home?: TeamFormStats, away?: TeamFormStats, h2h?: HeadToHeadStats | null): Probabilities | null {
  if (!home || !away) return null;

  // Recent goals are a simple, transparent baseline. Home advantage is explicit.
  const homeAttack = Math.max(0.25, home.averageGoalsPerMatch);
  const awayAttack = Math.max(0.25, away.averageGoalsPerMatch);
  const homeDefense = Math.max(0.25, home.goalsAgainst / Math.max(home.wins + home.draws + home.losses, 1));
  const awayDefense = Math.max(0.25, away.goalsAgainst / Math.max(away.wins + away.draws + away.losses, 1));

  let homeXg = 0.58 * homeAttack + 0.42 * awayDefense + 0.28;
  let awayXg = 0.58 * awayAttack + 0.42 * homeDefense;

  const formDelta = (analyzeTeamForm(home) - analyzeTeamForm(away)) / 100;
  homeXg += formDelta * 0.35;
  awayXg -= formDelta * 0.20;

  if (h2h && h2h.totalMatches >= 4) {
    const h2hAdj = analyzeH2HAdvantage(h2h) / 100;
    homeXg += h2hAdj * 0.10;
    awayXg -= h2hAdj * 0.05;
  }

  return poisson3way(clamp(homeXg, 0.2, 3.5), clamp(awayXg, 0.2, 3.5));
}

function blend(market: Probabilities, team: Probabilities | null, movementScore: number, disagreement: number): Probabilities {
  if (!team) return market;
  const marketWeight = 0.42;
  const teamWeight = 0.58;
  const movementWeight = clamp(movementScore / 100, 0, 1) * 0.08;
  const disagreementPenalty = clamp(disagreement / 100, 0, 1) * 0.06;
  const adjustedTeamWeight = Math.max(0.35, teamWeight - disagreementPenalty);
  const adjustedMarketWeight = Math.max(0.30, marketWeight + disagreementPenalty);
  const raw = {
    home: adjustedTeamWeight * team.home + adjustedMarketWeight * market.home,
    draw: adjustedTeamWeight * team.draw + adjustedMarketWeight * market.draw,
    away: adjustedTeamWeight * team.away + adjustedMarketWeight * market.away,
  };
  const favorite = Object.entries(raw).sort((a, b) => b[1] - a[1])[0][0] as keyof Probabilities;
  raw[favorite] += movementWeight * (1 - raw[favorite]);
  return normalize3(raw);
}

function outcomeFromProbabilities(p: Probabilities): Outcome {
  if (p.home >= p.draw && p.home >= p.away) return 'home_win';
  if (p.draw >= p.home && p.draw >= p.away) return 'draw';
  return 'away_win';
}

function getConfidence(p: Probabilities) {
  return Math.round(Math.max(p.home, p.draw, p.away) * 100);
}

function expectedValue(probability: number, odds: number) {
  return probability * odds - 1;
}

function valueScore(ev: number) {
  return Math.round(clamp((ev + 0.10) / 0.30, 0, 1) * 100);
}

function riskLevel(volatility: number, disagreement: number, confidence: number): 'low' | 'medium' | 'high' {
  if (volatility >= 65 || disagreement >= 65 || confidence < 45) return 'high';
  if (volatility >= 35 || disagreement >= 35 || confidence < 58) return 'medium';
  return 'low';
}

function deterministicReasoning(match: Match, outcome: Outcome, p: Probabilities, market: Probabilities, ev: number, disagreement: number) {
  const label = outcome === 'home_win' ? `${match.homeTeam} win` : outcome === 'away_win' ? `${match.awayTeam} win` : 'draw';
  const edge = ((p[outcome === 'home_win' ? 'home' : outcome === 'away_win' ? 'away' : 'draw'] - market[outcome === 'home_win' ? 'home' : outcome === 'away_win' ? 'away' : 'draw']) * 100).toFixed(1);
  const value = (ev * 100).toFixed(1);
  return `${label} is the model's highest-probability outcome at ${getConfidence(p)}%. The independent model is ${Math.abs(Number(edge))}% ${Number(edge) >= 0 ? 'above' : 'below'} the market probability; estimated expected value is ${value}%. Bookmaker disagreement is ${Math.round(disagreement)}%, so this signal should be treated with appropriate caution.`;
}

export async function generatePrediction(input: PredictionInput, options: { skipAiReasoning?: boolean } = {}): Promise<GeneratedPrediction> {
  const { match, oddsHistory } = input;
  const generatedAt = new Date();
  const odds = analyzeOdds(oddsHistory);

  let homeStats: TeamFormStats | undefined;
  let awayStats: TeamFormStats | undefined;
  let h2h: HeadToHeadStats | null = null;
  if (match.homeTeamId && match.awayTeamId && match.leagueId) {
    const season = getFootballSeason(match.matchDate);
    try {
      [homeStats, awayStats, h2h] = await Promise.all([
        fetchTeamFormStats(match.homeTeamId, match.leagueId, season),
        fetchTeamFormStats(match.awayTeamId, match.leagueId, season),
        fetchHeadToHeadStats(match.homeTeamId, match.awayTeamId, 10),
      ]);
    } catch (error) {
      console.warn(`[PredictionEngine] team-data failure for match ${match.id}:`, error);
    }
  }

  const teamModel = buildTeamModel(homeStats || undefined, awayStats || undefined, h2h);
  const rawModel = blend(odds.market, teamModel, odds.movementScore, odds.disagreement);
  const calibration = await getWalkForwardCalibration(generatedAt);
  const calibrated = applyTemperature(rawModel.home, rawModel.draw, rawModel.away, calibration.temperature);
  const model = calibrated;
  const prediction = outcomeFromProbabilities(model);
  const confidence = getConfidence(model);
  const key = prediction === 'home_win' ? 'home' : prediction === 'away_win' ? 'away' : 'draw';
  const bestOdds = odds.bestOdds[key];
  const ev = expectedValue(model[key], bestOdds);
  const value = valueScore(ev);

  const risk = !teamModel ? 'high' : riskLevel(odds.volatilityScore, odds.disagreement, confidence);
  const reasoningBase = deterministicReasoning(match, prediction, model, odds.market, ev, odds.disagreement);
  let reasoning = reasoningBase;

  if (!options.skipAiReasoning && process.env.ENABLE_AI_REASONING !== 'false') {
    try {
      const response = await invokeLLM({
        messages: [
          { role: 'system', content: 'You are an explanation layer for a football forecasting model. Do not invent facts, probabilities, injuries or statistics. Explain the supplied model output in 2-3 concise sentences. Never claim that AI itself produced the probability.' },
          { role: 'user', content: `Match: ${match.homeTeam} vs ${match.awayTeam}. Model probabilities H/D/A: ${(model.home*100).toFixed(1)} / ${(model.draw*100).toFixed(1)} / ${(model.away*100).toFixed(1)}. Market probabilities H/D/A: ${(odds.market.home*100).toFixed(1)} / ${(odds.market.draw*100).toFixed(1)} / ${(odds.market.away*100).toFixed(1)}. Expected value for ${prediction}: ${(ev*100).toFixed(1)}%. Movement: ${odds.movementScore.toFixed(0)}. Volatility: ${odds.volatilityScore.toFixed(0)}. Disagreement: ${odds.disagreement.toFixed(0)}. Base explanation: ${reasoningBase}` },
        ],
      });
      const content = response.choices[0]?.message.content;
      if (content) reasoning = typeof content === 'string' ? content : String(content);
    } catch (error) {
      console.warn('[PredictionEngine] AI explanation unavailable; using deterministic reasoning');
    }
  }

  return {
    prediction,
    confidence,
    reasoning,
    oddsMovementScore: Math.round(odds.movementScore),
    volatilityScore: Math.round(odds.volatilityScore),
    homeFormScore: homeStats ? analyzeTeamForm(homeStats) : undefined,
    awayFormScore: awayStats ? analyzeTeamForm(awayStats) : undefined,
    h2hAdvantage: h2h ? analyzeH2HAdvantage(h2h) : undefined,
    recentFormHome: homeStats?.recentForm,
    recentFormAway: awayStats?.recentForm,
    bookmakerDisagreement: Math.round(odds.disagreement),
    riskLevel: risk,
    valueScore: value,
    expectedValue: ev,
    valueFlag: ev > 0.03,
    homeProbability: model.home * 100,
    drawProbability: model.draw * 100,
    awayProbability: model.away * 100,
    marketHomeProbability: odds.market.home * 100,
    marketDrawProbability: odds.market.draw * 100,
    marketAwayProbability: odds.market.away * 100,
    asOf: odds.asOf,
    modelVersion: teamModel ? `${MODEL_VERSION}${calibration.calibrated ? '-calibrated' : ''}` : `${MODEL_VERSION}-market-fallback${calibration.calibrated ? '-calibrated' : ''}`,
    calibrationTemperature: calibration.temperature,
    calibrationSamples: calibration.samples,
    homeWinOdds: odds.bestOdds.home,
    drawOdds: odds.bestOdds.draw,
    awayWinOdds: odds.bestOdds.away,
  };
}

async function mapWithConcurrency<T, R>(items: T[], worker: (item: T) => Promise<R>, concurrency = 5): Promise<R[]> {
  const results: R[] = new Array(items.length);
  let cursor = 0;
  async function runWorker() {
    while (true) {
      const index = cursor++;
      if (index >= items.length) return;
      results[index] = await worker(items[index]);
    }
  }
  const workers = Array.from({ length: Math.min(concurrency, Math.max(items.length, 1)) }, () => runWorker());
  await Promise.all(workers);
  return results;
}

export async function generateTopPredictions(inputs: PredictionInput[], limit = 20) {
  const predictions = await mapWithConcurrency(inputs, async input => {
    try { return { ...(await generatePrediction(input)), matchId: input.match.id }; }
    catch (error) { console.error(`[PredictionEngine] failed for match ${input.match.id}:`, error); return null; }
  }, 5);
  return predictions.filter(Boolean).sort((a, b) => (b!.confidence + (b!.valueFlag ? 3 : 0)) - (a!.confidence + (a!.valueFlag ? 3 : 0))).slice(0, limit) as (GeneratedPrediction & { matchId: number })[];
}

export async function generatePredictionsWithNotifications(inputs: PredictionInput[], userId: number, limit = 20) {
  const predictions = await generateTopPredictions(inputs, limit);
  const highConfidence = predictions.filter(p => p.confidence >= 75 && p.valueFlag);
  if (highConfidence.length) {
    await notifyBatch(highConfidence.map((p, i) => ({ userId, predictionId: i, matchId: p.matchId, confidence: p.confidence, prediction: p.prediction, reasoning: p.reasoning })));
  }
  return predictions;
}
