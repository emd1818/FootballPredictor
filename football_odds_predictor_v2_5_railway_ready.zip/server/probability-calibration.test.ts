import { describe, expect, it } from 'vitest';
import { applyTemperature, fitTemperature } from './probability-calibration';

describe('walk-forward probability calibration', () => {
  it('temperature > 1 softens probabilities', () => {
    const p = applyTemperature(0.8, 0.1, 0.1, 2);
    expect(p.home).toBeLessThan(0.8);
    expect(p.home + p.draw + p.away).toBeCloseTo(1, 8);
  });

  it('requires a minimum historical sample', () => {
    const result = fitTemperature([{ home: 0.8, draw: 0.1, away: 0.1, actual: 'home_win' }]);
    expect(result.calibrated).toBe(false);
    expect(result.temperature).toBe(1);
  });

  it('learns a softening temperature from overconfident examples', () => {
    const examples = Array.from({ length: 150 }, (_, i) => ({
      home: 0.85,
      draw: 0.10,
      away: 0.05,
      actual: i % 2 === 0 ? 'home_win' as const : 'draw' as const,
    }));
    const result = fitTemperature(examples);
    expect(result.calibrated).toBe(true);
    expect(result.temperature).toBeGreaterThan(1);
  });
});
