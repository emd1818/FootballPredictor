import { and, eq, lt, desc } from 'drizzle-orm';
import { getDb } from './db';
import { predictionAccuracy, predictions } from '../drizzle/schema';

export interface CalibrationExample {
  home: number;
  draw: number;
  away: number;
  actual: 'home_win' | 'draw' | 'away_win';
}

export interface CalibrationResult {
  temperature: number;
  samples: number;
  calibrated: boolean;
  source: 'walk_forward' | 'identity';
}

const CACHE_TTL_MS = 10 * 60 * 1000;
const MIN_SAMPLES = 100;
let cached: { expires: number; result: CalibrationResult } | null = null;

function clampProbability(value: number) {
  return Math.max(1e-6, Math.min(1 - 1e-6, value));
}

export function applyTemperature(home: number, draw: number, away: number, temperature: number) {
  const values = [home, draw, away].map(clampProbability).map(p => Math.exp(Math.log(p) / Math.max(0.25, temperature)));
  const total = values.reduce((a, b) => a + b, 0);
  return { home: values[0] / total, draw: values[1] / total, away: values[2] / total };
}

export function fitTemperature(examples: CalibrationExample[]): CalibrationResult {
  if (examples.length < MIN_SAMPLES) {
    return { temperature: 1, samples: examples.length, calibrated: false, source: 'identity' };
  }

  let bestTemperature = 1;
  let bestLoss = Number.POSITIVE_INFINITY;
  // Coarse-to-fine deterministic grid search. No future observations are used.
  for (let temperature = 0.50; temperature <= 2.50 + 1e-9; temperature += 0.05) {
    const loss = examples.reduce((sum, example) => {
      const p = applyTemperature(example.home, example.draw, example.away, temperature);
      const actual = example.actual === 'home_win' ? p.home : example.actual === 'draw' ? p.draw : p.away;
      return sum - Math.log(clampProbability(actual));
    }, 0) / examples.length;
    if (loss < bestLoss) {
      bestLoss = loss;
      bestTemperature = Number(temperature.toFixed(2));
    }
  }

  return { temperature: bestTemperature, samples: examples.length, calibrated: true, source: 'walk_forward' };
}

export async function getWalkForwardCalibration(asOf: Date): Promise<CalibrationResult> {
  if (cached && cached.expires > Date.now()) return cached.result;
  const db = await getDb();
  if (!db) return { temperature: 1, samples: 0, calibrated: false, source: 'identity' };

  try {
    const rows = await db.select({
      homeProbability: predictions.homeProbability,
      drawProbability: predictions.drawProbability,
      awayProbability: predictions.awayProbability,
      actualResult: predictionAccuracy.actualResult,
      evaluatedAt: predictionAccuracy.evaluatedAt,
    })
      .from(predictionAccuracy)
      .innerJoin(predictions, eq(predictionAccuracy.predictionId, predictions.id))
      .where(and(lt(predictions.generatedAt, asOf), lt(predictionAccuracy.evaluatedAt, asOf)))
      .orderBy(desc(predictionAccuracy.evaluatedAt))
      .limit(5000);

    const examples: CalibrationExample[] = rows
      .map(row => ({
        home: Number(row.homeProbability) / 100,
        draw: Number(row.drawProbability) / 100,
        away: Number(row.awayProbability) / 100,
        actual: row.actualResult,
      }))
      .filter(e => [e.home, e.draw, e.away].every(Number.isFinite) && e.home > 0 && e.draw > 0 && e.away > 0);

    const result = fitTemperature(examples);
    cached = { expires: Date.now() + CACHE_TTL_MS, result };
    return result;
  } catch (error) {
    console.warn('[Calibration] Failed to fit walk-forward temperature:', error);
    return { temperature: 1, samples: 0, calibrated: false, source: 'identity' };
  }
}

export function clearCalibrationCache() {
  cached = null;
}
