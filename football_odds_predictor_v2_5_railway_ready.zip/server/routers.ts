import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { adminProcedure, protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { z } from "zod";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  predictions: router({
    matchOfDay: publicProcedure.query(async () => {
      const { getMatchOfTheDay } = await import('./match-of-day');
      const { getTopPredictions } = await import('./db');
      const matchOfDay = await getMatchOfTheDay();
      
      // No synthetic fallback: if there is no real match-of-day snapshot, return null.
      return matchOfDay;
    }),

    top: publicProcedure.query(async () => {
      const { hasUsableDatabase, getTopPredictions, getMatchById } = await import('./db');
      if (!(await hasUsableDatabase())) {
        const { getLivePredictions } = await import('./live-data');
        return getLivePredictions(20);
      }
      const predictions = await getTopPredictions(20);
      
      // Enrich predictions with match data and normalize probabilities
      const enriched = await Promise.all(
        predictions.map(async (pred) => {
          const match = await getMatchById(pred.matchId);
          
          const normalizedHome = Number(pred.homeProbability ?? 33.33);
          const normalizedDraw = Number(pred.drawProbability ?? 33.33);
          const normalizedAway = Number(pred.awayProbability ?? 33.34);
          const total = normalizedHome + normalizedDraw + normalizedAway;
          const normalizedProbabilities = {
            homeWin: Math.round((normalizedHome / total) * 100),
            draw: Math.round((normalizedDraw / total) * 100),
            awayWin: Math.round((normalizedAway / total) * 100),
          };
          normalizedProbabilities.awayWin = 100 - normalizedProbabilities.homeWin - normalizedProbabilities.draw;
          
          return {
            ...pred,
            match,
            normalizedProbabilities,
          };
        })
      );
      
      return enriched;
    }),
    
    forMatch: publicProcedure
      .input((val: unknown) => {
        if (typeof val === 'object' && val !== null && 'matchId' in val) {
          return val as { matchId: number };
        }
        throw new Error('Invalid input');
      })
      .query(async ({ input }) => {
        const { getPredictionsForMatch } = await import('./db');
        return getPredictionsForMatch(input.matchId);
      }),
  }),

  matches: router({
    upcoming: publicProcedure.query(async () => {
      const { hasUsableDatabase, getUpcomingMatches } = await import('./db');
      if (await hasUsableDatabase()) return getUpcomingMatches(50);
      const { getLiveMatches } = await import('./live-data');
      const live = await getLiveMatches();
      return live.matches.slice(0, 50);
    }),
    refreshLive: adminProcedure.mutation(async () => {
      const { fetchAndProcessOddsData } = await import('./data-fetcher');
      return fetchAndProcessOddsData();
    }),
    
    byId: publicProcedure
      .input((val: unknown) => {
        if (typeof val === 'object' && val !== null && 'id' in val) {
          return val as { id: number };
        }
        throw new Error('Invalid input');
      })
      .query(async ({ input }) => {
        const { hasUsableDatabase, getMatchById, getOddsHistoryForMatch } = await import('./db');
        if (await hasUsableDatabase()) {
          const match = await getMatchById(input.id);
          const oddsHistory = match ? await getOddsHistoryForMatch(match.id) : [];
          return { match, oddsHistory };
        }
        const { getLiveMatches } = await import('./live-data');
        const live = await getLiveMatches();
        const match = live.matches.find(m => m.id === input.id) ?? null;
        return { match, oddsHistory: match ? (live.histories.get(match.id) || []) : [] };
      }),
  }),

  analytics: router({
    performance: publicProcedure
      .input(z.object({ daysBack: z.number().min(1).max(365).optional() }))
      .query(async ({ input }) => {
        const { getPerformanceMetrics } = await import('./performance-analytics');
        return getPerformanceMetrics(input.daysBack || 30);
      }),

    accuracyByLeague: publicProcedure
      .input(z.object({ daysBack: z.number().min(1).max(365).optional() }))
      .query(async ({ input }) => {
        const { getAccuracyByLeague } = await import('./performance-analytics');
        return getAccuracyByLeague(input.daysBack || 30);
      }),

    accuracyByPredictionType: publicProcedure
      .input(z.object({ daysBack: z.number().min(1).max(365).optional() }))
      .query(async ({ input }) => {
        const { getAccuracyByPredictionType } = await import('./performance-analytics');
        return getAccuracyByPredictionType(input.daysBack || 30);
      }),

    statistics: publicProcedure
      .input(z.object({ daysBack: z.number().min(1).max(365).optional() }))
      .query(async ({ input }) => {
        const { getAccuracyStatistics } = await import('./statistics');
        return getAccuracyStatistics(input.daysBack || 30);
      }),

    comparison: publicProcedure
      .input(z.object({ daysBack: z.number().min(1).max(365).optional() }))
      .query(async ({ input }) => {
        const { getComparisonStats } = await import('./comparison-stats');
        return getComparisonStats(input.daysBack || 30);
      }),

    comparisonByType: publicProcedure
      .input(z.object({ daysBack: z.number().min(1).max(365).optional() }))
      .query(async ({ input }) => {
        const { getComparisonByPredictionType } = await import('./comparison-stats');
        return getComparisonByPredictionType(input.daysBack || 30);
      }),

    comparisonByConfidence: publicProcedure
      .input(z.object({ daysBack: z.number().min(1).max(365).optional() }))
      .query(async ({ input }) => {
        const { getComparisonByConfidenceRange } = await import('./comparison-stats');
        return getComparisonByConfidenceRange(input.daysBack || 30);
      }),

    backtest: publicProcedure
      .input(z.object({ daysBack: z.number().min(1).max(3650).optional() }))
      .query(async ({ input }) => {
        const { runHistoricalReplay } = await import('./backtesting');
        return runHistoricalReplay(input.daysBack || 90);
      }),

    archiveHistoricalOdds: adminProcedure
      .input(z.object({ sportKey: z.string().min(1), date: z.string().datetime() }))
      .mutation(async ({ input }) => {
        const { archiveHistoricalOddsSnapshot } = await import('./historical-archive');
        return archiveHistoricalOddsSnapshot(input.sportKey, new Date(input.date));
      }),

    syncHistoricalResults: adminProcedure
      .input(z.object({ date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/), leagueId: z.number().int().positive(), season: z.number().int().min(2000).max(2100) }))
      .mutation(async ({ input }) => {
        const { syncHistoricalResults } = await import('./historical-archive');
        return syncHistoricalResults(input.date, input.leagueId, input.season);
      }),

    recordMatchResult: adminProcedure
      .input(z.object({
        matchId: z.number(),
        result: z.enum(['home_win', 'draw', 'away_win']),
        homeScore: z.number().optional(),
        awayScore: z.number().optional(),
      }))
      .mutation(async ({ input }) => {
        const { recordMatchResult } = await import('./performance-analytics');
        await recordMatchResult(input.matchId, input.result, input.homeScore, input.awayScore);
        return { success: true };
      }),
  }),

  notifications: router({
    preferences: protectedProcedure.query(async ({ ctx }) => {
      const { getOrCreateNotificationPreferences } = await import('./db');
      const prefs = await getOrCreateNotificationPreferences(ctx.user.id);
      return prefs;
    }),

    updatePreferences: protectedProcedure
      .input(z.object({
        confidenceThreshold: z.number().min(50).max(100).optional(),
        enableEmailNotifications: z.boolean().optional(),
        enableInAppNotifications: z.boolean().optional(),
        preferredLeagues: z.array(z.string()).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const { updateNotificationPreferences } = await import('./db');
        const updates: Record<string, any> = {};
        
        if (input.confidenceThreshold !== undefined) {
          updates.confidenceThreshold = input.confidenceThreshold;
        }
        if (input.enableEmailNotifications !== undefined) {
          updates.enableEmailNotifications = input.enableEmailNotifications ? 1 : 0;
        }
        if (input.enableInAppNotifications !== undefined) {
          updates.enableInAppNotifications = input.enableInAppNotifications ? 1 : 0;
        }
        if (input.preferredLeagues !== undefined) {
          updates.preferredLeagues = JSON.stringify(input.preferredLeagues);
        }
        
        await updateNotificationPreferences(ctx.user.id, updates);
        return { success: true };
      }),

    list: protectedProcedure.query(async ({ ctx }) => {
      const { getUserNotifications } = await import('./db');
      return getUserNotifications(ctx.user.id, 50);
    }),

    unread: protectedProcedure.query(async ({ ctx }) => {
      const { getUnreadNotifications } = await import('./db');
      return getUnreadNotifications(ctx.user.id);
    }),

    markAsRead: protectedProcedure
      .input(z.object({ notificationId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const { markNotificationAsRead } = await import('./db');
        await markNotificationAsRead(input.notificationId, ctx.user.id);
        return { success: true };
      }),

    delete: protectedProcedure
      .input(z.object({ notificationId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const { deleteNotification } = await import('./db');
        await deleteNotification(input.notificationId, ctx.user.id);
        return { success: true };
      }),
  }),

  accuracy: router({
    getStats: publicProcedure.query(async () => {
      const { getAccuracyStats } = await import('./accuracy-stats');
      return getAccuracyStats();
    }),
  }),
});

export type AppRouter = typeof appRouter;
