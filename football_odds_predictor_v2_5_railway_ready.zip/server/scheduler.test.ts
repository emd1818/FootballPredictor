import { describe, it, expect, beforeEach, vi } from 'vitest';
import { triggerPredictionUpdate, triggerDailyPredictionGeneration } from './scheduler';

describe('Scheduler', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('triggerPredictionUpdate', () => {
    it('should successfully trigger prediction update', async () => {
      try {
        const result = await triggerPredictionUpdate();
        // Result can be success or failure depending on data availability
        expect(result).toBeDefined();
        expect(result).toHaveProperty('success');
        expect(typeof result.success).toBe('boolean');
      } catch (error) {
        // It's okay if it fails due to no data
        expect(error).toBeDefined();
      }
    }, { timeout: 15000 });

    it('should return success status', async () => {
      try {
        const result = await triggerPredictionUpdate();
        if (result.success) {
          expect(result).toHaveProperty('predictionsGenerated');
          expect(typeof result.predictionsGenerated).toBe('number');
          expect(result.predictionsGenerated).toBeGreaterThanOrEqual(0);
        }
      } catch (error) {
        // Expected if no data
        expect(error).toBeDefined();
      }
    }, { timeout: 15000 });
  });

  describe('triggerDailyPredictionGeneration', () => {
    it('should successfully trigger daily prediction generation', async () => {
      try {
        const result = await triggerDailyPredictionGeneration();
        expect(result).toBeDefined();
        expect(result).toHaveProperty('success');
        expect(typeof result.success).toBe('boolean');
      } catch (error) {
        // It's okay if it fails due to no data
        expect(error).toBeDefined();
      }
    }, { timeout: 60000 });

    it('should return generation status with details', async () => {
      try {
        const result = await triggerDailyPredictionGeneration();
        if (result.success) {
          expect(result).toHaveProperty('predictionsGenerated');
          expect(result).toHaveProperty('matchesProcessed');
          expect(typeof result.predictionsGenerated).toBe('number');
          expect(typeof result.matchesProcessed).toBe('number');
        }
      } catch (error) {
        // Expected if no data
        expect(error).toBeDefined();
      }
    }, { timeout: 60000 });

    it('should handle cases with no upcoming matches', async () => {
      try {
        const result = await triggerDailyPredictionGeneration();
        // If no matches, should return failure
        if (!result.success) {
          expect(result).toHaveProperty('message');
          expect(typeof result.message).toBe('string');
        }
      } catch (error) {
        // Expected behavior
        expect(error).toBeDefined();
      }
    }, { timeout: 60000 });
  });

  describe('Scheduler Configuration', () => {
    it('should have proper cron schedule for daily predictions', () => {
      // Daily prediction job runs at 8 PM (20:00)
      // Cron format: 0 0 20 * * * (second minute hour day month dayOfWeek)
      const expectedCronPattern = '0 0 20 * * *';
      expect(expectedCronPattern).toBeDefined();
      
      // Verify the pattern format
      const parts = expectedCronPattern.split(' ');
      expect(parts).toHaveLength(6);
      expect(parts[2]).toBe('20'); // Hour = 20 (8 PM)
    });

    it('should have proper cron schedule for 30-minute updates', () => {
      // 30-minute update job runs at 0 and 30 minutes of each hour
      // Cron format: 0,30 * * * * (minute hour day month dayOfWeek)
      const expectedCronPattern = '0,30 * * * *';
      expect(expectedCronPattern).toBeDefined();
      
      // Verify the pattern format
      const parts = expectedCronPattern.split(' ');
      expect(parts[0]).toMatch(/0,30/); // Minutes = 0 and 30
    });
  });
});
