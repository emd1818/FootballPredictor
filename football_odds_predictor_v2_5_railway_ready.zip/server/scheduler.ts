import * as cron from 'node-cron';
import { sql } from 'drizzle-orm';
import { fetchAndProcessOddsData } from './data-fetcher';
import { getDb, getUpcomingMatches, getOddsHistoryForMatches, createPrediction } from './db';
import { generateTopPredictions, type PredictionInput } from './prediction-engine';
import { checkAndSendAlerts } from './alert-service';

let scheduledJob: ReturnType<typeof cron.schedule> | null = null;
let cycleRunning = false;
const LOCK_NAME = process.env.SCHEDULER_LOCK_NAME || 'football-odds-predictor:scheduler';

async function withDatabaseLock<T>(fn: () => Promise<T>): Promise<T | null> {
  const db = await getDb();
  if (!db) throw new Error('Database not available');
  const result = await db.execute(sql`SELECT GET_LOCK(${LOCK_NAME}, 0) AS acquired`);
  const acquired = Number((result as any)[0]?.[0]?.acquired ?? (result as any)[0]?.acquired ?? 0) === 1;
  if (!acquired) {
    console.log('[Scheduler] Another instance owns the scheduler lock; skipping cycle.');
    return null;
  }
  try { return await fn(); }
  finally { try { await db.execute(sql`SELECT RELEASE_LOCK(${LOCK_NAME})`); } catch {} }
}

async function runPredictionCycle(reason: string) {
  if (cycleRunning) { console.log('[Scheduler] Cycle already running; skipping.'); return; }
  cycleRunning = true;
  try {
    await withDatabaseLock(async () => {
      console.log(`[Scheduler] Starting ${reason} cycle at ${new Date().toISOString()}`);
      const fetchResult = await fetchAndProcessOddsData();
      if (fetchResult.errors.length) console.warn('[Scheduler] ingestion errors:', fetchResult.errors.slice(0, 10));

      const matches = await getUpcomingMatches(100);
      const histories = await getOddsHistoryForMatches(matches.map(m => m.id));
      const grouped = new Map<number, typeof histories>();
      for (const row of histories) {
        const list = grouped.get(row.matchId) || [];
        list.push(row); grouped.set(row.matchId, list);
      }
      const inputs: PredictionInput[] = matches
        .map(match => ({ match, oddsHistory: grouped.get(match.id) || [] }))
        .filter(input => input.oddsHistory.length > 0);

      // Store every successfully generated snapshot. UI ranking is applied later by getTopPredictions().
      // Limiting here would bias the historical dataset toward high-confidence matches.
      const predictions = await generateTopPredictions(inputs, inputs.length);
      let stored = 0;
      for (const pred of predictions) {
        const row = {
          matchId: pred.matchId,
          prediction: pred.prediction,
          confidence: pred.confidence,
          reasoning: pred.reasoning,
          oddsMovementScore: pred.oddsMovementScore,
          volatilityScore: pred.volatilityScore,
          homeFormScore: pred.homeFormScore,
          awayFormScore: pred.awayFormScore,
          h2hAdvantage: pred.h2hAdvantage,
          recentFormHome: pred.recentFormHome,
          recentFormAway: pred.recentFormAway,
          bookmakerDisagreement: pred.bookmakerDisagreement,
          riskLevel: pred.riskLevel,
          homeWinOdds: String(pred.homeWinOdds),
          drawOdds: String(pred.drawOdds),
          awayWinOdds: String(pred.awayWinOdds),
          aiModel: pred.modelVersion || 'v2',
          modelVersion: pred.modelVersion || 'v2',
          homeProbability: pred.homeProbability?.toFixed(4),
          drawProbability: pred.drawProbability?.toFixed(4),
          awayProbability: pred.awayProbability?.toFixed(4),
          marketHomeProbability: pred.marketHomeProbability?.toFixed(4),
          marketDrawProbability: pred.marketDrawProbability?.toFixed(4),
          marketAwayProbability: pred.marketAwayProbability?.toFixed(4),
          expectedValue: pred.expectedValue?.toFixed(5),
          valueFlag: pred.valueFlag ? 1 : 0,
          calibrationTemperature: pred.calibrationTemperature?.toFixed(3) || '1.000',
          calibrationSamples: pred.calibrationSamples || 0,
          asOf: pred.asOf || new Date(),
          generatedAt: new Date(),
        };
        await createPrediction(row);
        stored++;
      }
      console.log(`[Scheduler] ${reason}: ${matches.length} matches, ${stored} immutable prediction snapshots stored.`);
      try {
        const alerts = await checkAndSendAlerts();
        if (alerts.alertsSent) console.log(`[Scheduler] Alerts sent: ${alerts.alertsSent}`);
      } catch (error) { console.warn('[Scheduler] Alert processing failed:', error); }
    });
  } finally { cycleRunning = false; }
}

export function startScheduler() {
  if (scheduledJob) return;
  if (process.env.SCHEDULER_ENABLED === 'false') {
    console.log('[Scheduler] Disabled by SCHEDULER_ENABLED=false');
    return;
  }
  void runPredictionCycle('initial');
  scheduledJob = cron.schedule('0,30 * * * *', () => void runPredictionCycle('30-minute'));
  console.log('[Scheduler] Started every 30 minutes with a database distributed lock.');
}

export function stopScheduler() {
  scheduledJob?.stop(); scheduledJob = null;
}

export async function triggerPredictionUpdate() {
  await runPredictionCycle('manual');
  return { success: true };
}

// Kept for compatibility with the old UI/API; daily generation is now covered by the single immutable snapshot pipeline.
export function startDailyPredictionJob() { console.log('[Scheduler] Daily job is deprecated; 30-minute pipeline is authoritative.'); }
export function stopDailyPredictionJob() {}
export async function triggerDailyPredictionGeneration() { await runPredictionCycle('manual-daily'); return { success: true }; }
