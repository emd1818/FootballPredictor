import { getDb } from './db';
import { predictionAccuracy, matches } from '../drizzle/schema';
import { eq, and, gte, lt } from 'drizzle-orm';

export interface AccuracyStats {
  totalPredictions: number;
  correctPredictions: number;
  accuracyPercentage: number;
  byPredictionType: {
    homeWin: { total: number; correct: number; accuracy: number };
    draw: { total: number; correct: number; accuracy: number };
    awayWin: { total: number; correct: number; accuracy: number };
  };
  byConfidenceBucket: {
    bucket: string;
    total: number;
    correct: number;
    accuracy: number;
  }[];
  byLeague: {
    league: string;
    total: number;
    correct: number;
    accuracy: number;
  }[];
}

export async function getAccuracyStatistics(
  daysBack: number = 30
): Promise<AccuracyStats> {
  const db = await getDb();
  if (!db) throw new Error('Database not available');

  // Get date range
  const now = new Date();
  const startDate = new Date(now.getTime() - daysBack * 24 * 60 * 60 * 1000);

  // Fetch all accuracy records for the period
  const accuracyRecords = await db
    .select({
      id: predictionAccuracy.id,
      prediction: predictionAccuracy.prediction,
      confidence: predictionAccuracy.confidence,
      actualResult: predictionAccuracy.actualResult,
      isCorrect: predictionAccuracy.isCorrect,
      confidenceBucket: predictionAccuracy.confidenceBucket,
      matchId: predictionAccuracy.matchId,
    })
    .from(predictionAccuracy)
    .where(gte(predictionAccuracy.createdAt, startDate));

  // Fetch match info for league data
  const matchIds = Array.from(new Set(accuracyRecords.map((r) => r.matchId)));
  const matchInfo = await db
    .select({
      id: matches.id,
      league: matches.league,
    })
    .from(matches)
    .where(
      matchIds.length > 0
        ? and(...matchIds.map((id) => eq(matches.id, id)))
        : undefined
    );

  const leagueMap = new Map(matchInfo.map((m) => [m.id, m.league]));

  // Calculate overall stats
  const totalPredictions = accuracyRecords.length;
  const correctPredictions = accuracyRecords.filter((r) => r.isCorrect === 1).length;
  const accuracyPercentage =
    totalPredictions > 0 ? Math.round((correctPredictions / totalPredictions) * 100) : 0;

  // Calculate by prediction type
  const byType = {
    homeWin: { total: 0, correct: 0, accuracy: 0 },
    draw: { total: 0, correct: 0, accuracy: 0 },
    awayWin: { total: 0, correct: 0, accuracy: 0 },
  };

  accuracyRecords.forEach((record) => {
    const typeKey = record.prediction === 'home_win' ? 'homeWin' : record.prediction === 'draw' ? 'draw' : 'awayWin';
    byType[typeKey].total++;
    if (record.isCorrect === 1) {
      byType[typeKey].correct++;
    }
  });

  Object.keys(byType).forEach((key) => {
    const type = byType[key as keyof typeof byType];
    type.accuracy = type.total > 0 ? Math.round((type.correct / type.total) * 100) : 0;
  });

  // Calculate by confidence bucket
  const bucketMap = new Map<string, { total: number; correct: number }>();
  accuracyRecords.forEach((record) => {
    const bucket = record.confidenceBucket;
    if (!bucketMap.has(bucket)) {
      bucketMap.set(bucket, { total: 0, correct: 0 });
    }
    const stats = bucketMap.get(bucket)!;
    stats.total++;
    if (record.isCorrect === 1) {
      stats.correct++;
    }
  });

  const byConfidenceBucket = Array.from(bucketMap.entries())
    .map(([bucket, stats]) => ({
      bucket,
      total: stats.total,
      correct: stats.correct,
      accuracy: Math.round((stats.correct / stats.total) * 100),
    }))
    .sort((a, b) => {
      const aMin = parseInt(a.bucket.split('-')[0]);
      const bMin = parseInt(b.bucket.split('-')[0]);
      return aMin - bMin;
    });

  // Calculate by league
  const leagueMap2 = new Map<string, { total: number; correct: number }>();
  accuracyRecords.forEach((record) => {
    const league = leagueMap.get(record.matchId) || 'Unknown';
    if (!leagueMap2.has(league)) {
      leagueMap2.set(league, { total: 0, correct: 0 });
    }
    const stats = leagueMap2.get(league)!;
    stats.total++;
    if (record.isCorrect === 1) {
      stats.correct++;
    }
  });

  const byLeague = Array.from(leagueMap2.entries())
    .map(([league, stats]) => ({
      league,
      total: stats.total,
      correct: stats.correct,
      accuracy: Math.round((stats.correct / stats.total) * 100),
    }))
    .sort((a, b) => b.total - a.total);

  return {
    totalPredictions,
    correctPredictions,
    accuracyPercentage,
    byPredictionType: {
      homeWin: byType.homeWin,
      draw: byType.draw,
      awayWin: byType.awayWin,
    },
    byConfidenceBucket,
    byLeague,
  };
}
