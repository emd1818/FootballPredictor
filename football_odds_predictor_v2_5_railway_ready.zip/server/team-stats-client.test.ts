import { describe, it, expect, beforeAll } from 'vitest';
import { fetchTeamFormStats, fetchHeadToHeadStats, analyzeTeamForm, analyzeH2HAdvantage } from './team-stats-client';

describe('Team Statistics Client', () => {
  // Test with real API key if configured
  const apiKeyConfigured = !!process.env.API_FOOTBALL_KEY;

  describe('fetchTeamFormStats', () => {
    it('should return null if API key is not configured', async () => {
      // Temporarily remove API key for this test
      const originalKey = process.env.API_FOOTBALL_KEY;
      delete process.env.API_FOOTBALL_KEY;

      const result = await fetchTeamFormStats(33, 39, 2025);
      expect(result).toBeNull();

      // Restore API key
      if (originalKey) {
        process.env.API_FOOTBALL_KEY = originalKey;
      }
    });

    it('should fetch team form statistics if API key is configured', async () => {
      if (!apiKeyConfigured) {
        console.log('[TeamStats] Skipping API test - API_FOOTBALL_KEY not configured');
        expect(true).toBe(true);
        return;
      }

      // Test with Manchester United (ID: 33) in Premier League (ID: 39) for 2025 season
      const result = await fetchTeamFormStats(33, 39, 2025);
      
      if (result) {
        expect(result).toHaveProperty('teamId');
        expect(result).toHaveProperty('teamName');
        expect(result).toHaveProperty('wins');
        expect(result).toHaveProperty('draws');
        expect(result).toHaveProperty('losses');
        expect(result).toHaveProperty('winPercentage');
        expect(result.winPercentage).toBeGreaterThanOrEqual(0);
        expect(result.winPercentage).toBeLessThanOrEqual(100);
      }
    }, { timeout: 10000 });
  });

  describe('fetchHeadToHeadStats', () => {
    it('should return null if API key is not configured', async () => {
      const originalKey = process.env.API_FOOTBALL_KEY;
      delete process.env.API_FOOTBALL_KEY;

      const result = await fetchHeadToHeadStats(33, 34);
      expect(result).toBeNull();

      if (originalKey) {
        process.env.API_FOOTBALL_KEY = originalKey;
      }
    });

    it('should fetch head-to-head statistics if API key is configured', async () => {
      if (!apiKeyConfigured) {
        console.log('[TeamStats] Skipping API test - API_FOOTBALL_KEY not configured');
        expect(true).toBe(true);
        return;
      }

      // Test with Manchester United (33) vs Liverpool (34)
      const result = await fetchHeadToHeadStats(33, 34, 5);
      
      if (result) {
        expect(result).toHaveProperty('homeTeam');
        expect(result).toHaveProperty('awayTeam');
        expect(result).toHaveProperty('homeWins');
        expect(result).toHaveProperty('draws');
        expect(result).toHaveProperty('awayWins');
        expect(result).toHaveProperty('totalMatches');
        expect(result).toHaveProperty('homeWinPercentage');
        expect(result.homeWinPercentage).toBeGreaterThanOrEqual(0);
        expect(result.homeWinPercentage).toBeLessThanOrEqual(100);
      }
    }, { timeout: 10000 });
  });

  describe('analyzeTeamForm', () => {
    it('should calculate form score correctly', () => {
      const mockStats = {
        teamId: 1,
        teamName: 'Test Team',
        recentForm: 'WWWWD',
        wins: 15,
        draws: 5,
        losses: 4,
        goalsFor: 50,
        goalsAgainst: 20,
        goalDifference: 30,
        winPercentage: 65.2,
        averageGoalsPerMatch: 2.17,
      };

      const formScore = analyzeTeamForm(mockStats);
      
      expect(formScore).toBeGreaterThanOrEqual(0);
      expect(formScore).toBeLessThanOrEqual(100);
      expect(formScore).toBeGreaterThan(50); // Good form should score above 50
    });

    it('should handle poor form correctly', () => {
      const mockStats = {
        teamId: 1,
        teamName: 'Poor Team',
        recentForm: 'LLLLL',
        wins: 2,
        draws: 1,
        losses: 21,
        goalsFor: 15,
        goalsAgainst: 60,
        goalDifference: -45,
        winPercentage: 8.7,
        averageGoalsPerMatch: 0.65,
      };

      const formScore = analyzeTeamForm(mockStats);
      
      expect(formScore).toBeGreaterThanOrEqual(0);
      expect(formScore).toBeLessThanOrEqual(100);
      expect(formScore).toBeLessThan(50); // Poor form should score below 50
    });
  });

  describe('analyzeH2HAdvantage', () => {
    it('should calculate home advantage correctly', () => {
      const mockH2H = {
        homeTeam: 'Team A',
        awayTeam: 'Team B',
        homeWins: 6,
        draws: 2,
        awayWins: 2,
        totalMatches: 10,
        homeWinPercentage: 60,
        recentMatches: [],
      };

      const advantage = analyzeH2HAdvantage(mockH2H);
      
      expect(advantage).toBeGreaterThanOrEqual(-100);
      expect(advantage).toBeLessThanOrEqual(100);
      expect(advantage).toBeGreaterThan(0); // Home team has advantage
    });

    it('should calculate away advantage correctly', () => {
      const mockH2H = {
        homeTeam: 'Team A',
        awayTeam: 'Team B',
        homeWins: 2,
        draws: 2,
        awayWins: 6,
        totalMatches: 10,
        homeWinPercentage: 20,
        recentMatches: [],
      };

      const advantage = analyzeH2HAdvantage(mockH2H);
      
      expect(advantage).toBeGreaterThanOrEqual(-100);
      expect(advantage).toBeLessThanOrEqual(100);
      expect(advantage).toBeLessThan(0); // Away team has advantage
    });

    it('should return 0 for no historical data', () => {
      const mockH2H = {
        homeTeam: 'Team A',
        awayTeam: 'Team B',
        homeWins: 0,
        draws: 0,
        awayWins: 0,
        totalMatches: 0,
        homeWinPercentage: 0,
        recentMatches: [],
      };

      const advantage = analyzeH2HAdvantage(mockH2H);
      
      expect(advantage).toBe(0);
    });
  });
});
