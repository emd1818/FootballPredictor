/** API-Football data client with short-lived in-process caching. */
const API_FOOTBALL_BASE_URL = 'https://v3.football.api-sports.io';
const CACHE_TTL_MS = 6 * 60 * 60 * 1000;

export interface TeamFormStats {
  teamId: number; teamName: string; recentForm: string; wins: number; draws: number; losses: number;
  goalsFor: number; goalsAgainst: number; goalDifference: number; winPercentage: number; averageGoalsPerMatch: number;
}
export interface HeadToHeadStats {
  homeTeam: string; awayTeam: string; homeTeamId?: number; awayTeamId?: number;
  homeWins: number; draws: number; awayWins: number; totalMatches: number; homeWinPercentage: number;
  recentMatches: Array<{ date: string; homeTeam: string; awayTeam: string; homeTeamId?: number; awayTeamId?: number; homeGoals: number; awayGoals: number; winner: 'home'|'away'|'draw'; }>;
}

const formCache = new Map<string, { expires: number; value: TeamFormStats | null }>();
const h2hCache = new Map<string, { expires: number; value: HeadToHeadStats | null }>();
const teamSearchCache = new Map<string, { expires: number; value: number | null }>();

function key(...parts: unknown[]) { return parts.join(':'); }
function apiKey() { return process.env.API_FOOTBALL_KEY; }

async function apiGet(path: string, params: Record<string,string>) {
  const token = apiKey();
  if (!token) return null;
  const qs = new URLSearchParams(params);
  const response = await fetch(`${API_FOOTBALL_BASE_URL}/${path}?${qs}`, { headers: { 'x-apisports-key': token, Accept: 'application/json' } });
  if (!response.ok) throw new Error(`API-Football ${response.status} ${response.statusText}`);
  const data = await response.json() as any;
  return Array.isArray(data.response) ? data.response : [];
}

export async function fetchTeamFormStats(teamId: number, leagueId: number, season: number): Promise<TeamFormStats | null> {
  const cacheKey = key(teamId, leagueId, season);
  const cached = formCache.get(cacheKey);
  if (cached && cached.expires > Date.now()) return cached.value;
  if (!apiKey()) return null;
  try {
    // /fixtures is the correct endpoint for the last X fixtures; /teams/statistics is season aggregate data.
    const fixtures = await apiGet('fixtures', { team: String(teamId), league: String(leagueId), season: String(season), last: '5', status: 'FT' });
    if (!fixtures?.length) { formCache.set(cacheKey, { expires: Date.now()+CACHE_TTL_MS, value: null }); return null; }
    let wins=0, draws=0, losses=0, goalsFor=0, goalsAgainst=0;
    let form='';
    for (const fixture of fixtures.slice(-5)) {
      const homeId = fixture.teams?.home?.id;
      const awayId = fixture.teams?.away?.id;
      const hg = Number(fixture.goals?.home ?? 0), ag = Number(fixture.goals?.away ?? 0);
      if (homeId === teamId) {
        goalsFor += hg; goalsAgainst += ag; if (hg>ag) { wins++; form+='W'; } else if (hg===ag) { draws++; form+='D'; } else { losses++; form+='L'; }
      } else if (awayId === teamId) {
        goalsFor += ag; goalsAgainst += hg; if (ag>hg) { wins++; form+='W'; } else if (ag===hg) { draws++; form+='D'; } else { losses++; form+='L'; }
      }
    }
    const total = wins+draws+losses;
    const value = { teamId, teamName: fixtures[0]?.teams?.home?.id===teamId ? fixtures[0]?.teams?.home?.name : fixtures[0]?.teams?.away?.name || 'Unknown', recentForm: form, wins, draws, losses, goalsFor, goalsAgainst, goalDifference: goalsFor-goalsAgainst, winPercentage: total ? wins/total*100 : 0, averageGoalsPerMatch: total ? goalsFor/total : 0 };
    formCache.set(cacheKey, { expires: Date.now()+CACHE_TTL_MS, value });
    return value;
  } catch (error) { console.warn('[TeamStats] form fetch failed:', error); formCache.set(cacheKey, { expires: Date.now()+15*60*1000, value:null }); return null; }
}

export async function fetchHeadToHeadStats(homeTeamId: number, awayTeamId: number, limit=10): Promise<HeadToHeadStats | null> {
  const cacheKey = key(Math.min(homeTeamId,awayTeamId), Math.max(homeTeamId,awayTeamId), limit);
  const cached = h2hCache.get(cacheKey); if (cached && cached.expires>Date.now()) return cached.value;
  if (!apiKey()) return null;
  try {
    const matches = await apiGet('fixtures/headtohead', { h2h:`${homeTeamId}-${awayTeamId}`, last:String(limit), status:'FT' });
    if (!matches?.length) return null;
    let homeWins=0, draws=0, awayWins=0;
    const recentMatches = matches.map((m:any) => {
      const hid=m.teams?.home?.id, aid=m.teams?.away?.id, hg=Number(m.goals?.home??0), ag=Number(m.goals?.away??0);
      let winner:'home'|'away'|'draw'='draw'; if(hg>ag) winner='home'; else if(ag>hg) winner='away';
      if (hid===homeTeamId && winner==='home' || aid===homeTeamId && winner==='away') homeWins++;
      else if (hg===ag) draws++; else awayWins++;
      return { date:m.fixture?.date||'', homeTeam:m.teams?.home?.name||'Unknown', awayTeam:m.teams?.away?.name||'Unknown', homeTeamId:hid, awayTeamId:aid, homeGoals:hg, awayGoals:ag, winner };
    });
    const total=recentMatches.length;
    const value={ homeTeam: homeTeamId === matches[0]?.teams?.home?.id ? (matches[0]?.teams?.home?.name||'Unknown') : (matches[0]?.teams?.away?.name||'Unknown'), awayTeam: awayTeamId === matches[0]?.teams?.away?.id ? (matches[0]?.teams?.away?.name||'Unknown') : (matches[0]?.teams?.home?.name||'Unknown'), homeTeamId, awayTeamId, homeWins, draws, awayWins, totalMatches:total, homeWinPercentage:total?homeWins/total*100:0, recentMatches };
    h2hCache.set(cacheKey,{expires:Date.now()+24*60*60*1000,value}); return value;
  } catch(error){ console.warn('[TeamStats] H2H fetch failed:',error); h2hCache.set(cacheKey,{expires:Date.now()+60*60*1000,value:null}); return null; }
}

export async function resolveTeamIdByName(name:string): Promise<number|null> {
  const normalized=name.trim().toLowerCase(); const cached=teamSearchCache.get(normalized); if(cached && cached.expires>Date.now()) return cached.value;
  if(!apiKey()) return null;
  try { const teams=await apiGet('teams',{search:name}); const exact=teams.find((t:any)=>String(t.team?.name||'').trim().toLowerCase()===normalized); const value=exact?.team?.id ?? teams[0]?.team?.id ?? null; teamSearchCache.set(normalized,{expires:Date.now()+24*60*60*1000,value}); return value; }
  catch(error){ console.warn('[TeamStats] team resolution failed:',error); return null; }
}

export function analyzeTeamForm(stats: TeamFormStats): number {
  const total=Math.max(1,stats.wins+stats.draws+stats.losses);
  const recentPoints=(stats.wins*3+stats.draws)/(total*3)*100;
  const gd=Math.max(0,Math.min(100,50+stats.goalDifference*4));
  return Math.round(Math.max(0,Math.min(100,recentPoints*0.65+gd*0.35)));
}

export function analyzeH2HAdvantage(h2h: HeadToHeadStats): number {
  if(!h2h.totalMatches) return 0;
  return Math.round((h2h.homeWins-h2h.awayWins)/h2h.totalMatches*100);
}

export interface HistoricalFixtureResult {
  fixtureId: number;
  date: string;
  homeTeamId: number;
  awayTeamId: number;
  homeTeam: string;
  awayTeam: string;
  status: string;
  homeGoals: number;
  awayGoals: number;
}

/** Fetch completed fixtures for a specific historical date/league/season. */
export async function fetchCompletedFixturesForDate(date: string, leagueId: number, season: number): Promise<HistoricalFixtureResult[]> {
  const fixtures = await apiGet('fixtures', {
    date,
    league: String(leagueId),
    season: String(season),
    status: 'FT-AET-PEN',
  });
  return (fixtures || []).map((fixture: any) => ({
    fixtureId: Number(fixture.fixture?.id),
    date: String(fixture.fixture?.date || ''),
    homeTeamId: Number(fixture.teams?.home?.id),
    awayTeamId: Number(fixture.teams?.away?.id),
    homeTeam: String(fixture.teams?.home?.name || 'Unknown'),
    awayTeam: String(fixture.teams?.away?.name || 'Unknown'),
    status: String(fixture.fixture?.status?.short || ''),
    homeGoals: Number(fixture.goals?.home ?? 0),
    awayGoals: Number(fixture.goals?.away ?? 0),
  })).filter((fixture: HistoricalFixtureResult) => Number.isFinite(fixture.fixtureId) && fixture.homeTeamId > 0 && fixture.awayTeamId > 0);
}
